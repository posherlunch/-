﻿// ============================================================
//  《屠龙谣》The Ballad Got It Wrong · 全局配置
//  这个文件做六件事：
//    1. 准备引擎要用的容器（INTRO / EVENTS / ENDINGS / INITIAL_STATE）
//    2. 定义人物面板要显示的条目文字（TRAITS）
//    3. 定义人物名单 id → 显示名（NAMES）
//    4. 定义成就（ACHIEVEMENTS）
//    5. 占位结局（第一章完成前的「未完待续」页）
//    6. 文件底部附「事件写法速查」，写新剧情时对照即可
//
//  ⚠ 所有给玩家看的文字都写成 { zh: "…", en: "…" } 两份。
//     缺哪一边，按 F12 打开控制台会直接点名（玩家看不到）。
//
//  ⚠ 英文为 AI 初稿占位，等润色后的英文回传再整体替换 en 字段。
// ============================================================

window.INTRO = [];
window.EVENTS = [];

// ------------------------------------------------------------
//  开局状态：全部是单选变量（字符串）。没有数值。
//  想加一个新变量，就在这里加一行，然后在剧情里 set 它。
//  —— 标志位总表逐章生长：本文件只放序章用到的六个。
// ------------------------------------------------------------
window.INITIAL_STATE = {
  // —— 序章（p0a–p3d 选定，之后不再变）
  claw:   "",            // sharp / dull / kept   磨爪的方式
  keep:   "",            // arrow / ring / coin    带走的旧藏
  face:   "",            // scar / scholar / hunter 化形的那张脸
  gender: "",            // male / female / unspoken
  voice:  "",            // low / true             嗓音
  habit:  "",            // sniff / finger / distance 化不掉的习惯
  name:   "",            // 玩家输入的名字（序章 p0 / 第一章 e06 两次机会）
  named:  false,         // 玩家主动起过名（空输入不算）：p0a 起名确认句 / {name} 称呼挂接用
  p1Sense: "",           // lights / face / wind   出洞后你先看了什么（p1 三选，认领读点 p2）
  p4Move:  "",           // walk / song / wink     你怎么下的山（p4 三选，认领读点 e01）

  // —— 第一章（e01–e07）
  dogStart:    false,    // 村口的狗开始观察你
  e01Dog:      "",       // stare / avoid   与村口的狗对视还是绕开（认领读点 e02）
  breadResult: "",       // who / mother / wrong / took / coin 面包摊的应对
  breadShort:  false,    // 拿面包没付够钱（隐藏成就线）
  sus1:        false,    // 村民疑心·一档
  gossipKnown: false,    // 从井边听到了押龙的内情
  songChoice:  "",       // coin / noname / cliff / listen 酒馆的应对
  keeperChoice:"",       // sarcasm / passing / legend 纪念堂的应对
  legendTold:  false,    // A 讲完了家族传说
  taughtKids:  false,    // 教了孩子「歌里的龙不会追」
  kidResult:   "",       // roar / roarFail / norun / hero
  cageChoice:  "",       // stop / away / hold 扔石头的应对
  stoppedStone:false,    // 拦下了孩子扔的石头
  askedIoreth: false,    // 向老兵问了伊奥瑞斯家的事
  nameChoice:  "",       // byface / nobody / iorth 你怎么回答老兵的名字问题
  inPartyA:    false,    // A 放下祭典，与你同行
  inPartyB:    false,    // B 带上祖传歌本，与你同行
  aAsk:        "",       // invite / guard / listen 你对守祠人的回答
  bAsk:        "",       // walk / stay / ballad 你对歌手的回答
  inPartyC:    false,    // C 与你立下盟约：同行至圣地
  feedC:       false,   // 给笼中的龙塞过吃的
  cageTalk:    false,    // 与笼中的龙谈过它为何不逃
  cQpact:      false,    // 与C立下问约：每晚一问，答到圣地
  cAsk:        "",       // why / force / feed 营地隔笼谈了什么
  bedChoice:   "",       // barn / church / den   入村第一夜睡在哪（面板条目）
  path:        "",       // comply / probe / flee 怎么面对传说（第二章入口）

  // —— 第二章 · A线（顺从·扮演英雄）
  feastToast:  "",       // toast / nod / speak 英雄宴的应对
  legendHard1: false,    // 传说硬化·一档（敬酒）
  legendCrack1:false,    // 传说裂隙·一档（劝食）
  soupChoice:  "",       // drink / truth / ask 寡妇汤的应对
  legendCrack2:false,    // 传说裂隙·二档（寡妇处说破 / 摆正剑 / 拒祝福 / B线全盘揭穿）
  widowMemory: false,    // 听寡妇讲完了火灾回忆
  keeperAsk:   "",       // lie / truth / silence 守祠人质问的应对
  keeperLied:  false,    // 对守祠人撒了谎
  songFix:     "",       // remove / fix / takeback 对 B 新词的应对
  legendHard2: false,    // 传说硬化·二档（送行祝福）
  charmGiven:  false,    // 给笼中龙挂了护符

  // —— 第二章 · B线（揭穿·收集证词）
  swordExamined: false,  // 检查过纪念堂里那把从未开刃的剑
  recordsRead:   false,  // 读过守祠人家族的火灾记录簿
  lastLook:      "",     // ch2b 循环页：本轮刚检视了什么（sword / book，回环只显示新段落）
  realSongHeard: false,  // 听歌手唱过原版歌谣
  bookTaken:     false,  // 拿走了歌手的祖传歌本
  soldierTruth:  false,  // 听老兵讲完了火灾目击真相
  b3Ask:       "",       // why / thanks    听完老兵的话你追问还是道谢（认领读点 b4）
  keeperAlly:    false,  // 守祠人愿意帮你揭穿传说
  b4Act:       "",       // accuse / sword  老兵屋里你怎么对守祠人说（认领读点 b5）
  swordShown:    false,  // 在黎明广场当众展示了那把假剑
  dragonSpeaks:  false,  // 在黎明广场让笼中龙开口

  // —— 第二章 · C线（绕开·直奔现场）
  onMountain:    false,  // 开始攀登高托山
  scorchExamined:false,  // 仔细检查过半山腰的烧痕
  scaleTaken:    false,  // 从崖底撞击坑拿走了龙鳞
  highClimb:     false,  // 攀登到了灼痕线的起点
  dragonTruth:   false,  // 听笼中龙讲完了两龙之战的真相
  c3Ask:       "",       // burn / thanks   龙讲完后你追问还是道谢（认领读点 c4）
  ridgeGo:       false,  // 出发前绕道回了旧巢
  stayEnd:       false,  // C线·随笼上山
  fleeEnd:       false,  // C线·被钟声追上归队
  truthEnd:      false,  // C线·回村对空屋说了真相

  // —— 第三章（破链）
  fightWhy:   "",        // grudge / bond / skip  与C的缠斗原因（玩家选过去）
  leadPray:   "",        // hard / crack / no    守夜祷的念法（仅A线）
  finaleSword:"",        // took / open / turned 执剑戏的手
  fuseBroke:  "",        // say / snap / hold    引信：怎么中断仪式
  paradePos:  "",        // front / back / cage  行军时你走的位置（ch3p1 三选，认领读点 ch3a）
  revealAct:  "",        // silent / voice / mirror 真身显露的方式（ch3f 三选，认领读点 ch3g）
  crisisAct:  "",        // shield / retreat / roar  仪式崩坏时的行动（ch3d 三选，认领读点 ch3f）
  ch3eAct:    "",        // funnel / past  逃离时你撑开路口还是跨过那只鞋（ch3e 二选，认领读点 ch3f）
  veteranSaved: false,   // 从火里救了老兵（与他的徽章）
  shoeTaken:  false,     // 从踩踏里捡起了孩子的鞋
  nightVisit: "",        // feed / ask / watch   仪式前夜的隔笼再谈
  cNightPost: "",        // sit / stand / bed  隔笼夜谈后你怎么收尾（ch3p1e 三选，认领读点 ch3a）
  climaxEnd: "",         // force / yield / fall / rewrite 终拍选择

  // —— 画像系统（CoG 合规工程 · 阶段一）
  // RO 性别在相遇页由玩家逐个选定（混沌之神范式）：male / female / nonbinary。
  // 正文里用 {aHe}{aHis}{bWas}… 代词 token，引擎按性别查表替换；
  // 中文 nonbinary 用头衔指代（守祠人/歌手/那条龙），英文用 they/them + 复数动词。
  roA_sex: "",            // A 守祠人（e04 纪念堂相遇页定）
  roB_sex: "",            // B 歌手（e03 酒馆相遇页定）
  roC_sex: "",            // C 那条龙（第三章化形页定）
  aHeart:  false,         // 心意档（阶段三感情线：inParty→Heart→告白→Love）
  bHeart:  false,
  cHeart:  false,
  aLove:   false,         // 告白回应档（告白页「回应」选项 set；亲密页与结局渲染「歌里没唱」变体）
  bLove:   false,
  cLove:   false,
  aBond:   "",            // hand / step  A 告白页的表态（伸手＝暧昧 / 退开＝婉拒；认领读点 ch3p1b）
  bBond:   "",            // string / stick  B 告白页的表态（按弦＝暧昧 / 添柴＝保持距离；认领读点 ch3p1d）
  dogName: "",            // coal / bread（空=未命名）歌续章页给村口的狗起的名

  log: []
};

// ------------------------------------------------------------
//  人物面板的显示文字。
//  ⚠ 改动了创建选项，记得同步改这里，否则人物界面会显示"—"。
// ------------------------------------------------------------
window.TRAITS = {
  claw: {
    sharp: { label: { zh: "磨利的爪", en: "Sharpened claws" },
             desc:  { zh: "漆黑锃亮，弯如镰月。下山这一路，它们会替你开口。",
                      en: "Black and gleaming, curved like sickle moons. On the way down, they will do your talking." } },
    dull:  { label: { zh: "磨钝的爪", en: "Ground-down claws" },
             desc:  { zh: "钝得像一柄收鞘过冬的刀。人类不会徒手切开石头。",
                      en: "Blunted like a knife put away for the winter. Humans do not cut stone with their hands." } },
    kept:  { label: { zh: "任其生长的爪", en: "Claws, left alone" },
             desc:  { zh: "又长又弯，格格不入。不管你从前是什么，你从来都不是规规矩矩的那一类。",
                      en: "Long, curved, wrong. Whatever you were, you were not tidy." } }
  },
  keep: {
    arrow: { label: { zh: "一支断箭", en: "A broken arrow" },
             desc:  { zh: "它烧伤过你一次。\n\n你已记不清是什么时候把它拔出来的。\n\n它压在你的鳞片底下，像一句没说完的话。",
                      en: "It burned, once. You do not remember when you pulled it out. It presses under the scale, like a sentence no one finished." } },
    ring: { label: { zh: "一枚银戒", en: "A silver ring" },
             desc:  { zh: "它从一只烫伤的小手里滑落。有人在哭。你分不清是谁。",
                      en: "It slid off a small scalded hand. Someone was crying. You could not say whose." } },
    coin: { label: { zh: "一枚半熔的硬币", en: "A half-melted coin" },
             desc:  { zh: "你至今记得金属熔化的气味。至少这件事，确确实实是你干的。",
                      en: "You remember the smell of it melting. That, at least, was your own work." } }
  },
  face: {
    scar:     { label: { zh: "带疤的脸", en: "Scarred face" },
                desc:  { zh: "眉骨上一道旧疤，把眉毛截成两段，像一条路被落石拦腰截断。",
                         en: "An old scar splits the brow in two, like a road cut off by a rockfall." } },
    scholar:  { label: { zh: "读书人的脸", en: "Scholar's face" },
                desc:  { zh: "人们总是很快就信任这张脸，你始终没想明白为什么。\n\n它像是属于书斋的脸——或者说，最适合在书斋里撒谎的脸。",
                         en: "People trust it quickly, and you never knew why. A face made for libraries, or for lying in one." } },
    hunter:   { label: { zh: "猎人的脸", en: "Hunter's face" },
                desc:  { zh: "那种还没人问你打哪儿来，就先被端上一碗炖菜的脸。",
                         en: "The kind that gets offered stew before it gets asked questions." } }
  },
  gender: {
    male:     { label: { zh: "男", en: "Male" } },
    female:   { label: { zh: "女", en: "Female" } },
    unspoken: { label: { zh: "从没留意过", en: "Never checked" },
                desc:  { zh: "你从没费心去弄清楚过。",
                         en: "You never once bothered to check." } }
  },
  voice: {
    low:  { label: { zh: "压低的嗓音", en: "A pressed voice" },
            desc:  { zh: "一副借来的嗓子，压得又低又平，像踩实了的雪。\n\n它从没出过岔子，却也一直在收取代价。",
                     en: "A borrowed voice, pressed flat like packed snow. It never cracked. It cost you." } },
    true: { label: { zh: "你自己的嗓音", en: "Your own voice" },
            desc:  { zh: "太低沉，元音拖得太长，像远方滚来的天气。\n\n你向人类问好时，他们听见的是雷声。",
                     en: "Too deep, too long in the vowels, a sound like distant weather. Humans heard thunder when you said hello." } }
  },
  habit: {
    sniff:    { label: { zh: "先嗅后语", en: "Smell first" },
                desc:  { zh: "每次开口之前，你总要先把周遭的气味闻个遍。",
                         en: "You smelled everything first and spoke second." } },
    finger:   { label: { zh: "闲不住的手指", en: "Restless fingers" },
                desc:  { zh: "你的手指从不安分，总得搓着点什么、拨弄着点什么。",
                         en: "Your fingers were never still—they worried at things." } },
    distance: { label: { zh: "三步之距", en: "Three steps" },
                desc:  { zh: "你和任何活物之间，总要隔开三步。",
                         en: "You kept three steps between yourself and everyone alive." } }
  },
  bedChoice: {
    barn:    { label: { zh: "谷仓里的干草", en: "The barn's hay" },
               desc:  { zh: "你枕着草料的气味入睡。\n\n这只借来的人鼻子，勉强熬过了一夜。",
                        en: "You slept with the smell of feed. The borrowed nose managed one night." } },
    church:  { label: { zh: "教堂的末排长椅", en: "The back pew" },
               desc:  { zh: "硬木长椅硌得你后背生疼。很好。疼痛足以让梦里的那条龙闭嘴。",
                        en: "The hard pew bites the back. Good. The pain is enough to silence the dragon in your dream." } },
    den:     { label: { zh: "悬崖下的旧巢", en: "The den below the cliff" },
               desc:  { zh: "你翻过栅栏，以真身睡了一夜。六十年来，你第一次觉得自己又是自己了。",
                        en: "You slipped the fence and slept in your own shape — the first night in sixty years that felt like yourself." } }
  },
  dogName: {
    coal:    { label: { zh: "煤球", en: "Coal" },
               desc:  { zh: "村口那条黄狗的耳朵还缺着一块。\n\n你喊了它的名字，它应了，整个集市都听见了。",
                        en: "The yellow dog at the gate, torn ear and all. When you called it, it answered — the whole market heard." } },
    bread:   { label: { zh: "面包", en: "Bread" },
               desc:  { zh: "村口那条黄狗的耳朵还缺着一块。\n\n那个名字是一笔旧债，如今总算还清了。",
                        en: "The yellow dog at the gate, torn ear and all. The name is an old debt, and it is paid now." } }
  }
};

// ------------------------------------------------------------
//  人物面板左列的类别名（右列＝玩家所选的选项名，取自上面 TRAITS 的 label）。
//  ⚠ 新增 TRAITS 分组时同步补一行；缺了的组左列会回退显示选项名。
// ------------------------------------------------------------
window.TRAIT_CATS = {
  claw:      { zh: "爪", en: "Claws" },
  keep:      { zh: "随身物品", en: "Keepsake" },
  face:      { zh: "长相", en: "Face" },
  gender:    { zh: "性别", en: "Gender" },
  voice:     { zh: "嗓音", en: "Voice" },
  habit:     { zh: "习惯", en: "Habit" },
  bedChoice: { zh: "睡处", en: "Sleeping place" },
  dogName:   { zh: "狗的名字", en: "The dog's name" }
};

// ------------------------------------------------------------
//  名单 id → 显示名（第一章起用）。
// ------------------------------------------------------------
window.NAMES = {
  self: { zh: "你自己", en: "Yourself" }
};

// ------------------------------------------------------------
//  左页场景插图映射（阶段一插图定稿）：按事件 id 精确匹配，从上往下取首条命中。
//  依据《剧情结构梳理-第一轮.md》4.1 场景分组（S1–S17）。
//  sex＝读取哪个角色性别标志（roA_sex/e04 定、roB_sex/e03 定、roC_sex/ch3p1d 定）：
//    male→_m  female→_f  nonbinary→守祠人/佩兰用 _obj（物件图）、龙人形用 _x（nb 字段）
//    性别未定时返回空 → 引擎沿用上一页的图（一局开头才显示空白羊皮纸）。
//  未列出的 id（ch3p2、dev_end 等）同样沿用上一页的图；一局开头无图时空白羊皮纸。
//  图放 assets/illust/<key>.webp（兼容 .png）。
// ------------------------------------------------------------
window.ILLUST_MAP = [
  { ids: ["p4"], key: "statue" },                                    // S2 广场雕像
  { ids: ["p0", "p0a", "p0b", "p1", "p2", "p3", "p3b", "p3c", "p3d", "p3e"],
    key: "scene_nest" },                                             // S1 山巢，夜
  { ids: ["e01"], key: "scene_nest" },                               // S3 下山，夜
  { ids: ["e02", "e02b", "e02c"], key: "statue" },                   // S3 广场雕像
  { ids: ["e03", "e03b", "e07b"], key: "bard", sex: "roB_sex" },     // S4 佩兰
  { ids: ["e04", "e04c", "e04b", "e07a"], key: "keeper", sex: "roA_sex" }, // S5 守祠人
  { ids: ["e05", "e07c", "e07c2", "e07c4", "e07c5", "e07d", "ch3p1b"],
    key: "caged_dragon" },                                           // S6+S8+S12喂食 笼中龙
  { ids: ["e06"], key: "veteran" },                                  // S7 老兵
  { ids: ["ch2a", "a2", "a3", "a3b", "a5"], key: "keeper", sex: "roA_sex" }, // 顺从线·守祠人
  { ids: ["a4"], key: "bard", sex: "roB_sex" },                      // 顺从线·歌手的新词
  { ids: ["ch2b", "b4", "b5"], key: "keeper", sex: "roA_sex" },      // 揭穿线·守祠人
  { ids: ["b2", "b2b"], key: "bard", sex: "roB_sex" },               // 揭穿线·歌手的旧书/下一节
  { ids: ["b3"], key: "veteran" },                                   // 揭穿线·老兵火堆
  { ids: ["ch2c", "c2", "c3", "c4", "c5"], key: "caged_dragon" },    // 逃避线·笼中龙
  { ids: ["ch3p1", "aConfess"], key: "keeper", sex: "roA_sex" },     // S12 A告白沿用守祠人
  { ids: ["ch3p1c", "bConfess"], key: "bard", sex: "roB_sex" },      // S12 B告白沿用佩兰
  { ids: ["ch3p1d", "ch3p1e"], key: "dragon", sex: "roC_sex", nb: "_x" }, // S12 龙人形
  { ids: ["aKiss"], key: "cg_a" },                                   // 恋爱CG（不分性别）
  { ids: ["bKiss"], key: "cg_b" },
  { ids: ["cKiss"], key: "cg_c" },
  { ids: ["ch3a", "ch3b", "ch3c", "ch3c2"], key: "scene_altar" },    // S13 黑石台
  { ids: ["ch3d", "ch3e", "ch3f"], key: "scene_fire" },              // S14 火场
  { ids: ["ch3g"], key: "scene_fire" },                              // S14 尾声沿用火场
  { ids: ["endA", "endA2"], key: "cg_end_a" },                       // S16 结局CG＋余响沿用
  { ids: ["endB", "endB2"], key: "cg_end_b" },
  { ids: ["endC", "endC2"], key: "cg_end_c" },
  { ids: ["endH", "endH2"], key: "cg_end_h" }
];
// ch3p2 不挂映射：引擎沿用前一页的图。

// ------------------------------------------------------------
//  成就（三档：结局 / 好感回应 / 隐藏行为）。
//  when：标志位命中即达成（当下弹窗）；ending：走到对应结局时达成。
//  dev_end 不发成就。成就不设清单页——未达成内容不剧透。
// ------------------------------------------------------------
window.ACHIEVEMENTS = [
  // —— 结局成就 ——
  { id: "end_force", ending: "force",
    title: { zh: "以力止力", en: "Force Against Force" },
    desc:  { zh: "弩阵塌了，故事也塌了。村子再没机会问个明白。",
             en: "The bolts came down, and so did the story. The village never got to ask." } },
  { id: "end_yield", ending: "yield",
    title: { zh: "让出传说", en: "Yielding the Legend" },
    desc:  { zh: "你把故事留在了人人够得着的地方。歌活了下来。",
             en: "You left the story where everyone could reach it. The song lived on." } },
  { id: "end_fall", ending: "fall",
    title: { zh: "睁眼坠落", en: "The Fall, Chosen" },
    desc:  { zh: "六十年前是失足。这一次，你睁着眼睛。",
             en: "Sixty years ago, an accident. This time, you kept your eyes open." } },
  { id: "end_rewrite", ending: "rewrite",
    title: { zh: "当众改写", en: "The Rewriting" },
    desc:  { zh: "守祠人挡在弩前，歌手提笔，龙作证。真相当众归还。",
             en: "The keeper stood before the bolts, the singer took the pen, the dragon bore witness. The truth went home in daylight." } },

  // —— 好感成就（告白得到回应）——
  { id: "love_a", when: { aLove: true },
    title: { zh: "你应了", en: "You Answered" },
    desc:  { zh: "有人把那个名字念出了不同的分量。你应了。",
             en: "Your name, said like it mattered. You answered it." } },
  { id: "love_b", when: { bLove: true },
    title: { zh: "再唱一遍", en: "Once More" },
    desc:  { zh: "今晚不需要歌。可你还是说了：再唱一遍，慢一点。",
             en: "The night didn't need a song. You asked for one anyway — slower." } },
  { id: "love_c", when: { cLove: true },
    title: { zh: "握住了那只手", en: "The Hand, Taken" },
    desc:  { zh: "扣子扣错了，留着没改。你握住了那只手。",
             en: "Buttons wrong, and left so. You took the hand anyway." } },

  // —— 隐藏行为成就（可选项的暗线，不剧透达成方式）——
  { id: "bread_short", when: { breadShort: true },
    title: { zh: "只是饿了", en: "Only Hunger" },
    desc:  { zh: "拿一条面包，柜台上什么也不留。",
             en: "You took a loaf and left nothing on the counter." } },
  { id: "legend_told", when: { legendTold: true },
    title: { zh: "一字不落", en: "Every Word of It" },
    desc:  { zh: "听守祠人把家族的传说，完整地讲了一遍。",
             en: "You heard the family legend told, whole." } },
  { id: "taught_kids", when: { taughtKids: true },
    title: { zh: "歌里的龙不追人", en: "The Song's Dragon Doesn't Chase People" },
    desc:  { zh: "你给孩子们的游戏，添了一条新规矩。",
             en: "You gave the children's game a new rule." } },
  { id: "asked_ioreth", when: { askedIoreth: true },
    title: { zh: "歌里的说法", en: "What the Song Calls It" },
    desc:  { zh: "你向老兵问起了伊奥瑞斯家——被英雄“救下”的那一家。",
             en: "You asked the old soldier about the Ioreths — the family the hero \"saved.\"" } },
  { id: "cage_talk", when: { cageTalk: true },
    title: { zh: "隔笼相问", en: "Questions Through the Bars" },
    desc:  { zh: "你隔着栏杆，与那条龙谈了谈去留。",
             en: "You talked of staying and going with the dragon in the cage." } },
  { id: "feed_c", when: { feedC: true },
    title: { zh: "带了样东西", en: "Brought Something" },
    desc:  { zh: "“我给你带了样东西。”你说了，也做了。",
             en: "\"I brought you something.\" You said it, and you did." } },
  { id: "keeper_lied", when: { keeperLied: true },
    title: { zh: "雇佣兵的故事", en: "The Mercenary Story" },
    desc:  { zh: "守祠人问起你的来历，你当场编了一个。",
             en: "The keeper asked where you came from. You made one up on the spot." } },
  { id: "legend_hard1", when: { legendHard1: true },
    title: { zh: "敬酒词", en: "The Toast" },
    desc:  { zh: "英雄宴上，你把那段话续顺了。它听上去比任何时候都更像真的。",
             en: "At the hero's feast, you carried the verse on — smoother and truer than it has ever sounded." } },
  { id: "legend_crack1", when: { legendCrack1: true },
    title: { zh: "掺了一个真字", en: "One True Word" },
    desc:  { zh: "你往那个传说里掺进了一个真字。裂缝，就是这样开始的。",
             en: "You slipped one true word into the legend. That is how cracks begin." } }
];

// ------------------------------------------------------------
//  占位结局：序章走完后给玩家一个「未完待续」页。
//  第一章完成时，把正式结局（以力止力/让出传说/坠落＋隐藏结局）
//  写进 story/99-endings.js 并删掉这一条。
// ------------------------------------------------------------
window.ENDINGS = [
  {
    id: "dev_end",
    condition: function () { return true; },
    title: { zh: "山下之歌", en: "The Song Below" },
    text: {
      zh: "序章到此结束。\n\n你磨过的爪，你带走的旧物，你想起的那张脸——它们都会在第一章追上你。\n\n（第一章：入村——制作中）",
      en: "The prologue ends here.\n\nThe claws you ground, the keepsake you took, the face you remembered — all of them catch up with you in Chapter One.\n\n(Chapter One · Into the Village — in development)"
    }
  }
];

/* ============================================================

   事 件 写 法 速 查（写剧情只看这里）

   一个事件 = 一页书。
   所有给玩家看的文字都写成 { zh, en } 两份——缺哪一边，
   按 F12 打开控制台会直接点名；漏译和断链都跑不掉。

   INTRO.push({ … })   // 创建流程（序章）
   EVENTS.push({ … })  // 正式剧情

   EVENTS.push({
     id: "e01",                       // 唯一 id，别的选项用 next 跳过来
     title: { zh: "页面标题", en: "Page title" },
     text:  { zh: "正文，用 \n\n 分段。", en: "Body, split with \n\n." },
     choices: [ … ]
   });

   ── 正文写条件变体（从上往下匹配，命中第一条就用它）──

   text: [
     { when: { claw: "sharp" }, text: { zh: "……", en: "…" } },
     { when: { keep: ["arrow", "coin"] }, text: { zh: "……", en: "…" } },
     { text: { zh: "……上面都不满足时的兜底正文。",
               en: "…fallback body." } }          // 兜底放最后
   ]

   正文里可以插玩家名字：
   { zh: "……{name}，你不该来这里。", en: "…{name}, you shouldn't be here." }

   ── RO 代词 token（相遇页选定性别后，引擎按性别替换）──
   {aHe} {aHim} {aHis} {aSelf}    A 守祠人（他/她/守祠人…）
   {bHe} {bHim} {bHis} {bSelf}    B 歌手
   {cHe} {cHim} {cHis} {cSelf}    C 那条龙
   英文专用：{aIs} {aWas} {aVs}（is/was/动词加s；nonbinary→are/were/去s）
   家族称谓随性别翻转：{aGrand} {aGreat}（祖父/外祖母/祖上/曾祖辈）
                       {bGrand}（爷爷/外婆/祖辈）
   ⚠ 相遇页之前的页面禁止使用：性别未设定时 token 会原样露出。

   ── 选项写法 ──（text 与 log 同样是 { zh, en }）

   { text: {…}, next: "下一个事件id" }
   { text: {…}, when: { face: "scar" },  next: "…" }  // 满足才显示
   { text: {…}, hide: { claw: "sharp" }, next: "…" }  // 满足就隐藏
   { text: {…}, set:  { claw: "sharp" }, next: "…" }  // 记住一个变量
   { text: {…}, log: { zh: "一句话记录。", en: "One-line log." }, next: "…" }
   { text: {…}, next: "ENDING_CHECK" }                // 通向结局判定

   ── 条件写法 ──（when / hide 里都能用）
   { claw: "sharp" }               等于
   { keep: ["arrow", "coin"] }     其中之一

   ── 新增一章 ──
   1. 在 story/ 里新建一个 .js 文件
   2. 在 index.html 底部加一行 <script src="story/xx.js"></script>
   3. 文件里只管 INTRO.push(…) 或 EVENTS.push(…)

   写完按 F12 看控制台：断链、重复 id、漏译都会直接报警（玩家看不到）。

   ============================================================ */
