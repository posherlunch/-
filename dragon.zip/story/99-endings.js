﻿// ============================================================
//  结局层（3 显性 ＋ 1 隐藏 ＋ 兜底）
//  引擎从上往下找第一条 condition 为真的；最后是兜底。
//  condition 收到的 s 就是标志位对象。
//
//  ⚠ 顺序即优先级：隐藏（rewrite）必须在最前——它的条件最苛刻，
//    排在后面会被 force/yield/fall 永久挡住。
//  完整结局叙事在 story/30-ch3.js 的 endA/endB/endC/endH 事件页里，
//  这里的 text 只是结局屏上的收束短文。
//  本文件整体覆盖 00-config.js 里的占位 ENDINGS（加载顺序在后）。
// ============================================================

window.ENDINGS = [

  // —— 隐藏结局：当众改写（三人全同行＋揭穿线＋终拍第四项）——
  {
    id: "rewrite",
    title: { zh: "当众改写", en: "The Rewriting" },
    condition: (s) => s.inPartyA && s.inPartyB && s.inPartyC &&
                       s.path === "probe" && s.climaxEnd === "rewrite",
    text: {
      zh: "守祠人挡在弩前，歌手提笔记下，龙在黑石上低头作证。\n\n" +
          "你当着全村的面，把真相原原本本交还给他们。从此，那首歌终于把地点唱对了。年复一年，孩子们在广场上玩着屠龙的游戏，却再也没有谁必须去扮那个怪物。\n\n" +
          "（隐藏结局 · 当众改写）",
      en: "All three keepers of the legend stood witness: the keeper in front of the crossbows, the singer with {bHis} ink, the dragon under oath. You handed them back their own truth — and the song finally got the location right. Year after year the children played the dragon-slaying game in the square, and nobody ever had to be the beast.\n\n(Hidden ending · The Rewriting)"
    }
  },

  // —— 结局 A：以力止力 ——
  {
    id: "force",
    title: { zh: "以力止力", en: "Force Against Force" },
    condition: (s) => s.climaxEnd === "force",
    text: {
      zh: "你冲垮了弩阵，也冲垮了那个讲了六十年的故事，然后带着全部的真相去了西方。村子从此再没有机会问个明白，那首歌也只好将错就错，一代一代唱了下去。" +
          "而两道影子沿着古老的猎道一路西去，飞向了那些还没有人为它们写过歌的地方。",
      en: "You broke the bolts and broke the story, and took the whole knowing west with you. The village never got to ask; the song kept getting it wrong, generation after generation. Two shadows flew the old prey-paths, going nowhere that had a song yet."
    }
  },

  // —— 结局 B：让出传说 ——
  {
    id: "yield",
    title: { zh: "让出传说", en: "Yielding the Legend" },
    condition: (s) => s.climaxEnd === "yield",
    text: {
      zh: "你替一个正在离去的奇迹挡下了整轮箭雨，又把故事的碎片留在了人人都够得着的地方。\n\n" +
          "那首歌依旧传唱不息，只是从此以后，它再也找不到一张可以唱错的脸了。",
      en: "You took the volley meant for a departing miracle, then left the pieces of the story where all of them could reach. The song survives — it has just never again had a face to be wrong about."
    }
  },

  // —— 结局 C：坠落 ——
  {
    id: "fall",
    title: { zh: "睁眼坠落", en: "The Fall, Chosen" },
    condition: (s) => s.climaxEnd === "fall",
    text: {
      zh: "你带着它回到了一切开始的那面崖壁。" +
          "六十年前，你是从这里失足坠落的；而这一次，你们在崖顶紧紧抓住彼此，睁着眼睛收起了翅膀。\n\n你回来，并不是为了弄清当年究竟发生了什么，而是为了亲自做出这个选择。",
      en: "You took it down to the ground where it actually happened, and let go at the top, together. Sixty years ago you fell by accident; this time, with your eyes open. You did not come back to find out what happened. You came back to choose it."
    }
  },

  // —— 兜底：理论上走不到这里（终拍四选必设 climaxEnd）——
  {
    id: "dev_end",
    title: { zh: "山下的歌声", en: "The Song Below" },
    condition: function () { return true; },
    text: {
      zh: "山还立着。歌也还在。\n\n（开发占位结局——如果你看到这一页，说明终局选择没有被正确记录。）",
      en: "The mountain still stands. The song still stands.\n\n(Dev placeholder — if you " +
          "see this page, the climax choice was not recorded.)"
    }
  }
];
