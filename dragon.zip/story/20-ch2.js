// ============================================================
//  第二章 · 三线并行
//  A线（顺从·扮演英雄）：a1–a5 已实装
//  B线（揭穿·收证词）、C线（绕开·直奔现场）：占位待写
//  zh：谷歌翻译稿＋人工修硬伤   en：英文原稿（待润色）
// ============================================================

// ---------- A线共享正文段 ----------

// a2 寡妇场景（前接敬酒后果；面变体在尾部拼接）
const a2ZhWidow =
  "等孩子们都睡下以后，那个老妇人来了。从你到这儿的头一天起，你就在井边、祠堂的台阶上、烤炉的热气旁见过她，她的一只眼睛已经瞎了，腰板却挺得笔直。早在这条街铺上石板之前，她就住在这里了。\n\n她把一碗冒着热气的汤放到你面前，那只好眼睛和那只瞎眼睛，都牢牢地钉在你的脸上。\n\n“六十年，”她说，“六十年了，你一天都没老。坐吧。不过是一碗汤。”";
const a2EnWidow =
  "After the children sleep, the old woman comes. You have seen her since your " +
  "first day here — at the well, on the shrine steps, in the oven's heat — one " +
  "eye gone, back straight, and she has fed bread to this street longer than " +
  "this street has had stones.\n\n" +
  "She sets a steaming bowl before you. Both her eyes — the good one and the " +
  "dead one — find your face and hold it.\n\n" +
  "\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is " +
  "only soup.\"";

// a2 面变体行（寡妇对不同脸的辨认）
const a2ZhFace = {
  scar:    "\n\n“那道疤，”她说，“就是那道疤。我从前还给你端水洗过它。”那道疤并不是你的，可它确实曾经长在某个人的脸上，而这个女人的手，至今还记得替那个人清洗它的感觉。",
  scholar: "\n\n“我教小儿子认字，头一个教的就是你的名字，”她说，“可你的名字到底该怎么写，你自己从来没告诉过我们。”",
  hunter:  "\n\n“你就是用这副肩膀，把人一个一个从火里背出来的。”她的目光顺着你的胳膊滑下去，“对不对？”"
};
const a2EnFace = {
  scar:    "\n\n\"That scar,\" she says. \"That scar. I once offered water to " +
           "wash it.\" You did not leave that scar. But someone did, and this " +
           "woman's hands live on the other side of it.",
  scholar: "\n\n\"I taught my youngest his letters so he could write your name " +
           "right,\" she says. \"But you never taught me mine.\"",
  hunter:  "\n\n\"You carried bodies out of the fire on shoulders like these.\" " +
           "Her gaze travels down your arm. \"Didn't you?\""
};

// a2 敬酒后果（统一开场，三种敬酒方式共用）
const a2ZhToast = "酒杯碰到了你的嘴唇，烤肉和柴烟的热气升起来，遮住了每一张脸。\n\n";
const a2EnToast = "The rim meets your lips. Roast-smoke rises and covers every face.\n\n";

// a2 英雄宴敬酒词回收（legendHard1＝把谎续顺了；legendCrack1＝往谎里掺了一个真字）
const a2ZhToastHard =
  "敬酒词说出口，比你预想的还要顺。为熄灭的火，为那只手，满场的杯子应声而起，杯底磕着桌面，一桌传过一桌。\n\n这是一套练了六十年的应和，而你头一回站在了它的正中央，用你自己的声音，把那句谎言续得滴水不漏。\n\n" + a2ZhToast;
const a2EnToastHard =
  "The toast comes out smoother than you meant it. To the fire that went out, " +
  "to the hand that broke it — cups rise all around you, rims knocking " +
  "tables, table by table. A sixty-year-old response, and you at the center " +
  "of it for the first time: your own voice, carrying the lie without a " +
  "drop spilled.\n\n" + a2EnToast;
const a2ZhToastCrack =
  "没有人听出那句祝词有什么不对。\n\n他们举起杯，为“像他那样从简”喝彩，把“离开”两个字也顺顺当当地咽了下去。歌里唱的是坠落，你敬的却是离开，一字之差，满场竟没有一只耳朵发觉。\n\n" + a2ZhToast;
const a2EnToastCrack =
  "No one hears anything wrong with the blessing. Cups rise to \"eating " +
  "lightly, as he did,\" and the word \"left\" goes down as smoothly as " +
  "everything else. The song says fell; your toast says left — one word " +
  "apart, and not one ear in the square catches it.\n\n" + a2EnToast;

// a3 守祠人质问场景（前接寡妇汤后果）
const a3ZhKeeper =
  "祠堂的门锁着，门缝底下却透出光来。\n\n守祠人还在里面等着，又或者说，等待本就是{aHe}真正的本事。\n\n你还没走完台阶，门就开了，{aHe}站在门里，一手端着烛台，一手拿着擦拭布。\n\n这已经不是你第一次注意到了：这个人从不佩剑，一次也没有。\n\n“明天一早，最后那批人就会到祠堂——名字真正写在族谱上的那些人。”{aHe}说，“我每次一闭上眼，就看见石头里的那张脸，还有你站在它底下。”{aHe}放下烛台，这是你见过的{aHim}最平静的样子，而平静的人，往往最危险。\n\n“所以，趁他们还没来，趁我还没被逼着向谁下跪——”{aHe}朝你走近一步，“你从哪儿来？你想要什么？”";
const a3EnKeeper =
  "The shrine door is locked, but light comes through under it. The keeper is " +
  "inside, and {aHe} {aIs} still waiting — or perhaps waiting is what {aHe} does. Before " +
  "you finish the steps {aHe} {aIs} on {aHis} feet, a candlestick in one hand and a " +
  "polishing cloth in the other. You notice, not for the first time, that {aHe} " +
  "never carry{aVs} a sword. Never.\n\n" +
  "\"By morning, the last of them will be at the shrine — the ones whose names " +
  "are actually on the family writ,\" {aHe} say{aVs}. \"Every time I close " +
  "my eyes I see your face in the stone, and your body standing beneath it.\" " +
  "{aHe} set{aVs} down the candlestick. This is the calmest you have ever seen {aHim}, " +
  "and the calm ones are the dangerous kind.\n\n" +
  "\"So before they come, before I am made to kneel to someone—\" {aHe} step{aVs} " +
  "closer. \"Where are you from? What do you want?\"";

// a3 寡妇汤后果行
const a3ZhSoup = {
  drink: "你喝了一口。在热气里，谎言和真话是同一个温度。\n\n她看着你咽下去，然后说：“这汤还是老味道。”其实并不是，这个村子里，早就没有什么还是老样子了。\n\n",
  truth: "“你记得的那张脸、那双手——都不是我的。”你说。她沉默了很久，然后轻声说道：“不，就是你。我记得那双手。”在场的人里，只有你知道她说对了。\n\n",
  ask:   "她谈起那场火，就像谈起一个人：哪家先烧起来，哪条巷子躲过了一劫，烟又是怎么走的。\n\n她讲着讲着，这个故事就渐渐不再属于你了。“够了，”她说，“喝你的汤。”\n\n"
};
const a3EnSoup = {
  drink: "You drink. In the steam, lie and truth are the same temperature. She " +
         "watches you swallow, then says, \"The soup is the same.\" It is not. " +
         "Nothing under this roof is.\n\n",
  truth: "\"The scar they washed, the body they carried — those were someone " +
         "else's hands.\" She goes quiet for a long time. Then, softly: \"No. " +
         "They were your hands. I remember your hands.\" Only you in this room " +
         "know she is right.\n\n",
  ask:   "She describes the fire the way one describes a person: which house " +
         "burned first, which alley the fire did not reach, how the smoke " +
         "moved. After a while the story stops belonging to you at all. " +
         "\"Enough,\" she says. \"Drink now.\"\n\n"
};

// a4 歌手新词场景（前接守祠人质问后果）
const a4ZhSinger =
  "黄昏时分，歌手来找你，手指上还沾着墨，外套里揣着一首折了四折的新歌。\n\n“为周年准备的，”{bHe}说，“英雄归来。”{bHe}清了清嗓子，半唱半念：\n\n“英雄下了托尔岗，焦土又见青草长；乡亲举火迎路旁，恶兽死在冷山冈。”\n\n{bHe}停了下来，连夜色也在听。\n\n“这不是真的，”{bHe}轻声说，“坠落那段不对，剑那段也不对。可它押韵，所以他们会唱。”{bHe}看着你，“那些真的部分——我该拿它们怎么办？”";
const a4EnSinger =
  "At dusk the singer finds you, ink on {bHis} fingers, a new song folded four " +
  "times inside {bHis} coat.\n\n" +
  "\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat " +
  "and recites it half-sung:\n\n" +
  "\"Down from the Tor's dark the hero came, where he burned the grass grew " +
  "green, and the villagers ran with torches aflame — for the beast lay dead " +
  "beneath the cold bare sky.\"\n\n" +
  "{bHe} stop{bVs}. The night listens.\n\n" +
  "\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. " +
  "But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The " +
  "true parts — what do I do with them?\"";

// a4 守祠人质问后果行
const a4ZhKeeper = {
  lie:     "守祠人的脸上纹丝不动。“六十年来，冒充那位英雄的人不计其数，”{aHe}说，“我们家亲手埋过好几个。”顿了顿，又道，“你知道这些，还敢在守祠人面前说这种话？”\n\n",
  truth:   "守祠人短促地笑了一声，笑声里满是疲惫。“守护真相吧，我想。我{aGrand}围着一把什么也没砍过的剑，盖起了这座祠堂。”\n\n{aHe}久久地盯着你，“等我想明白你到底是这座祠堂的一部分，还是只是借了它的形状，你再来吧。”\n\n",
  silence: "烛火一阵摇晃，守祠人手里的布也拧紧了。“两天，”{aHe}终于开口，“你要是个骗子，就在仪式之前走。否则，我会当着雕像和全村人的面揭穿你。”\n\n你几乎要相信，{aHe}这话是出于好意。\n\n"
};
const a4EnKeeper = {
  lie:     "{aHis} face does not move. \"Sixty years, and any number have tried to " +
           "pass themselves off as the hero,\" {aHe} say{aVs}. \"My family buried " +
           "several who tried.\" {aHe} pause{aVs}. \"And yet — you dare say it to the " +
           "keeper's face?\"\n\n",
  truth:   "{aHe} laugh{aVs}, short and worn out. \"To guard the truth, I suppose. " +
           "My {aGrand} built this shrine around a sword that has never cut " +
           "anything.\" {aHe} gaze{aVs} at you for a long time. \"Come back when I know " +
           "whether you are part of the shrine, or only wear its shape.\"\n\n",
  silence: "The candle gutters. The rag in {aHis} hand twist{aVs}. \"Two days,\" {aHe} " +
           "say{aVs} at last. \"If you are a fraud, leave before the service — or I " +
           "will unmask you before God, and before everyone.\" You almost believe " +
           "{aHe} mean{aVs} it kindly.\n\n"
};

// a4 裂缝档回收（legendCrack1：来源无关的档位式措辞，接在歌手问句后）
const a4ZhCrack =
  "这些字落进你耳朵的时候，你身上已经有一道缝先替它们裂开了。缝并不深，可风已经钻得进去了。";
const a4EnCrack =
  "By the time these words reach your ears, some seam in you has already " +
  "split open ahead of them. The seam is not deep. But the wind gets in now.";

// a5 押送启程场景（前接歌手新词后果）
const a5ZhSendoff =
  "他们在天亮之前出发，那时雾还以为整个山谷都归它所有，骡子、火把和铁笼，全都裹在阴影里。全村人穿着睡衣和靴子聚到了广场上，有人往你肩上披了一件斗篷，有人往你手里塞了一句祝福。\n\n“说那几句话吧，英雄。”开口的是村里的长者，村里一半人的婚礼是她主持的，另一半人的葬礼也是。“屠龙者亲眼看着最后一个敌人死去。这一回，也该让屠龙者的脸再看一次。”\n\n笼中的龙一整夜都没有看过任何人，此刻却看向了你，带着一种只有已经抵达目的地的东西才有的耐心。而在这片广场上，只有你知道它为什么这样看你。";
const a5EnSendoff =
  "They leave before dawn, when the mist still thinks it owns the valley. Mules, " +
  "torches, the cage all wrapped in shadow. The whole village comes to the " +
  "square in nightshirts and boots; someone drapes a cloak over your shoulders, " +
  "someone presses a blessing into your hands.\n\n" +
  "\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy " +
  "die. The Slayer's face should see this too.\"\n\n" +
  "The dragon in the cage has not looked at anyone all night. Now it looks at " +
  "you, with the patience of a thing that has already reached where it wanted " +
  "to go — and you alone in this yard know it.";

// a5 歌手新词后果行
const a5ZhSong = {
  remove:   "歌手把歌词纸折好，塞回了外套里。“那它就只是一首歌，”{bHe}说，“歌本来就是用来安慰人的。”\n\n{bHe}是真心想要安慰，安慰你，也安慰{bSelf}。\n\n",
  fix:      "歌手盯着你看了一会儿，然后慢慢地，在自己干燥的掌心里写下了几个字：“剑上无血。”\n\n{bHe}低声说：“这会是整首歌里最好的一句，而谁也不会知道它好在哪儿。”\n\n",
  takeback: "“我知道。”歌手说，夜色仿佛微微一动，“所以我才来问你。”\n\n"
};
const a5EnSong = {
  remove:   "{bHe} fold{bVs} the verse back into {bHis} coat. \"Then it's just a song,\" " +
            "{bHe} say{bVs}. \"Songs are for comforting.\" {bHe} mean{bVs} comfort — for you, " +
            "and for {bSelf}.\n\n",
  fix:      "{bHe} stare{bVs} at you. Then, slowly, {bHe} trace{bVs} three words in the " +
           "palm of {bHis} dry hand. \"The sword that never cut,\" {bHe} whisper{bVs}. " +
           "\"That will be the best line in the song, and no one will know " +
           "why.\"\n\n",
  takeback: "\"I know,\" {bHe} say{bVs}. The night changes. \"That's why I asked.\"\n\n"
};

// a5 守夜祷「剑已举」咽回（legendCrack1·守夜祷来源）的回收句，插在歌手后果与送行之间
const a5ZhPrayCrack =
  "昨夜那根鱼刺还卡在原处。“剑已举”三个字，你念到一半就咽了回去，村里人只当那是哽咽，纷纷低下了头；只有你知道是怎么回事：三句话里有一句正在变成谎言，而你亲口把它念了一半。\n\n";
const a5EnPrayCrack =
  "The fishbone from last night is still where it lodged. Halfway through " +
  "\"the sword was raised\" you swallowed the rest. The village takes it for " +
  "a choked-back sob and bows their heads; only you know what it actually " +
  "was — one of the three lines turning into a lie, and you had spoken " +
  "half of it with your own mouth.\n\n";

// ============================================================
//  ch2a · 英雄宴（A线入口，id 须与 e07d 的 next 一致）
// ============================================================
EVENTS.push({
  id: "ch2a",
  title: { zh: "英雄的宴席", en: "The Hero's Feast" },
  text: {
    zh: "他们让你坐在雕像看得见的地方。\n\n村里从天一亮就开始烤肉，整猪在铁叉上转着，香气滚过昨天才摆满广场的长桌。有人把一顶用晚开的花编成的花环戴到了你头上，花上还带着田野的凉意。没有人问过你愿不愿意，他们给你戴上花环，自然得就像雨落在山上。\n\n你坐在主桌上，整个广场都在等你举杯。四下静得像一座屏住了呼吸的采石场，所有人都在听。",
    en: "They seat you where the statue can see you.\n\n" +
        "The village has been roasting since dawn. The pig turns on its spit, " +
        "and the smell rolls out over a square filled with tables that did not " +
        "exist yesterday. Someone sets a late-blooming garland on your head — " +
        "it still carries the cool of the fields. No one asks. They put it on " +
        "you the way rain falls on mountains.\n\n" +
        "At the high table, the whole square waits for you to raise your cup. " +
        "Silent as quarry holding its breath — everyone is listening."
  },
  choices: [
    { text: { zh: "“敬那场熄灭的火，也敬熄灭它的那只手。”",
              en: "\"To the fire that went out, and to the hand that put it out.\"" },
      set: { feastToast: "toast", legendHard1: true }, next: "a2" },
    { text: { zh: "点头，喝酒，一言不发。",
              en: "Nod. Drink. Say nothing." },
      set: { feastToast: "nod" }, next: "a2" },
    { text: { zh: "“故事里的英雄是自己选择离开的。今晚，我们也像他那样，一切从简吧。”",
              en: "\"The hero in the story was one who chose to leave. Tonight, let us eat lightly, as he did.\"" },
      set: { feastToast: "speak", legendCrack1: true }, next: "a2" }
  ]
});

// ============================================================
//  a2 · 寡妇的汤（前接英雄宴；面变体）
// ============================================================
EVENTS.push({
  id: "a2",
  title: { zh: "寡妇的汤", en: "The Widow's Soup" },
  text: [
    // 说了敬酒词（legendHard1）：回收句前缀＋统一开场
    { when: { feastToast: "toast", face: "scar" },
      text: { zh: a2ZhToastHard + a2ZhWidow + a2ZhFace.scar,
              en: "The toast comes out smoother than you expected. To the fire that went out, to the hand that put it out — cups rise all around you, rims knocking tables, table by table. A sixty-year-old response, and you at the center of it for the first time: your own voice, carrying the lie without a drop spilled.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"That scar,\" she says. \"That scar. I once offered water to wash it.\" You did not leave that scar. But someone did, and this woman's hands live on the other side of it." } },
    { when: { feastToast: "toast", face: "scholar" },
      text: { zh: a2ZhToastHard + a2ZhWidow + a2ZhFace.scholar,
              en: "The toast comes out smoother than you expected. To the fire that went out, to the hand that put it out — cups rise all around you, rims knocking tables, table by table. A sixty-year-old response, and you at the center of it for the first time: your own voice, carrying the lie without a drop spilled.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"I taught my youngest his letters so he could write your name right,\" she says. \"But you never told us how to write it.\"" } },
    { when: { feastToast: "toast", face: "hunter" },
      text: { zh: a2ZhToastHard + a2ZhWidow + a2ZhFace.hunter,
              en: "The toast comes out smoother than you expected. To the fire that went out, to the hand that put it out — cups rise all around you, rims knocking tables, table by table. A sixty-year-old response, and you at the center of it for the first time: your own voice, carrying the lie without a drop spilled.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"You carried bodies out of the fire on shoulders like these.\" Her gaze travels down your arm. \"Didn't you?\"" } },
    // 「一切从简」（legendCrack1）：回收句前缀＋统一开场
    { when: { feastToast: "speak", face: "scar" },
      text: { zh: a2ZhToastCrack + a2ZhWidow + a2ZhFace.scar,
              en: "No one hears anything wrong with the blessing. Cups rise to \"eating lightly, as he did,\" and the word \"left\" goes down as smoothly as everything else. The song says fell; your toast says left — one word apart, and not one ear in the square catches it.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"That scar,\" she says. \"That scar. I once offered water to wash it.\" You did not leave that scar. But someone did, and this woman's hands live on the other side of it." } },
    { when: { feastToast: "speak", face: "scholar" },
      text: { zh: a2ZhToastCrack + a2ZhWidow + a2ZhFace.scholar,
              en: "No one hears anything wrong with the blessing. Cups rise to \"eating lightly, as he did,\" and the word \"left\" goes down as smoothly as everything else. The song says fell; your toast says left — one word apart, and not one ear in the square catches it.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"I taught my youngest his letters so he could write your name right,\" she says. \"But you never told us how to write it.\"" } },
    { when: { feastToast: "speak", face: "hunter" },
      text: { zh: a2ZhToastCrack + a2ZhWidow + a2ZhFace.hunter,
              en: "No one hears anything wrong with the blessing. Cups rise to \"eating lightly, as he did,\" and the word \"left\" goes down as smoothly as everything else. The song says fell; your toast says left — one word apart, and not one ear in the square catches it.\n\nThe rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"You carried bodies out of the fire on shoulders like these.\" Her gaze travels down your arm. \"Didn't you?\"" } },
    // 点头喝酒（feastToast:"nod"）：仅统一开场
    { when: { face: "scar" },
      text: { zh: a2ZhToast + a2ZhWidow + a2ZhFace.scar,
              en: "The rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"That scar,\" she says. \"That scar. I once offered water to wash it.\" You did not leave that scar. But someone did, and this woman's hands live on the other side of it." } },
    { when: { face: "scholar" },
      text: { zh: a2ZhToast + a2ZhWidow + a2ZhFace.scholar,
              en: "The rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"I taught my youngest his letters so he could write your name right,\" she says. \"But you never told us how to write it.\"" } },
    { when: { face: "hunter" },
      text: { zh: a2ZhToast + a2ZhWidow + a2ZhFace.hunter,
              en: "The rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"\n\n\"You carried bodies out of the fire on shoulders like these.\" Her gaze travels down your arm. \"Didn't you?\"" } },
    { text: { zh: a2ZhToast + a2ZhWidow,
              en: "The rim meets your lips. Roast-smoke rises and covers every face.\n\nAfter the children sleep, the old woman comes. You have seen her since your first day here — at the well, on the shrine steps, in the oven's heat — one eye gone, back straight, and she has lived here longer than this street has had stones.\n\nShe sets a steaming bowl before you. Both her eyes — the good one and the dead one — find your face and hold it.\n\n\"Sixty years,\" she says. \"Sixty years, and you have not aged. Sit. It is only soup.\"" } }
  ],
  choices: [
    { text: { zh: "喝下去。别让你的脸先开口。",
              en: "Drink. Don't let your face speak." },
      set: { soupChoice: "drink" }, next: "a3" },
    { text: { zh: "“你记得的那张脸、那双手——都不是我的。”",
              en: "\"The face you remember, the hands — neither is mine.\"" },
      set: { soupChoice: "truth", legendCrack2: true }, next: "a3" },
    { text: { zh: "问她，这些事她究竟是怎么记得的。",
              en: "Ask her how she remembers it." },
      set: { soupChoice: "ask", widowMemory: true }, next: "a3" }
  ]
});

// ============================================================
//  a3 · 守祠人的质问（前接寡妇汤；汤选择变体）
// ============================================================
EVENTS.push({
  id: "a3",
  title: { zh: "守祠人的问题", en: "The Keeper's Question" },
  text: [
    { when: { soupChoice: "drink" },
      text: { zh: a3ZhSoup.drink + a3ZhKeeper,
              en: "You drink. In the steam, lie and truth are the same temperature. She watches you swallow, then says, \"The soup is the same.\" It is not. Nothing under this roof is.\n\nThe shrine door is locked, but light comes through under it. The keeper is inside, and {aHe} {aIs} still waiting — or perhaps waiting is the one thing {aHe} {aIs} truly good at. Before you finish the steps the door opens, and {aHe} {aIs} in the doorway with {aHis} hands full — a candlestick in one, a polishing cloth in the other. You notice, not for the first time, that {aHe} never wear{aVs} a sword. Never.\n\n\"By morning, the last of them will be at the shrine — the ones whose names are actually on the family writ,\" {aHe} say{aVs}. \"Every time I close my eyes I see your face in the stone, and your body standing beneath it.\" {aHe} set{aVs} down the candlestick. This is the calmest you have ever seen {aHim}, and the calm ones are the dangerous kind.\n\n\"So before they come, before I am made to kneel to someone—\" {aHe} step{aVs} closer. \"Where are you from? What do you want?\"" } },
    { when: { soupChoice: "truth" },
      text: { zh: a3ZhSoup.truth + a3ZhKeeper,
              en: "\"The face you remember, the hands — neither is mine,\" you say. She goes quiet for a long time. Then, softly: \"No. They were your hands. I remember your hands.\" Only you in this room know she is right.\n\nThe shrine door is locked, but light comes through under it. The keeper is inside, and {aHe} {aIs} still waiting — or perhaps waiting is the one thing {aHe} {aIs} truly good at. Before you finish the steps the door opens, and {aHe} {aIs} in the doorway with {aHis} hands full — a candlestick in one, a polishing cloth in the other. You notice, not for the first time, that {aHe} never wear{aVs} a sword. Never.\n\n\"By morning, the last of them will be at the shrine — the ones whose names are actually on the family writ,\" {aHe} say{aVs}. \"Every time I close my eyes I see your face in the stone, and your body standing beneath it.\" {aHe} set{aVs} down the candlestick. This is the calmest you have ever seen {aHim}, and the calm ones are the dangerous kind.\n\n\"So before they come, before I am made to kneel to someone—\" {aHe} step{aVs} closer. \"Where are you from? What do you want?\"" } },
    { when: { soupChoice: "ask" },
      text: { zh: a3ZhSoup.ask + a3ZhKeeper,
              en: "She describes the fire the way one describes a person: which house burned first, which alley the fire did not reach, how the smoke moved. After a while the story stops belonging to you at all. \"Enough,\" she says. \"Drink your soup.\"\n\nThe shrine door is locked, but light comes through under it. The keeper is inside, and {aHe} {aIs} still waiting — or perhaps waiting is the one thing {aHe} {aIs} truly good at. Before you finish the steps the door opens, and {aHe} {aIs} in the doorway with {aHis} hands full — a candlestick in one, a polishing cloth in the other. You notice, not for the first time, that {aHe} never wear{aVs} a sword. Never.\n\n\"By morning, the last of them will be at the shrine — the ones whose names are actually on the family writ,\" {aHe} say{aVs}. \"Every time I close my eyes I see your face in the stone, and your body standing beneath it.\" {aHe} set{aVs} down the candlestick. This is the calmest you have ever seen {aHim}, and the calm ones are the dangerous kind.\n\n\"So before they come, before I am made to kneel to someone—\" {aHe} step{aVs} closer. \"Where are you from? What do you want?\"" } },
    { text: { zh: a3ZhKeeper, en: "The shrine door is locked, but light comes through under it. The keeper is inside, and {aHe} {aIs} still waiting — or perhaps waiting is the one thing {aHe} {aIs} truly good at. Before you finish the steps the door opens, and {aHe} {aIs} in the doorway with {aHis} hands full — a candlestick in one, a polishing cloth in the other. You notice, not for the first time, that {aHe} never wear{aVs} a sword. Never.\n\n\"By morning, the last of them will be at the shrine — the ones whose names are actually on the family writ,\" {aHe} say{aVs}. \"Every time I close my eyes I see your face in the stone, and your body standing beneath it.\" {aHe} set{aVs} down the candlestick. This is the calmest you have ever seen {aHim}, and the calm ones are the dangerous kind.\n\n\"So before they come, before I am made to kneel to someone—\" {aHe} step{aVs} closer. \"Where are you from? What do you want?\"" } }
  ],
  choices: [
    { text: { zh: "“从山口那边来的。雇佣兵。这张脸只是碰巧——我编了个故事，仅此而已。”",
              en: "\"From the far side of the pass. A sellsword. The resemblance is coincidence — I made up a story, that's all.\"" },
      set: { keeperAsk: "lie", keeperLied: true }, next: "a3b" },
    { text: { zh: "“我想看看，你们家到底在守着什么。”",
              en: "\"I want to see what your family is really guarding.\"" },
      set: { keeperAsk: "truth", aHeart: true }, next: "a3b" },
    { text: { zh: "什么也别说。让{aHim}自己走进这片沉默。",
              en: "Say nothing. Let {aHim} walk into the silence alone." },
      set: { keeperAsk: "silence" }, next: "a3b" }
  ]
});

// a3b 正文（擦像完整段，供 keeperLied 变体拼接）
const a3bZhBody =
  "你走下祠堂台阶时，守祠人果然就在你料想的地方，跪在雕像下的石板上，手里拿着布，把底座擦得在灯下发亮。六十年来一直都是这样，石板上跪过的地方，已经磨得比别处浅了一层。\n\n祷词随着动作一同从{aHis}喉咙里流出来，只发出一半的声音，就像一个早就不指望有人在听的人在祷告：“火中的圣者。折断火焰之臂者。世界的守护者……”\n\n你站在门口，而你自己的脸，正从高处俯视着你。";
const a3bEnBody =
  "You come down the shrine steps and find the keeper where the keeper " +
  "always is: on the flagstones below the statue, rag in hand, working " +
  "the pedestal clean by lamplight. Sixty years of this. The stone has " +
  "gone pale in the shape of two knees.\n\n" +
  "The prayer comes out with the work, half-voiced, the way prayers are " +
  "said when the one praying has stopped expecting an audience: \"Saint " +
  "of the fire. Arm that broke the flame. Keeper of the kept world...\"\n\n" +
  "You stand in the doorway. Your own face looks down at you.";

// a3 keeperLied（「雇佣兵」谎）的回收句，接在页尾
const a3bZhLie =
  "\n\n你那句“雇佣兵”还悬在祠堂的夜气里，守祠人却没有接。\n\n这类人从不当场戳穿，他们会把话像证物一样收好，留到审得动它的那一夜。";
const a3bEnLie =
  "\n\nYour \"sellsword\" still hangs in the shrine's night air. The keeper " +
  "never picked it up — this kind never unmasks anyone on the spot. They " +
  "store it away, like evidence, for the night it can be weighed.";

// ============================================================
//  a3b · 擦像（桥段#10 晚祷内核：祷文含「屠龙圣徒」；
//  aHeart 的第二来源＝沉默接过抹布）
// ============================================================
EVENTS.push({
  id: "a3b",
  title: { zh: "擦拭", en: "The Polishing" },
  text: [
    { when: { keeperLied: true },
      text: { zh: a3bZhBody + a3bZhLie,
              en: "You come down the shrine steps and find the keeper where the keeper always is: on the flagstones below the statue, rag in hand, working the pedestal clean by lamplight. Sixty years of this. The stone has worn thin in the shape of two knees.\n\nThe prayer comes out of {aHis} throat with the work, half-voiced, the way prayers are said when the one praying has stopped expecting an audience: \"Saint of the fire. Arm that broke the flame. Keeper of the kept world...\"\n\nYou stand in the doorway. Your own face looks down at you.\n\nYour \"sellsword\" still hangs in the shrine's night air. The keeper never picked it up — this kind never unmasks anyone on the spot. They store it away, like evidence, for the night it can be weighed." } },
    { text: { zh: a3bZhBody, en: "You come down the shrine steps and find the keeper where the keeper always is: on the flagstones below the statue, rag in hand, working the pedestal clean by lamplight. Sixty years of this. The stone has worn thin in the shape of two knees.\n\nThe prayer comes out of {aHis} throat with the work, half-voiced, the way prayers are said when the one praying has stopped expecting an audience: \"Saint of the fire. Arm that broke the flame. Keeper of the kept world...\"\n\nYou stand in the doorway. Your own face looks down at you." } }
  ],
  choices: [
    { text: { zh: "你跟着{aHim}一起念。每个字都落在它该落的地方。",
              en: "You say it with {aHim}. Every word, in its right place." },
      set: { legendHard2: true }, next: "a4" },
    { text: { zh: "你跪下来，从{aHis}手里接过布。石头需要的是手，不是话。",
              en: "You kneel and take the rag from {aHis} hands. The stone needs " +
                  "hands more than it needs words." },
      set: { aHeart: true }, next: "a4" },
    { text: { zh: "“那不是——”你把后半句咽了回去。祷词里的圣者，从来就不是什么圣者。",
              en: "\"That's not—\" You swallow the rest. The saint in the prayer " +
                  "was never a saint." },
      set: { legendCrack1: true }, next: "a4" }
  ]
});

// ============================================================
//  a4 · 歌手的新词（前接守祠人质问；质问选择变体）
// ============================================================
EVENTS.push({
  id: "a4",
  title: { zh: "歌手的新词", en: "The Singer's New Verse" },
  text: [
    // legendCrack1 已裂（e02c/ch2a/a3b 任一来源）：歌手问句后追加裂缝档位句
    { when: { keeperAsk: "lie", legendCrack1: true },
      text: { zh: a4ZhKeeper.lie + a4ZhSinger + "\n\n" + a4ZhCrack,
              en: "{aHis} face does not move. \"Sixty years, and any number have tried to pass themselves off as the hero,\" {aHe} say{aVs}. \"My family buried several who tried.\" {aHe} pause{aVs}. \"And yet — you dare say it to the keeper's face?\"\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"\n\nBy the time these words reach your ears, some seam in you has already split open ahead of them. The seam is not deep. But the wind gets in now." } },
    { when: { keeperAsk: "truth", legendCrack1: true },
      text: { zh: a4ZhKeeper.truth + a4ZhSinger + "\n\n" + a4ZhCrack,
              en: "{aHe} laugh{aVs}, short and worn out. \"To guard the truth, I suppose. My {aGrand} built this shrine around a sword that has never cut anything.\" {aHe} gaze{aVs} at you for a long time. \"Come back when I know whether you are part of the shrine, or only wear its shape.\"\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"\n\nBy the time these words reach your ears, some seam in you has already split open ahead of them. The seam is not deep. But the wind gets in now." } },
    { when: { keeperAsk: "silence", legendCrack1: true },
      text: { zh: a4ZhKeeper.silence + a4ZhSinger + "\n\n" + a4ZhCrack,
              en: "The candle gutters. The rag in {aHis} hand twist{aVs}. \"Two days,\" {aHe} say{aVs} at last. \"If you are a fraud, leave before the service — or I will unmask you before the statue, and before everyone.\" You almost believe {aHe} mean{aVs} it kindly.\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"\n\nBy the time these words reach your ears, some seam in you has already split open ahead of them. The seam is not deep. But the wind gets in now." } },
    { when: { keeperAsk: "lie" },
      text: { zh: a4ZhKeeper.lie + a4ZhSinger,
              en: "{aHis} face does not move. \"Sixty years, and any number have tried to pass themselves off as the hero,\" {aHe} say{aVs}. \"My family buried several who tried.\" {aHe} pause{aVs}. \"And yet — you dare say it to the keeper's face?\"\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"" } },
    { when: { keeperAsk: "truth" },
      text: { zh: a4ZhKeeper.truth + a4ZhSinger,
              en: "{aHe} laugh{aVs}, short and worn out. \"To guard the truth, I suppose. My {aGrand} built this shrine around a sword that has never cut anything.\" {aHe} gaze{aVs} at you for a long time. \"Come back when I know whether you are part of the shrine, or only wear its shape.\"\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"" } },
    { when: { keeperAsk: "silence" },
      text: { zh: a4ZhKeeper.silence + a4ZhSinger,
              en: "The candle gutters. The rag in {aHis} hand twist{aVs}. \"Two days,\" {aHe} say{aVs} at last. \"If you are a fraud, leave before the service — or I will unmask you before the statue, and before everyone.\" You almost believe {aHe} mean{aVs} it kindly.\n\nAt dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"" } },
    { text: { zh: a4ZhSinger, en: "At dusk the singer finds you, ink on {bHis} fingers, a new song folded four times inside {bHis} coat.\n\n\"For the anniversary,\" {bHe} say{bVs}. \"The hero's return.\" {bHe} clear{bVs} {bHis} throat and recites it half-sung:\n\n\"The hero came down from the Tor, the burnt ground grew green once more; the villagers raised their torches to greet, and the beast lay dead at the cold hill's feet.\"\n\n{bHe} stop{bVs}. The night listens.\n\n\"It isn't true,\" {bHe} say{bVs} quietly. \"The fall is wrong, the sword is wrong. But it rhymes, and that is what they will sing.\" {bHe} look{bVs} at you. \"The true parts — what do I do with them?\"" } }
  ],
  choices: [
    { text: { zh: "“把真的部分删掉。让他们留着他们的英雄。”",
              en: "\"Cut the true parts out. Let them have their hero.\"" },
      set: { songFix: "remove" }, next: "ch3p2" },
    { text: { zh: "“把剑写对。哪怕没人注意到。”",
              en: "\"Put the sword right, even if no one notices.\"" },
      set: { songFix: "fix", legendCrack2: true, bHeart: true }, next: "ch3p2" },
    { text: { zh: "“收回去吧。我不是什么英雄。”",
              en: "\"Take it back. I'm no hero.\"" },
      set: { songFix: "takeback" }, next: "ch3p2" }
  ]
});

// ============================================================
//  a5 · 押送启程（前接歌手新词；新词选择变体）
// ============================================================
EVENTS.push({
  id: "a5",
  title: { zh: "送行", en: "The Send-off" },
  text: [
    // 守夜祷咽回（leadPray:"crack"）：鱼刺句插在歌手后果与送行之间
    { when: { songFix: "remove", leadPray: "crack" },
      text: { zh: a5ZhSong.remove + a5ZhPrayCrack + a5ZhSendoff,
              en: "{bHe} fold{bVs} the verse back into {bHis} coat. \"Then it's just a song,\" {bHe} say{bVs}. \"Songs are for comforting.\" {bHe} mean{bVs} comfort — for you, and for {bSelf}.\n\nThe fishbone from last night is still where it lodged. Halfway through \"the sword was raised\" you swallowed the rest. The village takes it for a choked-back sob and bows their heads; only you know what it actually was — one of the three lines turning into a lie, and you had spoken half of it with your own mouth.\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { when: { songFix: "fix", leadPray: "crack" },
      text: { zh: a5ZhSong.fix + a5ZhPrayCrack + a5ZhSendoff,
              en: "{bHe} stare{bVs} at you. Then, slowly, {bHe} trace{bVs} a few words in the palm of {bHis} dry hand. \"The sword that never cut,\" {bHe} whisper{bVs}. \"That will be the best line in the song, and no one will know why.\"\n\nThe fishbone from last night is still where it lodged. Halfway through \"the sword was raised\" you swallowed the rest. The village takes it for a choked-back sob and bows their heads; only you know what it actually was — one of the three lines turning into a lie, and you had spoken half of it with your own mouth.\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { when: { songFix: "takeback", leadPray: "crack" },
      text: { zh: a5ZhSong.takeback + a5ZhPrayCrack + a5ZhSendoff,
              en: "\"I know,\" {bHe} say{bVs}. The night changes. \"That's why I asked.\"\n\nThe fishbone from last night is still where it lodged. Halfway through \"the sword was raised\" you swallowed the rest. The village takes it for a choked-back sob and bows their heads; only you know what it actually was — one of the three lines turning into a lie, and you had spoken half of it with your own mouth.\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { when: { songFix: "remove" },
      text: { zh: a5ZhSong.remove + a5ZhSendoff,
              en: "{bHe} fold{bVs} the verse back into {bHis} coat. \"Then it's just a song,\" {bHe} say{bVs}. \"Songs are for comforting.\" {bHe} mean{bVs} comfort — for you, and for {bSelf}.\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { when: { songFix: "fix" },
      text: { zh: a5ZhSong.fix + a5ZhSendoff,
              en: "{bHe} stare{bVs} at you. Then, slowly, {bHe} trace{bVs} a few words in the palm of {bHis} dry hand. \"The sword that never cut,\" {bHe} whisper{bVs}. \"That will be the best line in the song, and no one will know why.\"\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { when: { songFix: "takeback" },
      text: { zh: a5ZhSong.takeback + a5ZhSendoff,
              en: "\"I know,\" {bHe} say{bVs}. The night changes. \"That's why I asked.\"\n\nThey leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } },
    { text: { zh: a5ZhSendoff, en: "They leave before dawn, when the mist still thinks it owns the valley. Mules, torches, the cage all wrapped in shadow. The whole village comes to the square in nightshirts and boots; someone drapes a cloak over your shoulders, someone presses a blessing into your hands.\n\n\"Speak the words, hero,\" the elder says. She has married half this village and buried the other half. \"The Slayer saw the last enemy die. The Slayer's face should see it once more.\"\n\nThe dragon in the cage has not looked at anyone all night. Now it looks at you, with the patience of a thing that has already reached where it wanted to go — and you alone in this square know why it looks at you like that." } }
  ],
  choices: [
    { text: { zh: "走上前，轻声说出祝福，仿佛这对你毫无代价。",
              en: "Step forward and speak the blessing softly, as if it cost you nothing." },
      set: { legendHard2: true }, next: "ch3p1" },
    { text: { zh: "“我不给货物祝福。”",
              en: "\"I don't bless cargo.\"" },
      set: { legendCrack2: true }, next: "ch3p1" },
    { text: { zh: "你亲手把符铃挂到笼子上。",
              en: "Hang a charm on the cage yourself." },
      set: { charmGiven: true }, next: "ch3p1" }
  ]
});

// ============================================================
//  B线共享正文段
// ============================================================

// b1 进入纪念堂（剑与书的共同开场）
const b1ZhEntry =
  "天黑以后，祠堂的门没有锁。\n\n守祠人有时会忘记锁门，在一个六十年没进过贼的村子里，人难免会犯这种错。你溜了进去。\n\n雕像高高地立着，石头刻成了你的脸，长剑高举；而真正的那把剑，就静静地躺在它脚下的黑丝绒架上。\n\n守祠人书桌的抽屉里，放着一本皮面的册子，那是这家人在大火那年留下的私人记录。";
const b1EnEntry =
  "After dark, the shrine's door opens. The keeper sometimes forgets to lock " +
  "it — the way people do in a village that hasn't seen a thief in sixty " +
  "years. You slip inside.\n\n" +
  "The statue towers above — your face carved in stone, sword raised. The " +
  "real sword lies quiet on a black velvet stand at its feet. You lift it.\n\n" +
  "It is lighter than it should be. You run your thumb along the edge — there " +
  "is no edge. It was never sharpened. This sword has never cut anything — " +
  "not bread, not rope, not even a dragon. Someone hammered a bar of iron " +
  "into the shape of a sword and called it holy.\n\n" +
  "In the keeper's desk drawer, a leather-bound book: the family's own " +
  "record of the year of the fire.";

// b1 剑的细节（检查过剑后拼接）
const b1ZhSword =
  "\n\n你把剑拿了起来，它比应有的分量要轻。\n\n你用拇指抹过剑刃，才发现根本没有刃，它从来没有开过锋。\n\n这把剑什么也没有砍过，没切过面包，没割过绳子，更别说是龙了。剑身是生铁，剑柄廉价，剑首也已经松动，像是孩子心目中英雄该用的兵器。有人把一根铁条敲成了剑的模样，然后宣布它是神圣的。\n\n你忍不住去想，当年握着它的人，是不是从一开始就知道这是一个谎言。";
const b1EnSword =
  "\n\nThe blade is raw iron, the hilt cheap, the pommel loose. A child's " +
  "idea of a hero's weapon. You wonder who held it, and whether they knew " +
  "it was a lie.";

// b1 书的细节（读过书后拼接）
const b1ZhBook =
  "\n\n你翻开册子，上面写着：一个陌生人从烟里走了出来，没有名字，也没写长什么样；有人递给他一把剑，他上了山，就再也没有回来。故事到此为止，剩下的，全是那首歌。";
const b1EnBook =
  "\n\nIt says a stranger walked out of the smoke. No name, no description " +
  "of his face. He was given a sword. He walked toward the mountain. He " +
  "never came back. The story ends there. The rest is song.";

// b5 黎明广场开场
const b5ZhBase =
  "天亮时，他们抬着铁笼穿过广场，雾还罩着山谷。全村人都聚在这里，穿着睡衣和靴子，有人头上还戴着昨夜宴席上的花环，所有人都怀着同一个希望：英雄说出祝福，龙就此消失，这个故事再活六十年。\n\n白发高挽的长者举起手，广场立刻安静了下来。\n\n你走上前去。\n\n那首歌是错的。此刻，你可以当着所有人的面说出真相：那把剑从来没有开过锋，那条龙早就坠落了，而所谓的英雄，不过是一个走进火里救了他们的陌生人，后来独自上山，就再也没有回来。\n\n你可以全都说出来，也可以只说到刚好让那首歌断掉的程度，留下一道谁也补不上的裂缝。";
const b5EnBase =
  "At first light they carry the cage across the square. Mist still claims " +
  "the valley. The whole village comes — nightshirts, boots, the garlands " +
  "worn at the feast, and the same hope: the hero will speak the blessing, " +
  "the dragon will vanish, and the story will live another sixty years.\n\n" +
  "The elder raises her hand, white hair coiled and pinned. The square goes silent.\n\n" +
  "You step forward.\n\n" +
  "The song is wrong. You could say it here, now, before everyone. The sword " +
  "never cut. The dragon had already fallen. The hero was a stranger who " +
  "walked into fire to save them, climbed the mountain, and never came back.\n\n" +
  "You could say all of it. Or you could say just enough to break the song — " +
  "leave a crack no one can paper over.";

// b2 开场段（至"不再唱的歌"，供三个变体共用）
const b2ZhOpen =
  "歌手在酒馆里等你，带来了一本比{bHe}自己还要老的书。\n\n这本书是从{bGrand}手里传下来的，再往前经过了多少双手，已经数不清了。书页被翻得发软，墨迹也褪成了陈茶的颜色。\n\n那首歌就写在里面，写得仓促又慌张，可那并不是村里如今唱的版本。\n\n旧版本只有两句：“英雄下了托尔岗，恶兽早已躺山冈。”\n\n不是英雄把它打落的，而是它早就落在那里了。\n\n“我{bGrand}抄下了最早的那一版，”佩兰说，“因为怕大家忘了。可大家还是忘了。后来他们改了这首歌，每一代都改一点，到最后，恶兽的坠落成了英雄的功绩，龙成了敌人。”{bHe}敲了敲书页，“这就是他们不再唱的那首歌。”";
const b2EnOpen =
  "The singer meets you at the inn with a book older than {bHe} {bIs} — " +
  "it came down from {bGrand}, and before that, the count of hands runs out. " +
  "The pages are soft from handling, the ink faded to old tea.\n\n" +
  "The song is there, scribbled and anxious. And it is not the " +
  "song the village sings now.\n\n" +
  "\"The hero came down from the high Tor,\" the old version says, " +
  "\"and the beast lay there.\"\n\n" +
  "Not where the hero struck it down — where the beast had " +
  "already fallen.\n\n" +
  "\"My {bGrand} wrote the original down,\" Perrin says, " +
  "\"because {bHe} {bWas} afraid they would forget. And they did. They " +
  "rewrote it. Each generation changed it a little, until in the " +
  "end the beast's fall became the hero's deed, and the dragon " +
  "became the enemy.\" {bHe} tap{bVs} the page. \"This is the song they " +
  "no longer sing.\"";

// b3 开场段（至"每个字都错了"，供三个变体共用）
const b3ZhOpen =
  "老兵在火堆边等你，从你下山的那天起，他就一直在等。\n\n“你回来了。”他说，这并不是问句。他斟了两杯酒，你注意到第二只杯子擦得锃亮，从你到这儿起，它就一直搁在酒壶旁边等着。“我还以为你不会真的来。”\n\n他坐了下来。火光映在他的脸上，有那么一瞬间，你几乎能看见他当年那个孩子的模样：又小又冷，躲在雨水桶里，看着村子烧起来。\n\n“我那时六岁，”他说，“也许七岁。烟太浓了，我喘不过气，就爬进桶里躲着。然后我看见了。我看见了火。我看见——有什么东西从火里走了出来。”\n\n他低头盯着手里的酒杯，过了好一会儿才开口。\n\n“不是龙，是个人，一个长着你这张脸的人。他把孩子们一个一个从火里抱了出来，又徒手把火扑灭了——我亲眼看见的，火连碰都碰不到他。然后他上了山，再然后，龙就坠落了。”\n\n说完，他抬起头看着你。\n\n“后来，他们为这件事写了一首歌，可每一句都写错了。”";
const b3EnOpen =
  "The veteran waits for you by the fire. He has been waiting " +
  "since the day you came down from the mountain.\n\n" +
  "\"You came back,\" he says. It is not a question. He pours " +
  "two cups — and the second one, you notice, is already polished. " +
  "It has been waiting by the jug since the day you came down the " +
  "mountain. \"I did not think you would.\"\n\n" +
  "He sits. The firelight catches his face, and for a moment " +
  "you see him as a child — small, cold, hiding in a rain barrel " +
  "while his village burned.\n\n" +
  "\"I was six,\" he says. \"Maybe seven. I climbed into the " +
  "barrel because the smoke was so thick I could not breathe. " +
  "Then I watched. I watched the fire. I watched — that thing " +
  "come out of it.\"\n\n" +
  "He looks at his cup.\n\n" +
  "\"Not a dragon. A man. A man with a face like yours. He " +
  "pulled the children out. He put out the fire with his bare " +
  "hands — I saw it, the flames did not touch him. Then he " +
  "walked up the mountain. And the dragon fell.\"\n\n" +
  "Now he looks at you.\n\n" +
  "\"They wrote a song about it. Got it all wrong. Every word " +
  "of it.\"";

// ============================================================
//  ch2b · 从未切割过的剑（B线入口）
// ============================================================
EVENTS.push({
  id: "ch2b",
  title: { zh: "剑上无血", en: "The Sword That Never Cut" },
  text: [
    { when: { lastLook: "sword" },
      text: { zh: b1ZhSword.slice(2), en: "\n\nYou lift it. It is lighter than it should be.\n\nYou run your thumb along the edge — there is no edge. It was never sharpened.\n\nThis sword has never cut anything — not bread, not rope, not even a dragon. The blade is raw iron, the hilt cheap, the pommel loose. A child's idea of a hero's weapon. Someone hammered a bar of iron into the shape of a sword and called it holy.\n\nYou wonder who held it, and whether they knew it was a lie." } },
    { when: { lastLook: "book" },
      text: { zh: b1ZhBook.slice(2), en: b1EnBook.slice(2) } },
    { text: { zh: b1ZhEntry, en: "After dark, the shrine's door is unlocked. The keeper sometimes forgets to lock it — the way people do in a village that hasn't seen a thief in sixty years. You slip inside.\n\nThe statue towers above — your face carved in stone, sword raised. The real sword lies quiet on a black velvet stand at its feet.\n\nIn the keeper's desk drawer, a leather-bound book: the family's own record of the year of the fire." } }
  ],
  choices: [
    { text: { zh: "查看那把剑。", en: "Examine the sword." },
      when: { swordExamined: false }, set: { swordExamined: true, lastLook: "sword" }, next: "ch2b" },
    { text: { zh: "把那本册子从头读完。", en: "Read the whole book." },
      when: { recordsRead: false }, set: { recordsRead: true, lastLook: "book" }, next: "ch2b" },
    { text: { zh: "什么也别碰。", en: "Leave nothing disturbed." },
      set: { lastLook: "" }, next: "b2" }
  ]
});

// ============================================================
//  b2 · 歌手的旧书
// ============================================================
EVENTS.push({
  id: "b2",
  title: { zh: "歌手的旧书", en: "The Singer's Old Book" },
  text: [
    { when: { inPartyB: true },
      text: { zh: b2ZhOpen +
                "\n\n佩兰翻到最后一页，指着页边一行小得很容易漏看的字，那是{bGrand}的笔迹，潦草而倾斜：“这一版换不来面包。可唱出来，不像谎话。”\n\n“就因为这一句，老人家才把它留着，”佩兰说，“我留着它，是因为我信{bGrand}。”你们把两个版本一页一页对照——旧的那版，和村里如今唱的那版。对完以后，{bHe}沉默了很久，才轻轻合上了书，就像在替一个熟睡的人带上门。",
              en: "The singer meets you at the inn with a book older than {bHe} {bIs} — it came down from {bGrand}, and before that, the count of hands runs out. The pages are soft from handling, the ink faded to old tea.\n\nThe song is there, scribbled and anxious. And it is not the song the village sings now.\n\n\"The hero came down from the Tor,\" the old version says, \"and the beast already lay on the hill.\"\n\nNot where the hero struck it down — where the beast had already fallen.\n\n\"My {bGrand} wrote the original down,\" Perrin says, \"because {bHe} {bWas} afraid they would forget. And they did. They rewrote it. Each generation changed it a little, until in the end the beast's fall became the hero's deed, and the dragon became the enemy.\" {bHe} tap{bVs} the page. \"This is the song they no longer sing.\"\n\nPerrin turns to the last page and points at a line in the margin, small enough to miss — {bGrand}'s hand, hurried, slanting: \"This version earns no bread. But sung, it does not sound like a lie.\" \"That line is why {bGrand} kept it,\" Perrin says. \"I keep it because I believed {bGrand}.\" You put the two versions against each other, front to back — {bGrand}'s, and the one the village sings. When you finish {bHe} {bIs} quiet a long time, and close{bVs} the book gently, the way you close a door on someone sleeping." } },
    { when: { recordsRead: true },
      text: { zh: b2ZhOpen +
                "\n\n“你这本和守祠人家里的记录对得上。”你说。佩兰沉默了一会儿。“那它就是真的了。”{bHe}喃喃道，与其说是对你说的，不如说是说给{bSelf}听的。",
              en: "The singer meets you at the inn with a book older than {bHe} {bIs} — it came down from {bGrand}, and before that, the count of hands runs out. The pages are soft from handling, the ink faded to old tea.\n\nThe song is there, scribbled and anxious. And it is not the song the village sings now.\n\n\"The hero came down from the Tor,\" the old version says, \"and the beast already lay on the hill.\"\n\nNot where the hero struck it down — where the beast had already fallen.\n\n\"My {bGrand} wrote the original down,\" Perrin says, \"because {bHe} {bWas} afraid they would forget. And they did. They rewrote it. Each generation changed it a little, until in the end the beast's fall became the hero's deed, and the dragon became the enemy.\" {bHe} tap{bVs} the page. \"This is the song they no longer sing.\"\n\n\"Your book matches the family's record,\" you say. {bHe} fall{bVs} quiet. \"Then it is true,\" {bHe} murmur{bVs}, more to {bSelf} than to you." } },
    { when: { swordExamined: true },
      text: { zh: b2ZhOpen +
                "\n\n你告诉{bHim}，那把剑从来没有开过锋，佩兰苦笑了一下。“我就知道。用一把根本不是用来砍东西的剑，谁也杀不了龙。”",
              en: "The singer meets you at the inn with a book older than {bHe} {bIs} — it came down from {bGrand}, and before that, the count of hands runs out. The pages are soft from handling, the ink faded to old tea.\n\nThe song is there, scribbled and anxious. And it is not the song the village sings now.\n\n\"The hero came down from the Tor,\" the old version says, \"and the beast already lay on the hill.\"\n\nNot where the hero struck it down — where the beast had already fallen.\n\n\"My {bGrand} wrote the original down,\" Perrin says, \"because {bHe} {bWas} afraid they would forget. And they did. They rewrote it. Each generation changed it a little, until in the end the beast's fall became the hero's deed, and the dragon became the enemy.\" {bHe} tap{bVs} the page. \"This is the song they no longer sing.\"\n\nYou tell {bHim} the sword was never sharp. {bHe} smile{bVs} bitterly. \"Of course not. You cannot kill a dragon with a sword that was never meant to cut.\"" } },
    { text: { zh: b2ZhOpen, en: "The singer meets you at the inn with a book older than {bHe} {bIs} — it came down from {bGrand}, and before that, the count of hands runs out. The pages are soft from handling, the ink faded to old tea.\n\nThe song is there, scribbled and anxious. And it is not the song the village sings now.\n\n\"The hero came down from the Tor,\" the old version says, \"and the beast already lay on the hill.\"\n\nNot where the hero struck it down — where the beast had already fallen.\n\n\"My {bGrand} wrote the original down,\" Perrin says, \"because {bHe} {bWas} afraid they would forget. And they did. They rewrote it. Each generation changed it a little, until in the end the beast's fall became the hero's deed, and the dragon became the enemy.\" {bHe} tap{bVs} the page. \"This is the song they no longer sing.\"" } }
  ],
  choices: [
    { text: { zh: "“给我唱那首真正的歌。”", en: "Sing me the real song." },
      set: { realSongHeard: true }, next: "b2b" },
    { text: { zh: "“他们为什么要改？”", en: "Why did they change it?" },
      next: "b2b" },
    { text: { zh: "把书带走。", en: "Take the book." },
      set: { bookTaken: true }, next: "b2b" }
  ]
});

// b2b 正文两变体（狗趴脚边／狗隔桌观望），供 bookTaken 复合变体拼接
const b2bZhDog =
  "酒馆打烊了，地也扫干净了。\n\n佩兰坐在那里，旧书摊开在唯一的一张空白页上，那是那首歌的下一节，至今还没有人敢写的那一节。“歌停在恶兽坠落的地方，”{bHe}说，“那以后全是沉默。总该有人把那段沉默写下来。”\n\n那条黄狗照例大摇大摆地闯了进来，仿佛这地方归它所有。\n\n它从门缝挤进来，绕过长凳，最后趴在了你的脚边，就像是被人专程送来的。\n\n佩兰从旧书上抬起眼睛看着它。“这条狗，”{bHe}说，“可从来没为一首歌趴下过。”\n\n那只缺了一块的耳朵轻轻抖了抖。\n\n它在等着什么，就像那张空白的书页也在等着一样。";
const b2bEnDog =
  "The inn is closed and swept. Perrin sits with the old book open " +
  "to its one blank page — the next verse, the one nobody has " +
  "dared to write. \"The song ends where the beast falls,\" " +
  "{bHe} say{bVs}. \"Everything after that has been silence. Somebody " +
  "should write what the silence was.\"\n\n" +
  "The yellow dog comes in the way it goes everywhere, as if it " +
  "owns the place — through the door gap, past the settle, and " +
  "down at your feet like something delivered. Perrin looks over " +
  "the top of the old book. \"Sixty years,\" {bHe} say{bVs}, \"and it " +
  "has never once lain down for a song.\"\n\n" +
  "The dog's ear, the torn one, flicks. It is waiting for " +
  "something — the way the blank page is waiting.";
const b2bZhPlain =
  "酒馆打烊了，地也扫干净了。\n\n佩兰坐在那里，旧书摊开在唯一的一张空白页上，那是那首歌的下一节，至今还没有人敢写的那一节。“歌停在恶兽坠落的地方，”{bHe}说，“那以后全是沉默。总该有人把那段沉默写下来。”\n\n那条黄狗只走到第二张桌子边就趴下了，把下巴搁在爪子上看着你。\n\n它离你比离谁都近，却还没有近到你希望的地步。\n\n那只缺了一块的耳朵轻轻抖了抖。\n\n它在等着什么，就像那张空白的书页也在等着一样。";
const b2bEnPlain =
  "The inn is closed and swept. Perrin sits with the old book open " +
  "to its one blank page — the next verse, the one nobody has " +
  "dared to write. \"The song ends where the beast falls,\" " +
  "{bHe} say{bVs}. \"Everything after that has been silence. Somebody " +
  "should write what the silence was.\"\n\n" +
  "The yellow dog comes as far as the second table and lies down " +
  "there, chin on its paws, watching you — closer than it goes to " +
  "anyone, farther than you would like.\n\n" +
  "The dog's ear, the torn one, flicks. It is waiting for " +
  "something — the way the blank page is waiting.";

// b2 bookTaken（把书带走）的递书回收句，接在页尾
const b2bZhHandover =
  "\n\n末了，佩兰把合上的旧书推过了桌面，就像在交还一笔收了六十年的债。“书跟人走，”{bHe}说，“跟得动它的人。”\n\n你把它接过来揣好，那页空白贴着你的胸口，就像一张还没有兑现的字据。";
const b2bEnHandover =
  "\n\nAt the end, Perrin pushes the old book across the table — closed, " +
  "like a debt handed back after sixty years. \"Books follow people,\" " +
  "{bHe} say{bVs}, \"the ones who can carry them.\" You take it and stow " +
  "it, the blank page against your chest like a note not yet redeemed.";

// ============================================================
//  b2b · 续章（桥段#7 狗命名：村口的狗进了客栈；
//  bHeart 的第二来源＝给狗起名）
// ============================================================
EVENTS.push({
  id: "b2b",
  title: { zh: "下一节", en: "The Next Verse" },
  text: [
    // bookTaken（把书带走）：页尾追加递书段
    { when: { dogStart: true, bookTaken: true },
      text: { zh: b2bZhDog + b2bZhHandover,
              en: "The inn is closed and swept. Perrin sits with the old book open to its one blank page — the next verse, the one nobody has dared to write. \"The song ends where the beast falls,\" {bHe} say{bVs}. \"Everything after that has been silence. Somebody should write what the silence was.\"\n\nThe yellow dog comes in the way it goes everywhere, as if it owns the place — through the door gap, past the settle, and down at your feet like something delivered. Perrin looks over the top of the old book. \"This dog,\" {bHe} say{bVs}, \"has never once lain down for a song.\"\n\nThe dog's ear, the torn one, flicks. It is waiting for something — the way the blank page is waiting.\n\nAt the end, Perrin pushes the old book across the table — closed, like a debt handed back after sixty years. \"Books follow people,\" {bHe} say{bVs}, \"the ones who can carry them.\" You take it and stow it, the blank page against your chest like a note not yet redeemed." } },
    { when: { bookTaken: true },
      text: { zh: b2bZhPlain + b2bZhHandover,
              en: b2bEnPlain + b2bEnHandover } },
    { when: { dogStart: true },
      text: { zh: b2bZhDog, en: "The inn is closed and swept. Perrin sits with the old book open to its one blank page — the next verse, the one nobody has dared to write. \"The song ends where the beast falls,\" {bHe} say{bVs}. \"Everything after that has been silence. Somebody should write what the silence was.\"\n\nThe yellow dog comes in the way it goes everywhere, as if it owns the place — through the door gap, past the settle, and down at your feet like something delivered. Perrin looks over the top of the old book. \"This dog,\" {bHe} say{bVs}, \"has never once lain down for a song.\"\n\nThe dog's ear, the torn one, flicks. It is waiting for something — the way the blank page is waiting." } },
    { text: { zh: b2bZhPlain, en: b2bEnPlain } }
  ],
  choices: [
    { text: { zh: "“煤球。”你挠了挠它缺了块的耳朵，“就写：有人给一条狗起了名字。”",
              en: "\"Coal.\" You scratch the torn ear. \"Write this: somebody " +
                  "gave a dog a name.\"" },
      set: { dogName: "coal", bHeart: true }, next: "b3" },
    { text: { zh: "“面包。”这笔账该清了，“就写：怪物学会了付账。”",
              en: "\"Bread.\" The account should be settled. \"Write this: the " +
                  "beast learned to pay.\"" },
      set: { dogName: "bread", bHeart: true }, next: "b3" },
    { text: { zh: "“还没起名。”名字只给留得下来的东西，“这一节，先空着吧。”",
              en: "\"No name yet.\" Names are for things that stay. \"Leave the " +
                  "verse where it is.\"" },
      next: "b3" }
  ]
});

// ============================================================
//  b3 · 老兵之火
// ============================================================
EVENTS.push({
  id: "b3",
  title: { zh: "老兵的火堆", en: "The Veteran's Fire" },
  text: [
    { when: { recordsRead: true },
      text: { zh: b3ZhOpen +
                "\n\n“守祠人家的册子上也是这么写的，”你说，“一个陌生人，没有名字。”他缓缓地点了点头。“至少还有人写下来了。我还以为，只剩我一个人记得。”",
              en: "The veteran waits for you by the fire. He has been waiting since the day you came down from the mountain.\n\n\"You came back,\" he says. It is not a question. He pours two cups — and the second one, you notice, is already polished. It has been waiting by the jug since you got here. \"I did not think you would.\"\n\nHe sits. The firelight catches his face, and for a moment you see him as a child — small, cold, hiding in a rain barrel while his village burned.\n\n\"I was six,\" he says. \"Maybe seven. I climbed into the barrel because the smoke was so thick I could not breathe. Then I watched. I watched the fire. I watched — that thing come out of it.\"\n\nHe stares down at the cup in his hands. For a long while he says nothing.\n\n\"Not a dragon. A man. A man with a face like yours. He pulled the children out of the fire, one by one. He put out the fire with his bare hands — I saw it, the flames did not touch him. Then he walked up the mountain. And the dragon fell.\"\n\nNow he looks at you.\n\n\"They wrote a song about it. Got it all wrong. Every word of it.\"\n\n\"The family's record book says the same,\" you say. \"A stranger. No name.\" He nods slowly. \"Then at least someone wrote it down. I thought I was the only one who remembered.\"" } },
    { when: { realSongHeard: true },
      text: { zh: b3ZhOpen +
                "\n\n“旧歌里说，恶兽早就坠落了。”你说。他闭上了眼睛。“是的。早就坠落了。我看见了。那个人动身上山的时候，龙已经在往下掉了。他不是去追它。他是朝它走过去。”",
              en: "The veteran waits for you by the fire. He has been waiting since the day you came down from the mountain.\n\n\"You came back,\" he says. It is not a question. He pours two cups — and the second one, you notice, is already polished. It has been waiting by the jug since you got here. \"I did not think you would.\"\n\nHe sits. The firelight catches his face, and for a moment you see him as a child — small, cold, hiding in a rain barrel while his village burned.\n\n\"I was six,\" he says. \"Maybe seven. I climbed into the barrel because the smoke was so thick I could not breathe. Then I watched. I watched the fire. I watched — that thing come out of it.\"\n\nHe stares down at the cup in his hands. For a long while he says nothing.\n\n\"Not a dragon. A man. A man with a face like yours. He pulled the children out of the fire, one by one. He put out the fire with his bare hands — I saw it, the flames did not touch him. Then he walked up the mountain. And the dragon fell.\"\n\nNow he looks at you.\n\n\"They wrote a song about it. Got it all wrong. Every word of it.\"\n\n\"The old song says the beast had already fallen,\" you say. He closes his eyes. \"It had. I saw it. When the man started up the mountain, it was falling. He was not chasing it. He was walking toward it.\"" } },
    { text: { zh: b3ZhOpen, en: "The veteran waits for you by the fire. He has been waiting since the day you came down from the mountain.\n\n\"You came back,\" he says. It is not a question. He pours two cups — and the second one, you notice, is already polished. It has been waiting by the jug since you got here. \"I did not think you would.\"\n\nHe sits. The firelight catches his face, and for a moment you see him as a child — small, cold, hiding in a rain barrel while his village burned.\n\n\"I was six,\" he says. \"Maybe seven. I climbed into the barrel because the smoke was so thick I could not breathe. Then I watched. I watched the fire. I watched — that thing come out of it.\"\n\nHe stares down at the cup in his hands. For a long while he says nothing.\n\n\"Not a dragon. A man. A man with a face like yours. He pulled the children out of the fire, one by one. He put out the fire with his bare hands — I saw it, the flames did not touch him. Then he walked up the mountain. And the dragon fell.\"\n\nNow he looks at you.\n\n\"They wrote a song about it. Got it all wrong. Every word of it.\"" } }
  ],
  choices: [
    { text: { zh: "“那个人后来怎么样了？”", en: "What happened to the man?" },
      set: { soldierTruth: true }, next: "b4" },
    { text: { zh: "“你为什么从没告诉过别人？”", en: "Why didn't you tell anyone?" },
      set: { b3Ask: "why" }, next: "b4" },
    { text: { zh: "“谢谢你告诉我。”", en: "Thank you for telling me." },
      set: { b3Ask: "thanks" }, next: "b4" }
  ]
});

// ============================================================
//  b4 · 守祠人档案
// ============================================================
// S7 桥接（回声工单）：上一页 b3 讲述收尾认领；凑数工单后仅作 b4 兜底条目（why＋防御）用
const b4ZhBridge = "老兵没有回答，只把那只擦亮的杯子朝你推近了一寸，自己望着火，一直坐到酒凉。\n\n";
// b4 正文抽常量（凑数工单）：body2＝公共正文；body1＝body2＋soldierTruth 末段
const b4ZhBody2 =
  "守祠人在{aHis}书房里找到了你，{aHe}并不意外，只是有些疲惫。\n\n“你挖得够深了。”{aHe}说，这并不是问句。\n\n{aHe}走到柜子前，取出一捆信，信纸的边缘已经泛黄，捆信的绳子也早已褪了色。\n\n{aHe}把信放在了你们之间的桌上。\n\n“这是我{aGreat}留下的。大火那年的信。”\n\n第一封：一个陌生人走进了燃烧的村子，不肯离开。\n第二封：他徒手扑灭了火，火焰碰不到他。\n第三封：他上了山。龙坠落了。\n\n他再也没有回来。\n\n“我们家就在这上面盖起了一个故事，”守祠人没有看你，只是看着那些信，“一个持剑的英雄，一场单枪匹马的屠龙。六十年来，整个村子都靠着它过活，我们家也是。”\n\n说着，{aHe}透过窗子望向那座雕像，望向那张刻在石头里、本该属于你的脸。\n\n“可那个陌生人手里根本没有剑，而那条龙，也早就坠落了。”";
const b4ZhBody1 = b4ZhBody2 +
  "\n\n“老兵看见了，”你说，“他看见那个人走进了火里。”守祠人攥紧了手里的信。“我知道，”{aHe}说，“老兵告诉过我{aGrand}。而我{aGrand}叫他把这事忘了。”";
const b4EnBody2 =
  "The keeper finds you in {aHis} study. {aHe} {aIs} not surprised, " +
  "only tired.\n\n" +
  "\"You've been digging deep,\" {aHe} say{aVs}. Not a question.\n\n" +
  "{aHe} walk{aVs} to a cabinet and take{aVs} out a bundle of " +
  "letters, yellowed at the edges, bound with a cord that looks " +
  "older than the village itself. {aHe} lay{aVs} them on the " +
  "table between you.\n\n" +
  "\"These are from my {aGreat}. The year of the fire.\"\n\n" +
  "First letter: a stranger walked into the burning village and " +
  "would not leave.\n" +
  "Second: he put out the fire with his hands. The flames did " +
  "not touch him.\n" +
  "Third: he went up the mountain. The dragon fell. He never " +
  "came back.\n\n" +
  "\"My family built a story on top of it,\" the keeper says. " +
  "{aHe} {aIs} not looking at you, but at the letters. \"A hero " +
  "with a sword. A dragon he slew single-handed. It has fed us " +
  "for sixty years. The whole village lives on it.\"\n\n" +
  "{aHe} look{aVs} up through the window at the statue — your " +
  "face, carved in stone.\n\n" +
  "\"But the stranger had no sword. And the dragon had already " +
  "fallen.\"";
const b4EnBody1 = b4EnBody2 +
  "\n\n\"The veteran saw it,\" you say. \"He saw the man walk into " +
  "the fire.\" The keeper grips the letters. \"I know,\" {aHe} " +
  "say{aVs}. \"The veteran told my {aGrand}. My {aGrand} told " +
  "the veteran to forget.\"";
EVENTS.push({
  id: "b4",
  title: { zh: "守祠人的档案", en: "The Keeper's Archive" },
  text: [
    { when: { soldierTruth: true },
      // 凑数工单 B3-truth：b3 ①追问下落的落点认领，替换 S7 桥接（修复「老兵没有回答」矛盾）
      text: { zh: "老兵答得很短：“上了山，再没下来。”说完，他把杯里的酒一口喝干，望着火，再也没有开口。\n\n" + b4ZhBody1,
              en: "The veteran answers shortly. \"He went up the mountain. He never came down.\" He drinks the cup down in one gulp, looks into the fire, and never speaks again.\n\nThe keeper finds you in {aHis} study. {aHe} {aIs} not surprised, only tired.\n\n\"You've been digging deep,\" {aHe} say{aVs}. Not a question.\n\n{aHe} walk{aVs} to a cabinet and take{aVs} out a bundle of letters, yellowed at the edges, bound with a cord that looks older than the village itself. {aHe} lay{aVs} them on the table between you.\n\n\"These are from my {aGreat}. The year of the fire.\"\n\nFirst letter: a stranger walked into the burning village and would not leave.\nSecond: he put out the fire with his hands. The flames did not touch him.\nThird: he went up the mountain. The dragon fell. He never came back.\n\n\"My family built a story on top of it,\" the keeper says. {aHe} {aIs} not looking at you, but at the letters. \"A hero with a sword. A dragon he slew single-handed. It has fed us for sixty years. The whole village lives on it.\"\n\n{aHe} look{aVs} up through the window at the statue — your face, carved in stone.\n\n\"But the stranger had no sword. And the dragon had already fallen.\"\n\n\"The veteran saw it,\" you say. \"He saw the man walk into the fire.\" The keeper grips the letters. \"I know,\" {aHe} say{aVs}. \"The veteran told my {aGrand}. My {aGrand} told the veteran to forget.\"" } },
    // 凑数工单 B3-thanks：b3 ③道谢的落点认领；英文留待翻译阶段
    { when: { b3Ask: "thanks" },
      text: { zh: "“谢什么。”老兵摆了摆手，却还是把那只擦亮的杯子朝你推近了一寸，“这件事我揣了六十年，今晚总算有人肯听到底。”\n\n" + b4ZhBody2,
              en: "\"Thank me for what.\" The veteran waves it off — and still he pushes the polished cup an inch closer to you. \"I have carried this for sixty years. Tonight, at last, someone was willing to hear it to the end.\"\n\nThe keeper finds you in {aHis} study. {aHe} {aIs} not surprised, only tired.\n\n\"You've been digging deep,\" {aHe} say{aVs}. Not a question.\n\n{aHe} walk{aVs} to a cabinet and take{aVs} out a bundle of letters, yellowed at the edges, bound with a cord that looks older than the village itself. {aHe} lay{aVs} them on the table between you.\n\n\"These are from my {aGreat}. The year of the fire.\"\n\nFirst letter: a stranger walked into the burning village and would not leave.\nSecond: he put out the fire with his hands. The flames did not touch him.\nThird: he went up the mountain. The dragon fell. He never came back.\n\n\"My family built a story on top of it,\" the keeper says. {aHe} {aIs} not looking at you, but at the letters. \"A hero with a sword. A dragon he slew single-handed. It has fed us for sixty years. The whole village lives on it.\"\n\n{aHe} look{aVs} up through the window at the statue — your face, carved in stone.\n\n\"But the stranger had no sword. And the dragon had already fallen.\"" } },
    // 兜底＝b3 ②追问缘由（why）沿用 S7 桥接＋防御兜底
    { text: { zh: b4ZhBridge + b4ZhBody2, en: "The veteran does not answer. He only pushes the polished cup an inch closer, and looks into the fire, and sits there until the wine goes cold.\n\nThe keeper finds you in {aHis} study. {aHe} {aIs} not surprised, only tired.\n\n\"You've been digging deep,\" {aHe} say{aVs}. Not a question.\n\n{aHe} walk{aVs} to a cabinet and take{aVs} out a bundle of letters, yellowed at the edges, bound with a cord that looks older than the village itself. {aHe} lay{aVs} them on the table between you.\n\n\"These are from my {aGreat}. The year of the fire.\"\n\nFirst letter: a stranger walked into the burning village and would not leave.\nSecond: he put out the fire with his hands. The flames did not touch him.\nThird: he went up the mountain. The dragon fell. He never came back.\n\n\"My family built a story on top of it,\" the keeper says. {aHe} {aIs} not looking at you, but at the letters. \"A hero with a sword. A dragon he slew single-handed. It has fed us for sixty years. The whole village lives on it.\"\n\n{aHe} look{aVs} up through the window at the statue — your face, carved in stone.\n\n\"But the stranger had no sword. And the dragon had already fallen.\"" } }
  ],
  choices: [
    { text: { zh: "“你愿意帮我把真相告诉他们吗？”", en: "Will you help me tell them?" },
      set: { keeperAlly: true, aHeart: true }, next: "b5" },
    { text: { zh: "“你们家撒了谎。”", en: "Your family lied." },
      set: { b4Act: "accuse" }, next: "b5" },
    { text: { zh: "“我得让他们看看那把剑。”", en: "I need to show them the sword." },
      set: { b4Act: "sword" }, next: "b5" }
  ]
});

// ============================================================
//  b5 · 黎明前的广场
// ============================================================
// S8 桥接（回声工单→凑数工单改造）：b4 ①结盟＝原句；②指控／③看剑＝凑数工单新句；英文留待翻译阶段
const b5ZhBridge = "守祠人没有反驳，也没有拦你，只把那捆信重新系好，推到了桌子你这一边。";
EVENTS.push({
  id: "b5",
  title: { zh: "黎明前的广场", en: "The Square Before Dawn" },
  // 凑数工单认领：b4 三选（结盟／指控／看剑）的落点认领；防御兜底用显式条件；英文留待翻译阶段
  // stack 条目不写段尾 \n\n：引擎 join("\n\n") 自带分段，写了会产生双空行
  text: [ { stack: [
    { when: { keeperAlly: true }, text: { zh: b5ZhBridge, en: "The keeper does not argue, and does not stop you. {aHe} only tie{aVs} the bundle of letters again and slide{aVs} it across the table to your side." } },
    { when: { b4Act: "accuse" }, text: { zh: "“谎”这个字，守祠人接住了，却没有还回来。{aHe}只是把那捆信重新系好，慢慢推到了桌子你这一边，像是替整个家族，把六十年的谎一封一封地交了出去。", en: "The keeper catches the word \"lie\" and does not give it back. {aHe} only tie{aVs} the letters into their bundle again and slide{aVs} them slowly across the table to your side — as if handing over, for the whole family, sixty years of lies, one letter at a time." } },
    { when: { b4Act: "sword" }, text: { zh: "“剑就挂在祠堂里，从来没开过刃，”守祠人说，“你真要拿它给全村人看，就等于替我们家，把这句说不出口的话说完了。”", en: "\"The sword hangs in the shrine and was never sharpened,\" the keeper says. \"If you really mean to show it to the whole village, then you will be finishing, for my family, the sentence we cannot say out loud.\"" } },
    { when: { keeperAlly: false, b4Act: "" }, text: { zh: b5ZhBridge, en: "The keeper does not argue, and does not stop you. {aHe} only tie{aVs} the bundle of letters again and slide{aVs} it across the table to your side." } },   // 防御兜底
    { text: [   // 原 inPartyC 二变体，整体作为 stack 兜底条目
      { when: { inPartyC: true },
        text: { zh: b5ZhBase +
                  "\n\n笼中的龙睁开了一只眼睛，那颜色就像陈年的灯油。\n\n它也在等，而只有你知道它在等什么。",
                en: "At first light they carry the cage across the square. Mist still claims the valley. The whole village comes — nightshirts, boots, the garlands worn at the feast, and the same hope: the hero will speak the blessing, the dragon will vanish, and the story will live another sixty years.\n\nThe elder raises her hand, white hair coiled and pinned. The square goes silent.\n\nYou step forward.\n\nThe song is wrong. You could say it here, now, before everyone. The sword never cut. The dragon had already fallen. The hero was a stranger who walked into fire to save them, went up the mountain alone, and never came back.\n\nYou could say all of it. Or you could say just enough to break the song — leave a crack no one can paper over.\n\nThe dragon in the cage opens one eye. The color of old lamp oil. It is also waiting. Only you know what for." } },
      { text: { zh: b5ZhBase, en: "At first light they carry the cage across the square. Mist still claims the valley. The whole village comes — nightshirts, boots, the garlands worn at the feast, and the same hope: the hero will speak the blessing, the dragon will vanish, and the story will live another sixty years.\n\nThe elder raises her hand, white hair coiled and pinned. The square goes silent.\n\nYou step forward.\n\nThe song is wrong. You could say it here, now, before everyone. The sword never cut. The dragon had already fallen. The hero was a stranger who walked into fire to save them, went up the mountain alone, and never came back.\n\nYou could say all of it. Or you could say just enough to break the song — leave a crack no one can paper over." } }
    ] }
  ] } ],
  choices: [
    { text: { zh: "把全部真相告诉他们。", en: "Tell them everything." },
      set: { legendCrack2: true }, next: "ch3p1" },
    { text: { zh: "把那把剑拿出来，给他们看。", en: "Show them the sword." },
      set: { swordShown: true }, next: "ch3p1" },
    { text: { zh: "让龙自己开口。", en: "Let the dragon speak." },
      set: { dragonSpeaks: true }, next: "ch3p1" }
  ]
});

// ============================================================
//  C线共享正文段
// ============================================================

// c5 缠斗原因·C 的回答段（fightWhy 三变体）
const c5ZhAsk = {
  grudge: "“旧账，”它说，“地盘。那时候你们村子还没有栅栏。猎道。龙的算术很简单：低处的山谷，对高处的山口。后来火来了，逼着我们选。它选了山谷。我没有。六十年过去，算来算去，也就这么一笔。”",
  bond:   "“天气，”它说，那只灯黄色的眼睛飘向了六十年前的某处，“我们从前一起追着天气走——两道影子，乘着同一阵风。后来火来了，问我们到底是什么。结果我们是同一个问题的两个不同答案。对一对同伴来说，这是最坏的结局。也是最真的。”",
  skip:   "它没有再说下去，你也没有再问。护送队在收帐篷、套骡子，而你们之间的沉默并不空，它满得就像一阵风，托得起一对翅膀。"
};
const c5EnAsk = {
  grudge: "\"Old accounts,\" it says. \"Territory, before your village had fences. " +
          "Prey-paths. The arithmetic of dragons: the low valley against the high " +
          "passes. Then the fire came, and the fire made us choose, and it chose " +
          "the valley. I did not. Sixty years, and that is the whole of the " +
          "arithmetic.\"",
  bond:   "\"Weather,\" it says, and the lamp-eye goes somewhere sixty years away. " +
          "\"We traveled weather, once — two shadows riding one wind. Then the " +
          "fire came and asked what we were, and it turned out we were two " +
          "different answers to the same question. That is the worst thing that " +
          "can happen to a pair. It is also the truest.\"",
  skip:   "It does not ask. You do not. The sentries finish the tents, the mules " +
          "are harnessed, and the silence between you is not empty — it is full " +
          "enough to ride on."
};

// c5 启程共享段（所有变体后接）
const c5ZhDepart =
  "\n\n护送队已经在收拾行装了。不出一个钟头，铁笼就会沿着大路出发，绕过山肩，前往托尔岗顶上的黑石台地。\n\n可你有你自己上山的路。";
const c5EnDepart =
  "\n\nThe escorts are packing. The cage will be moving within the hour — up " +
  "the big road, around the mountain's shoulder, to the black stones at the " +
  "top of the Tor.\n\nYou have your own ways up.";

// c1 开场段（至烧痕描述，供 keep 三变体共用）
const c1ZhScorch =
  "你没有等到天亮。趁村子还在排练它的歌，你已经溜过最后一道栅栏，开始往山上爬，雾在你身后合拢，就像一扇关上的门。\n\n这条路比村子还要老，早在人类踏足之前，野兽就已经把它踩了出来。\n\n你的靴子轻易就找到了旧辙，轻易得过了头，仿佛这座山还记得你的形状。\n\n在高处，越过这片无名的、烧焦的山肩，托尔岗耸立在天际，那是圣山，也是歌里的那座山。歌里说，龙是从它的最高峰坠落的；歌里还说，英雄站在那座峰顶，一剑把它斩了下来。\n\n你不信那些歌，所以你才亲自来了。\n\n爬到半山腰时，你找到了第一处痕迹：岩石上有一块焦痕，老得地衣已经爬满了一半。\n\n这里烧过火，至少是六十年前，也许还要更早。\n\n你把手按了上去，石头是凉的，可你的掌心仿佛还能接住那些日子的热度。";
const c1EnScorch =
  "You do not wait for dawn. The village is still rehearsing " +
  "its songs as you round the last fence and start up the " +
  "mountain. The mist closes behind you like a door.\n\n" +
  "This path is older than the village. Animals made it before " +
  "humans ever walked it. Your boots find the ruts easily — " +
  "too easily, as if the mountain remembers your shape.\n\n" +
  "Far above you, past the shoulder of this nameless burned " +
  "slope, the Tor stands against the sky — the holy one, the " +
  "sung one. The songs say the dragon fell from its highest " +
  "peak. The songs say the hero stood atop it and struck it " +
  "down.\n\n" +
  "You do not believe the songs. So you have come to see.\n\n" +
  "Halfway up, you find the first mark: a scorch on the rock, " +
  "old enough that lichen has covered half of it. Fire burned " +
  "here. At least sixty years ago, maybe more. You lay your " +
  "hand on it. The stone is cold, but your palm seems to feel " +
  "the heat that was once there.";

// c2 开场段（至灼痕线描述，供变体共用）
const c2ZhScorch =
  "崖壁陡直，通体漆黑，一道道陈年的矿脉远远看去，就像凝固的血，走近了，真正的痕迹才显露出来。若是从你身后的山谷里、从磨坊那方小小的院子仰望，这面石壁一定像是世界的尽头，可从来没有哪首歌唱过它的名字。\n\n石头上有刻痕，是爪痕，而且不是一组，是两组：一组更大、更深，是撕扯留下的；另一组更小、更利，是击打留下的。\n\n这里打过一场仗，打仗的是两条龙。不是英雄和龙，是两条龙。\n\n你顺着沟壑下到崖底，那里岩石碎裂，地面塌陷成了一个浅坑。曾经有什么东西坠落在这里，撞击震裂了基岩，如今裂缝里长出了一棵树，已经六十岁了。\n\n坑底的苔藓里半埋着一片鳞，已经褪了色，黯淡得像一堆熄灭的火。\n\n它褪色的样子，和你隔着铁栏看到的那些鳞一模一样，有那么一瞬间，你几乎以为它是笼中那条龙的。可当你把它握进手里，手指却推翻了眼睛：这是你的，左肩，第三排。\n\n这座山替你把证据保管了六十年，只等那个读得懂它的人回来。\n\n然而不止这些。在更高处，崖壁与天空相接的地方，还有另一道不同的痕迹：一道笔直的焦痕，像是有什么东西一路燃烧着坠了下来。\n\n那不是吐息留下的火，而是别的东西，更烫的东西。";
const c2EnScorch =
  "The cliff face is vertical and black, streaked with old " +
  "mineral stains that look like dried blood from a distance. " +
  "Up close, the real marks show. From the mill's little yard " +
  "in the valley behind you, this wall of stone must look like " +
  "the end of the world. No song has ever named it.\n\n" +
  "There are scores in the stone. Claw marks. Not one set, but " +
  "two. One larger, deeper, as if something raked. The other " +
  "smaller, sharper, as if something struck.\n\n" +
  "Two dragons fought here. Not hero and dragon — two dragons.\n\n" +
  "You follow the gully down to the cliff's base, where the " +
  "rock is broken and the ground dips into a shallow crater. " +
  "Something fell here. The impact cracked the bedrock. Now a " +
  "tree grows from the crack, sixty years old.\n\n" +
  "At the bottom of the crater, half-buried in moss, there is " +
  "a scale — faded, dull as a fire gone out. Faded like the " +
  "ones you saw through the bars of the cage, yes; for one " +
  "heartbeat you nearly file it under that. Then your fingers " +
  "close around it, and your fingers overrule your eyes: " +
  "yours. Off your own left shoulder, third row. The mountain " +
  "kept your evidence for sixty years, waiting for the only " +
  "witness who could read it.\n\n" +
  "But there is something else — higher up, where cliff meets " +
  "sky, a different mark on the rock. A linear scorch, as if " +
  "something burned as it fell. Not a fireblast. Something " +
  "else. Hotter.";

// c3 开场段（至"冒着火海"，供变体共用）
const c3ZhOpen =
  "天亮时，你回到了铁笼边，士兵们刚吃完早饭。龙醒着，它一直在等你。\n\n“你回来了，”它说，声音依旧像是从地底传来的，“我就知道你会回来。悬崖从不轻易交出它的秘密。”\n\n你把看到的一切都告诉了它：爪痕，两组，那个坑，还有鳞片。\n\n随后是一阵沉默，铁栏上的符铃映着光，轻轻叮当作响。\n\n“那天，我想让山谷烧起来，”它说，眼睛一眨不眨地盯着火，“另一个想救他们——就是被那首歌唱成英雄的那一个。那首歌什么都唱反了。我们在托尔岗上空交手。我输了，带着伤往西逃。”\n\n“另一个把整场火吞进了自己身体里，用自己闷死了那场火。那份重量把它拖过山的另一侧，越过这道悬崖，坠进山腹的黑暗里。它在那儿睡了六十年。”\n\n“我回来了，守着那片地，像守一笔旧债。两个星期前，带锁链的人来了，挖开地面，没找到睡着的那个，倒找到了我。于是我在笼子里待了两个星期，什么也没干，光顾着惊叹自己的好运气。这就是全部真相，两脚龙。那首歌只唱对了那座山，别的全错了。”\n\n它用那双灯黄色的眼睛看着你。\n\n“你当时也在。我记得那个形状。它把孩子们从燃烧的房子里抱出来时，戴的就是这张脸——就是你现在戴的这张，连望着火光时微微眯眼的样子都一样。它先用自己的双手，把他们一个一个抱出来。然后，它换上另一副形状，上山来追我。托尔岗上空从来就容不下我们两个。”";
const c3EnOpen =
  "You find the cage at dawn, just as the guards finish " +
  "breakfast. The dragon is awake. It has been waiting.\n\n" +
  "\"You came back,\" it says. The voice comes from underground. " +
  "\"I knew you would. Cliffs do not give up their secrets " +
  "easily.\"\n\n" +
  "You tell it what you found. Claw marks. Two sets. The " +
  "crater. The scale.\n\n" +
  "Silence. The charms on the cage bars tick and glint.\n\n" +
  "\"I wanted the valley to burn,\" it says, and the firelight " +
  "does not flinch. \"The other — the one the song insists on " +
  "calling the hero, because the song was always going to get " +
  "it backwards — the other wanted them saved. We fought above " +
  "the Tor. I lost. I went west with my wounds. And it: it " +
  "took the whole fire into its own body to kill it, and the " +
  "weight of the killing brought it down the far side, past " +
  "this cliff, into the dark under the mountain. It slept " +
  "there, sixty years. I came back to that ground and kept it, " +
  "like a debt-keeper. Two weeks ago the men with the chains " +
  "came, and dug, and found me instead of the sleeper — and I " +
  "have had two weeks of cage-nights to wonder at my luck. That " +
  "is the whole of it, soft-foot. The song has the right " +
  "mountain and nothing else.\"\n\n" +
  "It looks at you with its lamp-yellow eyes.\n\n" +
  "\"You were there. I remember the shape. The face it wore, " +
  "carrying the children out of the burning houses — the face " +
  "you are wearing right now, down to the way it squints at " +
  "firelight. First it brought them out, one by one, with its " +
  "own hands. Then it went up the mountain after me, wearing " +
  "another shape entirely, and the sky over the Tor was not " +
  "big enough for both of us.\"";

// （c5 旧巢／山脊段已随 C 线修订并入启程段与第三章入口，2026-10）

// ============================================================
//  ch2c · 夜间出发（C线入口）
// ============================================================
EVENTS.push({
  id: "ch2c",
  title: { zh: "夜行开始", en: "Departure by Night" },
  text: [
    { when: { keep: "arrow" },
      text: { zh: c1ZhScorch +
                "\n\n你肩胛下的那支断箭忽然发起烫来。\n\n你把它取出来一比，岩石上的焦痕和箭上的烧痕正好对得上。就是在这里发生的。",
              en: c1EnScorch +
                  "\n\nThe broken arrow under your shoulder blade seems to warm. " +
                  "You pull it out. The scorch on the rock matches the scorch " +
                  "on the arrow. It happened here." } },
    { when: { keep: "ring" },
      text: { zh: c1ZhScorch +
                "\n\n那枚银戒抵着你的锁骨，你记起了一只小手、一次坠落和一声尖叫。就是这片山坡，银戒就是在这里滑落的。",
              en: "You do not wait for dawn. The village is still rehearsing its songs as you round the last fence and start up the mountain. The mist closes behind you like a door.\n\nThis path is older than the village. Animals made it before humans ever walked it. Your boots find the ruts easily — too easily, as if the mountain remembers your shape.\n\nFar above you, past the shoulder of this nameless burned slope, the Tor stands against the sky — the holy one, the sung one. The songs say the dragon fell from its highest peak. The songs say the hero stood atop it and struck it down.\n\nYou do not believe the songs. So you have come to see.\n\nHalfway up, you find the first mark: a scorch on the rock, old enough that lichen has covered half of it. Fire burned here. At least sixty years ago, maybe more. You lay your hand on it. The stone is cold, but your palm seems to feel the heat that was once there.\n\nThe silver ring presses against your collarbone. You remember a small hand, a fall, a scream. This is the slope. This is where the ring came off." } },
    { when: { keep: "coin" },
      text: { zh: c1ZhScorch +
                "\n\n那枚半熔的硬币贴着你的皮肤，渐渐温热起来，你又记起了金属熔化的气味。\n\n这里的火，烫得能把银子烧软。",
              en: c1EnScorch +
                  "\n\nThe half-melted coin is warm against your skin. You " +
                  "remember the smell of it melting. The fire here was hot " +
                  "enough to bend silver." } },
    { text: { zh: c1ZhScorch, en: c1EnScorch } }
  ],
  choices: [
    { text: { zh: "继续往上爬。", en: "Keep climbing." },
      set: { onMountain: true }, next: "c2" },
    { text: { zh: "仔细查看那块焦痕。", en: "Examine the scorch mark closely." },
      set: { scorchExamined: true }, next: "c2" },
    { text: { zh: "回村子去。", en: "Return to the village." },
      next: "ch3p1" }
  ]
});

// c2 onMountain（ch2c 连夜爬山）回收句，接在既有变体尾部
const c2ZhClimb =
  "\n\n夜里剩下的那段路，你是一口气爬上来的。六十年来，这座山头一回重新认识了你的分量，不是压进石头里的鳞片，而是一双磨破了鞋底的脚。";
const c2EnClimb =
  "\n\nYou make the rest of the night's climb in one push. For the first " +
  "time in sixty years the mountain learns your weight again — not scales " +
  "pressing into stone, but a pair of feet gone through their soles.";

// ============================================================
//  c2 · 崖底
// ============================================================
EVENTS.push({
  id: "c2",
  title: { zh: "崖底", en: "The Bottom of the Cliff" },
  text: [
    { when: { scorchExamined: true, inPartyC: true },
      text: { zh: c2ZhScorch +
                "\n\n半山腰那道焦痕，和这里的线条严丝合缝。不管留下它的是什么，在撞上崖壁之前，它就已经在燃烧了。\n\n你在记忆里听见了龙的声音，那是在营地里，隔着铁栏和火光：“我不是在逃离那座山，两脚龙。我是在回去。”",
              en: "The cliff face is vertical and black, streaked with old mineral stains that look like dried blood from a distance. Up close, the real marks show. From the mill's little yard in the valley behind you, this wall of stone must look like the end of the world. No song has ever named it.\n\nThere are scores in the stone. Claw marks. Not one set, but two. One larger, deeper, as if something raked. The other smaller, sharper, as if something struck.\n\nTwo dragons fought here. Not hero and dragon — two dragons.\n\nYou follow the gully down to the cliff's base, where the rock is broken and the ground dips into a shallow crater. Something fell here. The impact cracked the bedrock. Now a tree grows from the crack, sixty years old.\n\nAt the bottom of the crater, half-buried in moss, there is a scale — faded, dull as a fire gone out. Faded like the ones you saw through the bars of the cage, yes; for one heartbeat you nearly file it under that. Then your fingers close around it, and your fingers overrule your eyes: yours. Off your own left shoulder, third row. The mountain kept your evidence for sixty years, waiting for the only witness who could read it.\n\nBut there is something else — higher up, where cliff meets sky, a different mark on the rock. A linear scorch, as if something burned as it fell. Not a fireblast. Something else. Hotter.\n\nThe scorch from halfway up the mountain matches this line. Whatever made it was already burning before it reached the cliff.\n\nYou hear the dragon's voice in memory — the camp, the bars, the firelight: \"I'm not running from the mountain, soft-foot. I'm going back to it.\"\n\nYou make the rest of the night's climb in one push. For the first time in sixty years the mountain learns your weight again — not scales pressing into stone, but a pair of feet gone through their soles." } },
    { when: { scorchExamined: true },
      text: { zh: c2ZhScorch +
                "\n\n半山腰那道焦痕，和这里的线条严丝合缝。不管留下它的是什么，在撞上崖壁之前，它就已经在燃烧了。",
              en: c2EnScorch +
                  "\n\nThe scorch from halfway up the mountain matches this line. " +
                  "Whatever made it was already burning before it reached the cliff." } },
    // 连夜爬山（onMountain）：在龙声／纯崖底变体后追加登山句
    { when: { inPartyC: true, onMountain: true },
      text: { zh: c2ZhScorch +
                "\n\n你在记忆里听见了龙的声音，那是在营地里，隔着铁栏和火光：“我不是在逃离那座山，两脚龙。我是在回去。”" + c2ZhClimb,
              en: "The cliff face is vertical and black, streaked with old mineral stains that look like dried blood from a distance. Up close, the real marks show. From the mill's little yard in the valley behind you, this wall of stone must look like the end of the world. No song has ever named it.\n\nThere are scores in the stone. Claw marks. Not one set, but two. One larger, deeper, as if something raked. The other smaller, sharper, as if something struck.\n\nTwo dragons fought here. Not hero and dragon — two dragons.\n\nYou follow the gully down to the cliff's base, where the rock is broken and the ground dips into a shallow crater. Something fell here. The impact cracked the bedrock. Now a tree grows from the crack, sixty years old.\n\nAt the bottom of the crater, half-buried in moss, there is a scale — faded, dull as a fire gone out. Faded like the ones you saw through the bars of the cage, yes; for one heartbeat you nearly file it under that. Then your fingers close around it, and your fingers overrule your eyes: yours. Off your own left shoulder, third row. The mountain kept your evidence for sixty years, waiting for the only witness who could read it.\n\nBut there is something else — higher up, where cliff meets sky, a different mark on the rock. A linear scorch, as if something burned as it fell. Not a fireblast. Something else. Hotter.\n\nYou hear the dragon's voice in memory — the camp, the bars, the firelight: \"I'm not running from the mountain, soft-foot. I'm going back to it.\"\n\nYou make the rest of the night's climb in one push. For the first time in sixty years the mountain learns your weight again — not scales pressing into stone, but a pair of feet gone through their soles." } },
    { when: { inPartyC: true },
      text: { zh: c2ZhScorch +
                "\n\n你在记忆里听见了龙的声音，那是在营地里，隔着铁栏和火光：“我不是在逃离那座山，两脚龙。我是在回去。”",
              en: "The cliff face is vertical and black, streaked with old mineral stains that look like dried blood from a distance. Up close, the real marks show. From the mill's little yard in the valley behind you, this wall of stone must look like the end of the world. No song has ever named it.\n\nThere are scores in the stone. Claw marks. Not one set, but two. One larger, deeper, as if something raked. The other smaller, sharper, as if something struck.\n\nTwo dragons fought here. Not hero and dragon — two dragons.\n\nYou follow the gully down to the cliff's base, where the rock is broken and the ground dips into a shallow crater. Something fell here. The impact cracked the bedrock. Now a tree grows from the crack, sixty years old.\n\nAt the bottom of the crater, half-buried in moss, there is a scale — faded, dull as a fire gone out. Faded like the ones you saw through the bars of the cage, yes; for one heartbeat you nearly file it under that. Then your fingers close around it, and your fingers overrule your eyes: yours. Off your own left shoulder, third row. The mountain kept your evidence for sixty years, waiting for the only witness who could read it.\n\nBut there is something else — higher up, where cliff meets sky, a different mark on the rock. A linear scorch, as if something burned as it fell. Not a fireblast. Something else. Hotter.\n\nYou hear the dragon's voice in memory — the camp, the bars, the firelight: \"I'm not running from the mountain, soft-foot. I'm going back to it.\"" } },
    { when: { onMountain: true },
      text: { zh: c2ZhScorch + c2ZhClimb,
              en: c2EnScorch + c2EnClimb } },
    { text: { zh: c2ZhScorch, en: c2EnScorch } }
  ],
  choices: [
    { text: { zh: "带走那片鳞。", en: "Take the scale." },
      set: { scaleTaken: true }, next: "c3" },
    { text: { zh: "爬得更高，去焦痕开始的地方。",
              en: "Climb higher, to where the scorch line begins." },
      set: { highClimb: true }, next: "c3" },
    { text: { zh: "下山去——笼中的龙会明白这意味着什么。",
              en: "Go back down — the dragon in the cage will know what this means." },
      next: "c3" }
  ]
});

// ============================================================
//  c3 · 笼中龙
// ============================================================
EVENTS.push({
  id: "c3",
  title: { zh: "笼中之龙", en: "The Caged Dragon" },
  text: [
    { when: { scaleTaken: true },
      text: { zh: c3ZhOpen +
                "\n\n你把鳞片从栏杆间递了过去，它只瞥了一眼，并没有伸手去接。“看来那个坑终于把证据吐出来了，”它说，“带上山去吧。\n\n那是你的肩膀，你的账本。”",
              en: "You find the cage at dawn, just as the guards finish breakfast. The dragon is awake. It has been waiting.\n\n\"You came back,\" it says. Its voice still comes from underground. \"I knew you would. Cliffs do not give up their secrets easily.\"\n\nYou tell it what you found. Claw marks. Two sets. The crater. The scale.\n\nSilence. The charms on the cage bars tick and glint.\n\n\"I wanted the valley to burn,\" it says, and the firelight does not flinch. \"The other — the one the song insists on calling the hero, because the song was always going to get it backwards — the other wanted them saved. We fought above the Tor. I lost. I went west with my wounds. And it: it took the whole fire into its own body and smothered it — and the weight of that brought it down the far side, past this cliff, into the dark under the mountain. It slept there, sixty years. I came back to that ground and kept it, like a debt-keeper. Two weeks ago the men with the chains came, and dug, and found me instead of the sleeper — and I have had two weeks of cage-nights to wonder at my luck. That is the whole of it, soft-foot. The song has the right mountain and nothing else.\"\n\nIt looks at you with its lamp-yellow eyes.\n\n\"You were there. I remember the shape. The face it wore, carrying the children out of the burning houses — the face you are wearing right now, down to the way it squints at firelight. First it brought them out, one by one, with its own hands. Then it went up the mountain after me, wearing another shape entirely, and the sky over the Tor was not big enough for both of us.\"\n\nYou hold the scale through the bars. It looks once and does not take it. \"So the crater gave up its evidence,\" it says. \"Carry it up the mountain. Your shoulder, your ledger.\"" } },
    { when: { highClimb: true },
      text: { zh: c3ZhOpen +
                "\n\n“你爬到那条线那儿去了，”它说，“那是它坠落的路径——一路燃烧，从托尔岗的山坡滑下来，直到砸进这道悬崖底下的坑里。我看着它坠下去的。六十年了，我还记得那道光。”",
              en: "You find the cage at dawn, just as the guards finish breakfast. The dragon is awake. It has been waiting.\n\n\"You came back,\" it says. Its voice still comes from underground. \"I knew you would. Cliffs do not give up their secrets easily.\"\n\nYou tell it what you found. Claw marks. Two sets. The crater. The scale.\n\nSilence. The charms on the cage bars tick and glint.\n\n\"I wanted the valley to burn,\" it says, and the firelight does not flinch. \"The other — the one the song insists on calling the hero, because the song was always going to get it backwards — the other wanted them saved. We fought above the Tor. I lost. I went west with my wounds. And it: it took the whole fire into its own body and smothered it — and the weight of that brought it down the far side, past this cliff, into the dark under the mountain. It slept there, sixty years. I came back to that ground and kept it, like a debt-keeper. Two weeks ago the men with the chains came, and dug, and found me instead of the sleeper — and I have had two weeks of cage-nights to wonder at my luck. That is the whole of it, soft-foot. The song has the right mountain and nothing else.\"\n\nIt looks at you with its lamp-yellow eyes.\n\n\"You were there. I remember the shape. The face it wore, carrying the children out of the burning houses — the face you are wearing right now, down to the way it squints at firelight. First it brought them out, one by one, with its own hands. Then it went up the mountain after me, wearing another shape entirely, and the sky over the Tor was not big enough for both of us.\"\n\n\"You climbed to the line,\" it says. \"That is the road it fell by — burning, slanting down from the Tor's side, ending in the pit below this cliff. I watched it come down. Sixty years, and I still remember the light.\"" } },
    { text: { zh: c3ZhOpen, en: "You find the cage at dawn, just as the guards finish breakfast. The dragon is awake. It has been waiting.\n\n\"You came back,\" it says. Its voice still comes from underground. \"I knew you would. Cliffs do not give up their secrets easily.\"\n\nYou tell it what you found. Claw marks. Two sets. The crater. The scale.\n\nSilence. The charms on the cage bars tick and glint.\n\n\"I wanted the valley to burn,\" it says, and the firelight does not flinch. \"The other — the one the song insists on calling the hero, because the song was always going to get it backwards — the other wanted them saved. We fought above the Tor. I lost. I went west with my wounds. And it: it took the whole fire into its own body and smothered it — and the weight of that brought it down the far side, past this cliff, into the dark under the mountain. It slept there, sixty years. I came back to that ground and kept it, like a debt-keeper. Two weeks ago the men with the chains came, and dug, and found me instead of the sleeper — and I have had two weeks of cage-nights to wonder at my luck. That is the whole of it, soft-foot. The song has the right mountain and nothing else.\"\n\nIt looks at you with its lamp-yellow eyes.\n\n\"You were there. I remember the shape. The face it wore, carrying the children out of the burning houses — the face you are wearing right now, down to the way it squints at firelight. First it brought them out, one by one, with its own hands. Then it went up the mountain after me, wearing another shape entirely, and the sky over the Tor was not big enough for both of us.\"" } }
  ],
  choices: [
    { text: { zh: "“你为什么从没告诉过任何人？”", en: "Why didn't you tell anyone?" },
      set: { dragonTruth: true }, next: "c4" },
    { text: { zh: "“那天，你为什么想让山谷烧起来？”",
              en: "That day. Why did you want the valley to burn?" },
      set: { c3Ask: "burn" }, next: "c4" },
    { text: { zh: "“谢谢你告诉我。”", en: "Thank you for telling me." },
      set: { c3Ask: "thanks" }, next: "c4" }
  ]
});

// ============================================================
//  c4 · 最后一问
// ============================================================
// c4 正文抽常量（凑数工单）：认领句前插，原文保留为兜底（防御不插）
const c4ZhOpen =
  "龙没有马上应声。\n\n它把那句话含在嘴里，就像含着一块还没凉透的炭，过了很久，才慢慢地咽了下去。\n\n它的目光追着正在收帐篷的哨兵，那是一场盛大的收尾里，那些琐碎而经久的杂活。\n\n“问吧，”它说，“这两个星期，山谷里人人都向我讨过东西，祷告、命令、价钱。或许只有你，会问出那个真正要紧的问题。”";
const c4EnOpen =
  "The dragon's eye follows the sentries folding the tents — the small, " +
  "permanent business of a large ending.\n\n" +
  "\"Ask,\" it says. \"Everyone in this valley has asked me something " +
  "these two weeks. Prayers. Orders. Prices. You are the only one who " +
  "might ask the one that matters.\"";
EVENTS.push({
  id: "c4",
  title: { zh: "最后一个问题", en: "The Last Question" },
  // 凑数工单认领：c3 三选（真相／纵火／道谢）的落点认领，前插；英文留待翻译阶段
  text: [
    { when: { dragonTruth: true },
      text: { zh: "你问完以后，它只是看着你，一直看到火堆塌下了最后一角。\n\n" + c4ZhOpen,
              en: "After you finish asking, it only looks at you, and keeps looking until the last corner of the fire falls in.\n\nThe dragon does not answer at once.\n\nIt holds the words in its mouth like a coal that has not yet cooled, and only after a long while does it swallow them, slowly.\n\nThe dragon's eye follows the sentries folding the tents — the small, permanent business of a large ending.\n\n\"Ask,\" it says. \"Everyone in this valley has asked me something these two weeks. Prayers. Orders. Prices. You are the only one who might ask the one that matters.\"" } },
    { when: { c3Ask: "burn" },
      text: { zh: "这个问题就悬在铁栏之间，龙没有躲开，只是久久地望着火，久到火堆里的火星都凉了两颗。\n\n" + c4ZhOpen,
              en: "The question hangs between the bars. The dragon does not turn from it; it only looks at the fire a long while — long enough for two of its embers to go cold.\n\nThe dragon does not answer at once.\n\nIt holds the words in its mouth like a coal that has not yet cooled, and only after a long while does it swallow them, slowly.\n\nThe dragon's eye follows the sentries folding the tents — the small, permanent business of a large ending.\n\n\"Ask,\" it says. \"Everyone in this valley has asked me something these two weeks. Prayers. Orders. Prices. You are the only one who might ask the one that matters.\"" } },
    { when: { c3Ask: "thanks" },
      text: { zh: "那个“谢”字，它收得很慢，就像在收一件从来没有人送过它的东西。\n\n" + c4ZhOpen,
              en: "The word \"thanks,\" it takes slowly, the way it would take a gift no one had ever given it.\n\nThe dragon does not answer at once.\n\nIt holds the words in its mouth like a coal that has not yet cooled, and only after a long while does it swallow them, slowly.\n\nThe dragon's eye follows the sentries folding the tents — the small, permanent business of a large ending.\n\n\"Ask,\" it says. \"Everyone in this valley has asked me something these two weeks. Prayers. Orders. Prices. You are the only one who might ask the one that matters.\"" } },
    { text: { zh: c4ZhOpen, en: "The dragon does not answer at once.\n\nIt holds the words in its mouth like a coal that has not yet cooled, and only after a long while does it swallow them, slowly.\n\nThe dragon's eye follows the sentries folding the tents — the small, permanent business of a large ending.\n\n\"Ask,\" it says. \"Everyone in this valley has asked me something these two weeks. Prayers. Orders. Prices. You are the only one who might ask the one that matters.\"" } }
  ],
  choices: [
    { text: { zh: "“我们打那一仗，只是为了算一笔旧账。债，边界，血。告诉我，从头到尾就只有这些。”",
              en: "\"We fought an old account. Debt, border, blood. Tell me that " +
                  "is all it ever was.\"" },
      set: { fightWhy: "grudge" }, next: "c5" },
    { text: { zh: "“那天之前，我们就认识。告诉我，那从来不只是仇恨。”",
              en: "\"We knew each other, before that day. Tell me it was never " +
                  "only hate.\"" },
      set: { fightWhy: "bond" }, next: "c5" },
    { text: { zh: "“别说了。有些东西，得完完整整地带上山。”",
              en: "\"Don't. Some things you carry up the mountain whole.\"" },
      set: { fightWhy: "skip" }, next: "c5" }
  ]
});

// ============================================================
//  c5 · 旧巢，或高托
// ============================================================
EVENTS.push({
  id: "c5",
  title: { zh: "旧巢，或托尔岗", en: "The Old Den, or the Tor" },
  text: [
    { when: { fightWhy: "grudge" },
      text: { zh: c5ZhAsk.grudge + c5ZhDepart, en: c5EnAsk.grudge + c5EnDepart } },
    { when: { fightWhy: "bond" },
      text: { zh: c5ZhAsk.bond + c5ZhDepart, en: c5EnAsk.bond + c5EnDepart } },
    { when: { fightWhy: "skip" },
      text: { zh: c5ZhAsk.skip + c5ZhDepart, en: "It says no more. You do not ask. The sentries are striking the tents and hitching the mules, and the silence between you is not empty — it is as full as a wind that could lift a pair of wings.\n\nThe escorts are packing. The cage will be moving within the hour — up the big road, around the mountain's shoulder, to the black stones at the top of the Tor.\n\nYou have your own ways up." } },
    { text: { zh: c5ZhDepart.trimStart(), en: c5EnDepart.trimStart() } }
  ],
  choices: [
    { text: { zh: "留在笼边。一路陪它上山。", en: "Stay by the cage. Go up with it, all the way." },
      set: { stayEnd: true }, next: "ch3p1" },
    { text: { zh: "让他们去吧。让那首歌在没有你的地方唱完。", en: "Let them go. Let the song finish without you." },
      set: { fleeEnd: true }, next: "ch3p1" },
    { text: { zh: "回村子去。他们若想要真相，就让他们去找那个还背着真相的人。",
              en: "Back to the village. If they want the truth, they can find the one " +
                  "still carrying it." },
      set: { truthEnd: true }, next: "ch3p1" },
    { text: { zh: "先回旧巢。在你的真身压进石头里的那张床上，躺最后一个钟头——然后奔跑，在路上追上他们。",
              en: "The den first. One last hour in the bed your own shape wore into " +
                  "stone — then run, and catch them on the road." },
      set: { ridgeGo: true }, next: "ch3p1" }
  ]
});