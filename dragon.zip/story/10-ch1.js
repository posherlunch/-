﻿// ============================================================
//  第一章 · 入村（e01–e07，13 个事件节点）
//  zh：谷歌翻译稿＋人工修硬伤（16 处）   en：英文原稿（待润色）
//  链式变体原则：每页只用一个维度，渲染「上一页选择的后果」，
//  正文主体共享（tail 拼接），避免组合爆炸。
//  第一章新增变量见 00-config.js。
// ============================================================

// ---------- 共享正文段（拼接用） ----------

// e02b 井边正文（前接面包摊后果段）
const e02bZhTail =
  "你打了一桶水，因为人到了井边，就该干这个。\n\n井水冰得刺骨，带着一股金属味，像是活的；桶里晃动着你选的那张脸，它看上去和你一样，对这一切都将信将疑。\n\n矮墙边有两个女人在洗衣服，说话时一点也没有压低声音。\n\n“——说是今天晌午就到。从山口一路拖过来，拖了六天。听说它在渡口弄死了两个当兵的——”\n\n“是“吃”了两个当兵的。”\n\n“没吃，莫德，剩下那点儿连一顿饭都凑不齐——”\n\n她们一瞥见你，话头就戛然而止，其中一个的话还卡在半截。\n\n那样的停顿，是一个村子在掂量，一个外人能听去多少。\n\n而她们说的那东西，此刻正锁在一只哐啷作响的铁笼里，一路朝这边而来。";
const e02bEnTail =
  "You draw water because that is what people do at wells. Cold, metallic, alive. " +
  "Your reflection wavers in the bucket — that face you chose — and looks no more " +
  "convinced than you feel.\n\n" +
  "Two women wash clothes on the low wall, and they are not quiet about it.\n\n" +
  "\"—through tomorrow, they said. Six days they've marched it from the pass. It " +
  "killed two soldiers at the crossing, they say—\"\n\n" +
  "\"It *ate* two soldiers.\"\n\n" +
  "\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\n" +
  "They see you and pause, one of them mid-sentence, the pause of a village " +
  "deciding what a stranger may hear.\n\n" +
  "Chained in iron that sings when it moves.";

// e04b 孩子游戏正文（前接纪念堂后果段）
const e04bZhTail =
  "正午的钟声敲响了，广场上的大人全都涌进了教堂，可转眼之间，孩子们又把广场填满了。\n\n最后一下钟声还没散尽，他们就已经玩起了游戏。\n\n这游戏你见过无数次，早在这个村子砌起围墙之前就见过：一个孩子扮怪物，其余的都扮英雄，而英雄的规则，无非是跑、叫，然后一拥而上。\n\n“你！”最小的那个——一个扛着比自己还高的木剑的小女孩——已经给你派好了角色，“你当龙！你得吼，还得追我们！”";
const e04bEnTail =
  "The bell rings for midday, and the square empties into church — and fills, at " +
  "once, with children.\n\n" +
  "They are playing the game before the last bell dies. You have seen games like " +
  "it since before this village had walls: one child is the beast, and everyone " +
  "else is the hero, and the rules of heroism are: run, scream, swarm.\n\n" +
  "\"You!\" The smallest one — a girl with a wooden sword taller than herself — has " +
  "appointed you. \"You're the dragon! You have to roar and chase us!\"";

// e05 扔石头段（e05 尾部共享，必须先于 e05ZhTail 定义，否则 TDZ）
const e05ZhStone =
  "“点火！就在这儿烧死它！”\n\n一个男孩爬上了井沿，不知是谁家的孩子、谁家的心头肉，十三岁，浑身都透着不容置疑的笃定。\n\n他抓起手边最硬的东西扔了出去，碰巧是一块石头，石头砸在铁栏上，发出当啷一声脆响。\n\n人群哄笑起来，士兵们无动于衷，男孩又弯腰去捡第二块。\n\n那只眼睛仍旧盯着你。";
const e05EnStone =
  "\"Torch it! Burn it here!\"\n\n" +
  "A boy has scrambled up onto the well — someone's boy, someone's " +
  "bread-and-butter, thirteen and certain — and he is throwing the hardest " +
  "thing he can find, which is a stone. It rings off the bars. The crowd " +
  "laughs, and the soldiers do nothing, and the boy picks up a second " +
  "stone.\n\n" +
  "The eye is still on you.";

// e05 押龙过境正文（前接孩子游戏后果段）
const e05ZhTail =
  "最先叫起来的是狗，全村的狗同时狂吠，仿佛整个村子突然达成了共识。\n\n紧接着是蹄声、铁环撞上木头的哐当声，还有人群朝同一个方向涌去的喧哗。\n\n你随着人流往前走，因为你知道那是什么；从在井边听到那些闲话起，你就已经知道了。\n\n他们用四头牛拉着车，把笼子拖过广场。\n\n笼子是新打的铁，挂满了叮当作响、闪闪发亮的符铃，那是用来束缚的声音，是有人精心打造出来的恐惧。而在笼子里：\n\n是鳞片，褪了色的鳞片，像一堆熄灭的余烬；是一副生来就要撑起双翼的肩膀；还有一颗不肯为人群抬起的头，仿佛它早就打定了主意，再也不为任何东西抬头。\n\n它的尾巴在身上绕了两圈，正是你从前睡觉的样子，那种蜷着的、半睡半醒的姿势，装作自己只是一件货物，却把一切都听得清清楚楚。\n\n然后，在人群的喧嚷里，它抬起了头，越过孩子们，越过长矛。\n\n它的眼睛像一盏被提进暗室的灯，径直在人群里找到了你，便再也没有移开。\n\n" + e05ZhStone;
const e05EnTail =
  "The dogs start it — all of them at once, one voice, like the village has an " +
  "opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, " +
  "all one direction, and you move too, because you know. You have known since the " +
  "well.\n\n" +
  "They bring the cage through the square on a wagon drawn by four oxen. The cage is " +
  "iron, new-forged, hung with charms that tick and shimmer when they move — the " +
  "sound of containment, of someone else's fear, well engineered. And inside it:\n\n" +
  "Scale. Faded scale, the color of a fire gone out. A shoulder built for wings. A " +
  "head that does not rise for the crowd, that has decided not to rise for " +
  "anything, and a length of tail curled twice around the body the way you yourself " +
  "once slept — the coiled not-sleep of a thing that is listening to everything " +
  "while pretending to be cargo.\n\n" +
  "Then, through the crowd's roar, it does raise its head. Past the children. Past " +
  "the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — " +
  "and stays.\n\n" + e05EnStone;

// e06 老兵火塘正文（前接押龙后果段）
const e06ZhTail =
  "今天你去了五个地方，其中三处都碰见了他。\n\n在井边、在铁笼旁、在祠堂前，你都注意到了这个老人：他腰板挺得笔直，目光就像一把掉落的叉子，总能扎在出事的地方。\n\n黄昏时分，他坐在酒馆外头，守着一堆火、一锅炖菜和两只杯子。\n\n“坐。”他对你说。那是军人的口吻，客气早就磨没了，只剩下命令。\n\n你们之间的桌上，一枚徽章靠着酒壶立着，上面是交叉的双剑，纹样古旧，划痕却比纹样还深。\n\n它和守祠人胸前那枚有点歪的徽章，原本是一对。\n\n见你注意到了，他开口道：“伊奥瑞斯家的徽章。我曾经是他们的人。大火之前是，大火之后也是。六十年前，我小得能躲进一只雨水桶里。如今，我是最后一个亲眼见过那件事的活人。”\n\n他给你斟上酒，火堆噼啪作响。\n\n“好了，我替全村问你一个问题。他们都太客气，也太害怕，不敢当面问。”\n\n他盯着你的脸看了很久。\n\n“那是谁的脸？又该配上哪个名字？”";
const e06EnTail =
  "He has been at three of the same five places you have been today. You noticed " +
  "him at the well, at the cage, at the shrine — an old man with a straight back " +
  "and eyes like a dropped fork: everywhere something happened.\n\n" +
  "At dusk he is outside the inn with a fire, a pot, and two cups, and he says, " +
  "\"Sit,\" the way soldiers say it — a courtesy worn down to an instruction.\n\n" +
  "On the table between you, knocked against the jug: a badge. Crossed sword, old " +
  "make, older scratches. A twin to the one hanging slightly crooked on the " +
  "shrine-keeper's chest.\n\n" +
  "\"Ioreth's badge,\" he says, when he sees you see it. \"I was theirs. Before the " +
  "fire, and after it. Sixty years ago I was small enough to hide in a rain barrel, " +
  "and I am the last one living who *saw*.\" He pours. The fire snaps. \"So. I'll " +
  "ask what the whole village is too polite to ask.\"\n\n" +
  "He looks at your face, and it takes him a long time.\n\n" +
  "\"Whose face is that? And what name goes with it?\"";

// e04 守祠人登场正文（前接酒馆出门后果段；A 性别未定，通篇中性指代，停在看清脸）
const e04ZhTail =
  "你到的时候，守祠人已经在那儿了。\n\n起先你把那个跪在雕像下的身影当成了乞丐，可那只手里握着的是擦拭布，而不是讨饭碗；\n\n外套下的那副肩膀也不属于穷人，而属于一个出身体面的人，只是被某种私人的责任压得又沉又歪。\n\n勤勉、整洁，还怕着某样叫不出名字的东西，这三样加起来，差不多就是这个人了。\n\n对方还没跟你说上话，你就已经从那低声的念叨里，把这三样全都听了出来。\n\n对方胸前别着一枚大得不合身的徽章，上面是屠龙者的交叉双剑，那是一整个家族的荣光，戴在这个人身上，却像是借来的。\n\n守祠人正踮着脚擦雕像的脸，小小的布在石头眉骨上画着紧密的圈，一边干活一边念叨，熟稔得像是在和一张比自己活得还久的脸说话。\n\n“——因为我不擦，谁擦？还有三天就是周年了，全家人都要回来，而且——”话说到一半，你的影子落在了大理石上，对方这才注意到你。\n\n守祠人立刻落回脚跟，就像自己哼歌时被人撞见了一样。\n\n“抱歉。”对方吸了口气，“是那张脸。人人都盯着那张脸看。”\n\n守祠人抬头望了望石像的面孔，又转过头来看你的脸。\n\n偏偏你站的角度既恰到好处，又恰恰不对。\n\n擦拭的手僵在半空。\n\n而在同一束光里，你也看清了对方的脸。";
const e04EnTail =
  "The keeper is there before you are — you assumed it was a beggar kneeling at " +
  "the statue's base, but the rag in that hand is polish, not alms, and the " +
  "shoulders under the coat are gentry shoulders, if slightly hung on their own " +
  "private weathervane of duty.\n\n" +
  "Diligent. Polished. Afraid of something the keeper can't name — that is the " +
  "whole of them in three words, and you could pick all three out of that voice " +
  "before it even speaks. On the breast, pinned slightly crooked, a badge too " +
  "big for the shoulders under it: the crossed sword of the Slaying, a family's " +
  "whole honor, worn like a borrowed thing.\n\n" +
  "The keeper is cleaning the statue's face. Up on the toes, the rag in small " +
  "circles on the stone brow — talking while working, low, familiar, someone " +
  "talking to a face known longer than their own.\n\n" +
  "\"—because if I don't, who will,\" to the mouth of the statue, \"and the " +
  "anniversary is in three days, and the whole family is coming, and—\" Then the " +
  "shadow of you lands on the marble, and is noticed.\n\n" +
  "Down off the toes, like someone caught singing.\n\n" +
  "\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The " +
  "keeper looks up at it — and then, because you are standing in exactly the " +
  "wrong light, or exactly the right one, looks at yours.\n\n" +
  "The rag stops in the air.\n\n" +
  "And by that same light, you see the face.";

// e07a 守祠人黄昏对话正文（前接老兵火塘后果段）
const e07aZhTail =
  "你在雕像脚下找到了守祠人，那是它迟早会把所有人都引去的地方。\n\n祠堂已经关门了，{aHe}却还跪在最后一点余晖里，手里的布仍在石头眉骨上画着小圈。\n\n你很快意识到，同一块地方{aHe}已经擦了好一阵子了；{aHe}不是在擦拭，而是在拖延。\n\n“三天。”守祠人没有回头，“再过三天，全家人都会到这儿。要办仪式，要摆宴席，而在宴席上，我得站起来念那段话。我九岁就开始念了。”\n\n又是一个圈，再一个。“我父亲念过。我祖父也念过。\n\n你知道我最近在想什么吗，陌生人？”\n\n{aHe}抬起头，望着那张脸，那张老老实实刻在石头里的、你自己的脸。\n\n“我总觉得它在听。”\n\n守祠人短促地笑了一声，随即又立刻收了回去。\n\n“我们家靠这个故事吃饭。靠这张脸吃饭。我还没蠢到去咬喂我的那只手。可是你——”\n\n{aHe}站起身，膝盖咯吱一响，那枚过大的徽章晃了晃才停稳。\n\n“你今天看它的样子，就像在看一张催债的单子。你到底是谁，要那样看它？”";
const e07aEnTail =
  "You find {aHim} where the statue finds everyone in the end: at its feet. The " +
  "shrine is closed for the night, but {aHe} {aIs} still there, kneeling in the " +
  "last light, and the rag is going in small circles on the stone brow, and " +
  "you realize the same square foot of face has been under that rag for some " +
  "time now. {aHe} {aIs} not cleaning. {aHe} {aIs} stalling.\n\n" +
  "\"Three days,\" {aHe} say{aVs}, without looking around. \"Then the whole family " +
  "arrives. There's a service, and a supper, and at the supper I stand up " +
  "and say the words. I have said the words since I was nine years old.\" " +
  "Circle. Circle. \"My father said them. {aHis} father's before that. You know what I keep " +
  "thinking, stranger?\"\n\n" +
  "{aHe} look{aVs} up at the face — your face, worn honest in stone.\n\n" +
  "\"I keep thinking it's listening.\"\n\n" +
  "{aHe} laugh{aVs} at {aSelf}, shortly. \"The family eats well off this story. Off " +
  "that face. I'm not such a fool as to bite the hand. But you—\" {aHe} stand{aVs}, " +
  "knees cracking; the too-big badge swings and settles. \"You looked at its " +
  "face today like a man reading a bill of debts. Who are you, to look at it " +
  "that way?\"";

// e07c 营地与初见正文
const e07cZhBody =
  "营地在最后一道栅栏外一里地，六顶帐篷围着一圈木桩，那只铁笼孤零零地待在火光里，仿佛整堆火都是为了向它赔罪才生起来的。\n\n栏杆上的符铃映着火光，轻轻叮当作响。\n\n一个哨兵咳嗽了一声，纯粹是闲出来的，近乎玩忽职守。\n\n那只眼睛睁着。它一直在等。\n\n“两脚龙。”龙开口了。它的声音与其说是从空气里传来的，不如说是从地底升起的，就像一副在煤窖里锁了六十年的喉咙。\n\n“来放我出去？全村人早就在脑子里把这出戏排练过了。”\n\n褪色的鳞片上掠过一阵涟漪，像是一声笑，又像是曾经有过笑声的地方留下的回音。\n\n“别。”";
const e07cEnBody =
  "The camp is a mile out, past the last fence: six tents, a ring of " +
  "pickets, and the cage sitting alone in the firelight like a thing the " +
  "fire was built to apologize for. The charms on the bars tick and " +
  "shimmer. Somewhere a sentry coughs, bored into carelessness.\n\n" +
  "The eye is open. It was waiting.\n\n" +
  "\"The soft-foot,\" says the dragon, and its voice comes up through the " +
  "ground more than the air, a voice kept in a coal cellar for sixty " +
  "years. \"Come to let me out? The whole village is rehearsing it.\" A " +
  "ripple goes down the faded scales — laughter, or the place where " +
  "laughter lived. \"Don't.\"";

// e07c2 去留引导正文
const e07c2ZhTail =
  "火堆噼啪作响，哨兵换了换重心，那只眼睛在火焰后面看着你，不慌不忙。\n\n六顶帐篷。一圈木桩。\n\n一条通回村子的路。";
const e07c2EnTail =
  "The fire spits. A sentry shifts his weight. The eye watches you from " +
  "the firelight, in no hurry at all.\n\n" +
  "Six tents. A ring of pickets. A road back to the village.";

// e07d 夜盘点正文
const e07dZhTail =
  "你像龙那样睡觉，也就是说，闭上眼睛，把今天听到的一切清点一遍：那首歌、那枚徽章、那些硬币，还有那道悬崖，照歌里的说法，它的位置并不对。还有面包。六十年说长不长，说短不短，长到足以把一场救援改写成一场谋杀，又短到村里最老的那个女人，还在用同一只手搅着她的汤。\n\n山坡下，村子睡在它自己的歌里。";
const e07dEnTail =
  "You sleep the way dragons sleep, which is to say: you " +
  "close your eyes and take inventory of everything " +
  "you have heard. The song. The badge. The coins. The cliff that isn't " +
  "where the song says it is. The bread. Sixty years is not so long as it " +
  "turns out — long enough for a rescue to become a murder, and short " +
  "enough that the oldest woman in the village still stirs her soup with " +
  "the same hand.\n\n" +
  "Below the hill, the village sleeps in its song.";

// e07d 认领头：上一页「龙睡在哪儿」（e07c5）的一句回声。
// 不复述选项原文与 TRAITS 面板文案，不与清点段冲突；
// C 同行者顺序＝营地回声（躺下之前）→床位认领（躺下）→龙式清点（入睡）。
const e07dZhCHead =
  "躺下之前，你又想起了营地里的那一幕：你才走出四十步，龙就沿着栏杆挪了挪身子，冲着你说：“这两个星期以来，你是这山谷里头一个跟我说话时既不祈祷、也不下令的人。”\n\n然后，它冲着你的背影又补了一句，声音不大，却刚好让你听见：“两脚龙。去问问他们，第一把火是谁点的。”\n\n";
const e07dEnCHead =
  "Before you are forty yards gone, the dragon settles its length " +
  "along the bars: \"Now that is the first thing anyone in this " +
  "valley has said to me in weeks that wasn't a prayer or an " +
  "order.\"\n\n" +
  "And then, to your back — not loudly, exactly: \"Soft-foot. Ask " +
  "them who lit the first fire.\"\n\n";
const e07dZhBed = {
  barn:   "谷仓的干草接住了你，比你想的软，也比你想的暖。",
  church: "空荡荡的教堂里只剩下圣像。\n\n你看不清它们的脸，它们也看不清你的。",
  den:    "旧巢还认得你，你把自己盘回石头上那道旧凹槽里，严丝合缝。"
};
const e07dEnBed = {
  barn:   "The barn hay catches you — softer than you remembered, and warmer.",
  church: "The empty church keeps only its saints. You can't make out their " +
          "faces, and they can't make out yours.",
  den:    "The old den still knows you — you fold yourself back into the " +
          "hollow you wore in the stone, and it fits."
};

// e07b 佩兰数硬币段（前接守祠人回答后果段）
const e07bZhTail =
  "酒馆里的人渐渐散了，好的夜晚都该这样收场。\n\n佩兰正在门边的木桶盖上数硬币，显然对这个数目不太满意。\n\n{bHe}自我介绍时是这么说的：“叫我佩兰，不叫也行，反正大家都只管我叫‘歌手’。”";
const e07bEnTail =
  "The inn empties slow, the way good nights do. Perrin — {bHe} introduce{bVs} " +
  "{bSelf} as \"Perrin, like it matters, everyone just says singer\" — " +
  "counts {bHis} coins on the barrel-head by the door, and does not look " +
  "happy with the arithmetic.";

// ============================================================
//  e01 · 下山（化形＋村口的狗）
// ============================================================
// S6 桥接（回声工单）：上一页 p4 下山三选（走/听/眨眼）共享认领，4 变体前插；英文留待翻译阶段
const e01ZhBridge = "碎石在你爪下一路滚进黑暗，山下的灯火一层一层升到眼前。\n\n";
EVENTS.push({
  id: "e01",
  title: { zh: "下山", en: "The Walk Down" },
  // 凑数工单认领：p4 下山三选（走／听／眨眼）的落点认领，插在 S6 桥接之前；英文留待翻译阶段
  // stack 条目不写段尾 \n\n：引擎 join("\n\n") 自带分段，写了会产生双空行
  text: [ { stack: [
    { when: { p4Move: "walk" }, text: { zh: "你下山的步子迈得很快，快得不像是来查一桩旧事的，倒像是在回家。", en: "You walk down the mountain quickly. Too quickly for someone come to look into an old matter — more like coming home." } },
    { when: { p4Move: "song" }, text: { zh: "你站在原地，把那支歌整整听完一节才动身。唱的人咬字含糊，可每一句都钉得很牢，这一钉，就是六十年。", en: "You stand where you are and wait out a whole verse before you move. The singer slurs his words, but every line is nailed down hard — and that nailing has held for sixty years." } },
    { when: { p4Move: "wink" }, text: { zh: "你朝那张脸缓缓眨了眨眼，然后等了一会儿。按龙的礼数，对方该眨回来才对，可石头什么也没有给你。于是你转身下了山。", en: "You blink slowly at that face, and wait. By dragon courtesy, the other should blink back. The stone gives you nothing. So you turn and go down the mountain." } },
    { text: [   // 原 claw 四变体，整体作为 stack 兜底条目
    { when: { claw: "sharp" },
      text: {
        zh: e01ZhBridge + "你还没看见村子，歌声就先传了过来。\n\n那是一个年轻人的嗓音，被酒泡得有些沙哑，唱的是那条龙，唱你的双翼、你的火焰，还有你的坠落。\n\n你一边下山一边听着，整座山也跟着你一起听。\n\n走到林子边上时，你停下了脚步。是时候披上人皮了，距离上一次这么做，已经过去了整整六十年。\n\n你想把长长的黑爪折成人的拳头，它们却不肯就范，不愿就这样被藏起来。\n\n这算不上疼，更像是被生生削去了一大截：脊柱缩短，世界骤然下沉，地面猛地朝你迎了上来，夜色也随之收窄、发灰，缩成了人的尺寸。\n\n你那只了不起的鼻子，你最引以为傲的器官，塌成了一张扁平的脸上的两个小孔。\n\n你吸了一口气，却几乎什么也闻不到，就像突然之间聋了一样。\n\n只有肩头那片松动的鳞片，你没有去动它；全身上下，只剩它还记得你的真身。\n\n你还没走进村口，一条狗就先宣告了你的到来。\n\n那是一条高大的黄狗，一只耳朵缺了一块。\n\n它拦在路中间冲你狂吠，那架势像是见过你，又像是你欠了它钱。\n\n附近的村民连头都不抬，他们早就听惯了它冲生人叫唤。\n\n可它叫的并不是生人，而是你身上早已看不见的鳞片。",
        en: "Gravel rolls away into the dark beneath your claws, and the lamplight of the village climbs into view, one tier at a time.\n\nThe song reaches you before the village does. A voice, young and cracked with ale, singing about a dragon — your wingbeats, it says, your fire, your fall. You listen on the way down, and the mountain listens with you.\n\nAt the treeline you stop. Skin, then. Sixty years since you last put one on. You fold the long black talons into human fists, and they do not want to fold.\n\nIt is not pain, exactly. It is subtraction. The spine shortens. The world drops — the grass is suddenly at your eye level, and the night goes with it, dim and gray and human. Your nose, that splendid instrument, collapses into a face with two small holes in it. When you breathe in, you get almost nothing. It is like going deaf.\n\nYou keep the loose scale at your shoulder — the one thing that still knows what you are.\n\nAt the gate, a dog announces you.\n\nIt is a big yellow beast with a torn ear, and it plants itself in the road and barks at you like it has met you before, like you owe it money. The villagers nearby don't even look up. They are used to the dog barking at strangers.\n\nBut the dog is not barking at a stranger. The dog is barking at scales." } },
    { when: { claw: "kept" },
      text: {
        zh: e01ZhBridge + "你还没看见村子，歌声就先传了过来。\n\n那是一个年轻人的嗓音，被酒泡得有些沙哑，唱的是那条龙，唱你的双翼、你的火焰，还有你的坠落。\n\n你一边下山一边听着，整座山也跟着你一起听。\n\n走到林子边上时，你停下了脚步。是时候披上人皮了，距离上一次这么做，已经过去了整整六十年。\n\n你的爪子弯进掌心，像一串你答不上来的问题。\n\n这算不上疼，更像是被生生削去了一大截：脊柱缩短，世界骤然下沉，地面猛地朝你迎了上来，夜色也随之收窄、发灰，缩成了人的尺寸。\n\n你那只了不起的鼻子，你最引以为傲的器官，塌成了一张扁平的脸上的两个小孔。\n\n你吸了一口气，却几乎什么也闻不到，就像突然之间聋了一样。\n\n只有肩头那片松动的鳞片，你没有去动它；全身上下，只剩它还记得你的真身。\n\n你还没走进村口，一条狗就先宣告了你的到来。\n\n那是一条高大的黄狗，一只耳朵缺了一块。\n\n它拦在路中间冲你狂吠，那架势像是见过你，又像是你欠了它钱。\n\n附近的村民连头都不抬，他们早就听惯了它冲生人叫唤。\n\n可它叫的并不是生人，而是你身上早已看不见的鳞片。",
        en: "Gravel rolls away into the dark beneath your claws, and the lamplight of the village climbs into view, one tier at a time.\n\nThe song reaches you before the village does. A voice, young and cracked with ale, singing about a dragon — your wingbeats, it says, your fire, your fall. You listen on the way down, and the mountain listens with you.\n\nAt the treeline you stop. Skin, then. Sixty years since you last put one on. The nails curl in your palms like questions you can't answer.\n\nIt is not pain, exactly. It is subtraction. The spine shortens. The world drops — the grass is suddenly at your eye level, and the night goes with it, dim and gray and human. Your nose, that splendid instrument, collapses into a face with two small holes in it. When you breathe in, you get almost nothing. It is like going deaf.\n\nYou keep the loose scale at your shoulder — the one thing that still knows what you are.\n\nAt the gate, a dog announces you.\n\nIt is a big yellow beast with a torn ear, and it plants itself in the road and barks at you like it has met you before, like you owe it money. The villagers nearby don't even look up. They are used to the dog barking at strangers.\n\nBut the dog is not barking at a stranger. The dog is barking at scales." } },
    { when: { claw: "dull" },
      text: {
        zh: e01ZhBridge + "你还没看见村子，歌声就先传了过来。\n\n那是一个年轻人的嗓音，被酒泡得有些沙哑，唱的是那条龙，唱你的双翼、你的火焰，还有你的坠落。\n\n你一边下山一边听着，整座山也跟着你一起听。\n\n走到林子边上时，你停下了脚步。是时候披上人皮了，距离上一次这么做，已经过去了整整六十年。\n\n磨钝的指甲轻轻敲着大腿，钝得像庄稼人的手。\n\n这算不上疼，更像是被生生削去了一大截：脊柱缩短，世界骤然下沉，地面猛地朝你迎了上来，夜色也随之收窄、发灰，缩成了人的尺寸。\n\n你那只了不起的鼻子，你最引以为傲的器官，塌成了一张扁平的脸上的两个小孔。\n\n你吸了一口气，却几乎什么也闻不到，就像突然之间聋了一样。\n\n只有肩头那片松动的鳞片，你没有去动它；全身上下，只剩它还记得你的真身。\n\n你还没走进村口，一条狗就先宣告了你的到来。\n\n那是一条高大的黄狗，一只耳朵缺了一块。\n\n它拦在路中间冲你狂吠，那架势像是见过你，又像是你欠了它钱。\n\n附近的村民连头都不抬，他们早就听惯了它冲生人叫唤。\n\n可它叫的并不是生人，而是你身上早已看不见的鳞片。",
        en: "Gravel rolls away into the dark beneath your claws, and the lamplight of the village climbs into view, one tier at a time.\n\nThe song reaches you before the village does. A voice, young and cracked with ale, singing about a dragon — your wingbeats, it says, your fire, your fall. You listen on the way down, and the mountain listens with you.\n\nAt the treeline you stop. Skin, then. Sixty years since you last put one on. Your filed nails tap against your thigh, blunt as a farmer's.\n\nIt is not pain, exactly. It is subtraction. The spine shortens. The world drops — the grass is suddenly at your eye level, and the night goes with it, dim and gray and human. Your nose, that splendid instrument, collapses into a face with two small holes in it. When you breathe in, you get almost nothing. It is like going deaf.\n\nYou keep the loose scale at your shoulder — the one thing that still knows what you are.\n\nAt the gate, a dog announces you.\n\nIt is a big yellow beast with a torn ear, and it plants itself in the road and barks at you like it has met you before, like you owe it money. The villagers nearby don't even look up. They are used to the dog barking at strangers.\n\nBut the dog is not barking at a stranger. The dog is barking at scales." } },
    { text: {
        zh: e01ZhBridge + "你还没看见村子，歌声就先传了过来。\n\n那是一个年轻人的嗓音，被酒泡得有些沙哑，唱的是那条龙，唱你的双翼、你的火焰，还有你的坠落。\n\n你一边下山一边听着，整座山也跟着你一起听。\n\n走到林子边上时，你停下了脚步。是时候披上人皮了，距离上一次这么做，已经过去了整整六十年。\n\n这算不上疼，更像是被生生削去了一大截：脊柱缩短，整个世界也随之沉了下去，你的鼻子塌成了脸上的两个小孔。\n\n你吸了一口气，却几乎什么也闻不到，就像突然之间聋了一样。\n\n你还没走进村口，一条狗就先宣告了你的到来。\n\n它冲着叫的，是你身上早已看不见的鳞片。",
        en: "Gravel rolls away into the dark beneath your claws, and the lamplight of the village climbs into view, one tier at a time.\n\nThe song reaches you before the village does. A voice, young and cracked with ale, singing about a dragon — your wingbeats, it says, your fire, your fall. You listen on the way down, and the mountain listens with you.\n\nAt the treeline you stop. Skin, then. Sixty years since you last put one on.\n\nIt is not pain, exactly. It is subtraction. The spine shortens. The world drops. Your nose collapses into a face with two small holes in it. When you breathe in, you get almost nothing. It is like going deaf.\n\nAt the gate, a dog announces you. It is barking at scales." } }
  ] } ] } ],
  choices: [
    { text: { zh: "蹲下来，把手伸给它，让它自己决定。", en: "Crouch. Hold out your hand. Let it decide." },
      set: { dogStart: true }, next: "e02" },
    { text: { zh: "和它对视，直到它先移开目光。", en: "Stare it down, until it moves first." },
      set: { e01Dog: "stare" }, next: "e02" },
    { text: { zh: "绕开它，从另一道门进村。", en: "Walk around it, and go in by the far gate." },
      set: { e01Dog: "avoid" }, next: "e02" }
  ]
});

// ============================================================
//  e02 · 面包摊（开头一句认领村口的狗：蹲下＝送到广场；
//  对视＝放行（E01-stare）／绕开＝叫声淡去。e01 是唯一前驱，兜底可放心带收梢）
// ============================================================
// 正文抽成常量，供两变体拼接
const e02ZhBody =
  "集市刚刚醒来，推车和帆布遮棚之间，摆着一整排热腾腾、香喷喷的面包，香得让人愿意拿一颗牙去换一口。\n\n而你，已经六十年没吃过东西了。\n\n面包师的妻子一边擦着手上的面粉，一边看着你穿过广场，目光始终没有离开过你。等你走到她的摊前，她开门见山地说道：\n\n“你长得像一个人。”\n\n她身后的面包还冒着热气，广场上不知哪里，一口钟懒洋洋地响了一声。";
const e02EnBody =
  "The market is just waking: carts, awnings, a wall of warm bread-smell you " +
  "would trade a tooth for. You have not eaten anything but sleep in sixty " +
  "years.\n\n" +
  "The baker's wife watches you cross the square. She watches you the whole " +
  "way, wiping flour from her hands, and when you reach her stall she says it " +
  "plainly:\n\n" +
  "\"You look like someone.\"\n\n" +
  "Behind her, the bread steams. Somewhere in the square, a bell rings once, " +
  "lazily.";
// 认领句：只写局部事实，不写「从此跟着你」（B线 b2b 与结局段另有狗戏）
const e02ZhDogCame = "那条黄狗一路把你送到了广场边上，才在一辆推车旁趴了下来。";
const e02EnDogCame =
  "The yellow dog walks you as far as the edge of the square, then flops down " +
  "beside a cart.";
const e02ZhDogFaded = "村口那阵叫声，在你身后一点一点淡了下去。";
const e02EnDogFaded =
  "Behind you, the barking at the gate thins out, little by little, and gives " +
  "up.";

EVENTS.push({
  id: "e02",
  title: { zh: "面包", en: "Bread" },
  text: [
    { when: { dogStart: true },
      text: { zh: e02ZhDogCame + "\n\n" + e02ZhBody,
              en: "The yellow dog walks you as far as the edge of the square, then flops down beside a cart.\n\nThe market is just waking: carts, awnings, and between them a whole row of bread, hot and fragrant, good enough to trade a tooth for a bite. You have not eaten anything but sleep in sixty years.\n\nThe baker's wife watches you cross the square. She watches you the whole way, wiping flour from her hands, and when you reach her stall she says it plainly:\n\n\"You look like someone.\"\n\nBehind her, the bread steams. Somewhere in the square, a bell rings once, lazily." } },
    // 凑数工单 E01-stare：对视认领句替换 faded 开场；英文留待翻译阶段
    { when: { e01Dog: "stare" },
      text: { zh: "最后还是它先移开了目光。等你从它身边走过时，它已经趴了下来，把下巴搁在爪子上，尾巴在地上扫了一下。\n\n那不是讨好，而是放行。\n\n" + e02ZhBody,
              en: "In the end it is the dog that looks away first. By the time you walk past, it has settled down, chin on its paws, tail sweeping the ground once.\n\nThat is not fawning. It is letting you through.\n\nThe market is just waking: carts, awnings, and between them a whole row of bread, hot and fragrant, good enough to trade a tooth for a bite. You have not eaten anything but sleep in sixty years.\n\nThe baker's wife watches you cross the square. She watches you the whole way, wiping flour from her hands, and when you reach her stall she says it plainly:\n\n\"You look like someone.\"\n\nBehind her, the bread steams. Somewhere in the square, a bell rings once, lazily." } },
    { text: { zh: e02ZhDogFaded + "\n\n" + e02ZhBody,
              en: "Behind you, the barking at the gate thins out, little by little, and gives up.\n\nThe market is just waking: carts, awnings, and between them a whole row of bread, hot and fragrant, good enough to trade a tooth for a bite. You have not eaten anything but sleep in sixty years.\n\nThe baker's wife watches you cross the square. She watches you the whole way, wiping flour from her hands, and when you reach her stall she says it plainly:\n\n\"You look like someone.\"\n\nBehind her, the bread steams. Somewhere in the square, a bell rings once, lazily." } }
  ],
  choices: [
    { text: { zh: "“像谁？”", en: "\"Like who?\"" },
      set: { breadResult: "who" }, next: "e02b" },
    { text: { zh: "“大家都说我像我母亲。”", en: "\"Everyone says I have my mother's face.\"" },
      set: { breadResult: "mother" }, next: "e02b" },
    { text: { zh: "“那他们看错了。”", en: "\"They'd be wrong.\"" },
      set: { breadResult: "wrong" }, next: "e02b" },
    { text: { zh: "拿一条面包，柜台上什么也不留。", en: "Take a loaf. Put nothing on the counter." },
      set: { breadResult: "took", breadShort: true }, next: "e02b" },
    { text: { zh: "把那枚半熔的硬币放在柜台上。", en: "Put the half-melted coin on the counter." },
      when: { keep: "coin" },
      set: { breadResult: "coin", sus1: true }, next: "e02b" }
  ]
});

// ============================================================
//  e02b · 井边（前接面包摊后果段）
// ============================================================
EVENTS.push({
  id: "e02b",
  title: { zh: "水井", en: "The Well" },
  text: [
    { when: { breadResult: "who" },
      text: { zh: "她皱起眉头，伸手去拿面包。“一个已经不在人世的人。”\n\n她终于开口，说完自己先笑了起来，“坐下吧，不然你要当我疯了。来块面包？”\n\n" + e02bZhTail,
              en: "She frowns, reaching for it. \"No one living,\" she says at last, and laughs at herself. \"Sit down, you'll think I'm mad. Bread?\"\n\nYou draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } },
    { when: { breadResult: "mother" },
      text: { zh: "这是你对她说的第一句话，嗓音出来得恰到好处。\n\n她笑了起来：“那看在你母亲的面子上，面包白送。拿着吧。”\n\n" + e02bZhTail,
              en: "It is the first thing you have ever said to her. Your voice comes out right. She smiles. \"Then for your mother's sake, the bread's free. Take it.\"\n\nYou draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } },
    { when: { breadResult: "wrong" },
      text: { zh: "她的笑容僵了一下。“好吧，”她说，“随你。”\n\n这一回，面包可就不是白送的了。\n\n" + e02bZhTail,
              en: "Her smile goes sideways. \"Well,\" she says. \"Suit yourself.\" The bread is not free.\n\nYou draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } },
    { when: { breadResult: "took" },
      text: { zh: "你的手习惯性地去摸银子，那还是六十年前的习惯，结果却什么也没摸到。\n\n于是你在柜台上什么也没留，拿着面包慢慢走开了，而她正看着烤炉，始终没有察觉。\n\n面包还温着。从前你从这座山谷带走过的东西，没有一样是为了吃的；只有这一条不一样，这一条，纯粹是因为饿了。\n\n" + e02bZhTail,
              en: "Your hand remembers the weight of silver from a world sixty years dead. It does not find any. You put nothing on the counter, and you walk out slow, and she is watching the ovens, and she never sees.\n\nThe loaf is still warm. Nothing you ever carried out of this valley was for eating. This one is different — this one is only hunger.\n\nYou draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } },
    { when: { breadResult: "coin" },
      text: { zh: "她把硬币翻过来，又翻回去。“你是从哪儿弄来的？”\n\n她的语气并不凶，“这是老东西了。大火那些年的。”\n\n广场上的人都在各忙各的，只是有那么几个，忙得格外大声。\n\n" + e02bZhTail,
              en: "She turns it over. Turns it again. \"Where did you get this?\" Her voice is not unkind. \"This is from before. From the fire years.\" Everyone in the square is minding their own business, and some of them are doing it loudly.\n\nYou draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } },
    { text: { zh: e02bZhTail, en: "You draw water because that is what people do at wells. Cold, metallic, alive. Your reflection wavers in the bucket — that face you chose — and looks no more convinced than you feel.\n\nTwo women wash clothes on the low wall, and they are not quiet about it.\n\n\"—they say it arrives by noon today. Six days they've dragged it from the pass. They say it killed two soldiers at the crossing—\"\n\n\"It 'ate' two soldiers.\"\n\n\"It did not eat them, Maude, there wasn't enough left to eat—\"\n\nThey see you and pause, one of them mid-sentence, the pause of a village deciding what a stranger may hear.\n\nAnd the thing they are talking about is locked in an iron cage that sings as it moves, and it is coming this way right now." } }
  ],
  choices: [
    { text: { zh: "“它在渡口干了什么？”", en: "\"What did it do at the crossing?\"" },
      set: { gossipKnown: true }, next: "e02c" },
    { text: { zh: "打你的水，什么也别说。", en: "Draw your water. Say nothing." },
      next: "e02c" },
    { text: { zh: "“谈起龙的时候，你们最好当心点。”", en: "\"You should be careful what you say about dragons.\"" },
      set: { sus1: true }, next: "e02c" }
  ]
});

// e02c 井边问答后果（gossipKnown 回收：问过渡口的玩家专属开场）
const e02cZhGossip =
  "因为在井边多问了半句，你把那段闲话的后半截也听全了：渡口、一小队押送的士兵，还有一只再也没能靠岸的渡船。\n\n两个洗衣妇都担保自己那一版才是真的，可你注意到，两个版本连月份都对不上。\n\n";
const e02cEnGossip =
  "You asked the half-question at the well, and heard the rest of it: the " +
  "crossing, the little escort of soldiers, the ferry that never came in. The " +
  "two washerwomen each vouch for her own version — and you notice the two " +
  "versions do not even agree on the month.\n\n";

// e02c 铁匠铺正文（铁匠的搭话按 keep 分派）
const e02cZhSmith = {
  arrow: "离开井边以后，你路过了铁匠铺。\n\n铁匠正坐在门口磨一把锄头，火星溅在他的靴尖上；你经过的时候，他的锤子漏了半拍。\n\n“你老去摸那边肩膀。”他盯着铁，没看你，“旧伤？——你身上有大火那年的铁锈味。村里还能认出这股味道的人，大多已经埋进土里了。”",
  ring:  "离开井边以后，你路过了铁匠铺。\n\n铁匠正坐在门口磨一把锄头，火星溅在他的靴尖上；你经过的时候，他的锤子漏了半拍。\n\n“银子。”他盯着铁说，“你领口底下藏着银子，蹭着皮肉。村里买得起银器的人家——大半也都入土了。你打哪儿来，往哪儿去？”",
  coin:  "离开井边以后，你路过了铁匠铺。\n\n铁匠正坐在门口磨一把锄头，火星溅在他的靴尖上；你经过的时候，他的锤子漏了半拍。\n\n“硬币。”他盯着铁说，“揣着钱的人走路有种架势。像来讨债的。旧债总追着旧东西跑。”他抬眼瞥了你一下，“要是大火那年的什么东西回来找人，我不拦着。只是别把我的村子再烧一回。”"
};
const e02cEnSmith = {
  arrow: "The way to the well runs past the smithy. The smith is grinding a hoe " +
         "on his doorstep, sparks kissing his boots. As you pass, his hammer " +
         "misses half a beat.\n\n" +
         "\"You keep touching that shoulder,\" he says, eyes on the iron. \"Old " +
         "wound? — You smell of fire-year rust. In this village, the ones who " +
         "could smell that are mostly underground now.\"",
  ring:  "The way to the well runs past the smithy. The smith is grinding a hoe " +
         "on his doorstep, sparks kissing his boots. As you pass, his hammer " +
         "misses half a beat.\n\n" +
         "\"Silver,\" he says, eyes on the iron. \"Something silver under that " +
         "collar, rubbing. The families here who could afford silver — most are " +
         "in the ground now. Where are you from, and where are you going?\"",
  coin:  "The way to the well runs past the smithy. The smith is grinding a hoe " +
         "on his doorstep, sparks kissing his boots. As you pass, his hammer " +
         "misses half a beat.\n\n" +
         "\"Coin,\" he says, eyes on the iron. \"People who carry money walk " +
         "like it. Debt-collector's walk. Old debts chase old things.\" He looks " +
         "up at you, once. \"Fire-year things chasing folk — I won't stand in " +
         "their way. Just don't burn my village into a second one.\""
};

// ============================================================
//  e02c · 铁匠铺（桥段#12：他嗅得出火那年的铁锈）
// ============================================================
EVENTS.push({
  id: "e02c",
  title: { zh: "铁匠", en: "The Smith" },
  text: [
    { when: { keep: "arrow", gossipKnown: true },
      text: { zh: e02cZhGossip + e02cZhSmith.arrow,
              en: "You asked the half-question at the well, and heard the rest of it: the crossing, the little escort of soldiers, the ferry that never came in. The two washerwomen each vouch for her own version — and you notice the two versions do not even agree on the month.\n\nAfter leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"You keep touching that shoulder,\" he says, eyes on the iron. \"Old wound? — You smell of fire-year rust. In this village, the ones who could smell that are mostly underground now.\"" } },
    { when: { keep: "ring", gossipKnown: true },
      text: { zh: e02cZhGossip + e02cZhSmith.ring,
              en: "You asked the half-question at the well, and heard the rest of it: the crossing, the little escort of soldiers, the ferry that never came in. The two washerwomen each vouch for her own version — and you notice the two versions do not even agree on the month.\n\nAfter leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"Silver,\" he says, eyes on the iron. \"Something silver under that collar, rubbing your skin. The families here who could afford silver — most are in the ground now. Where are you from, and where are you going?\"" } },
    { when: { keep: "coin", gossipKnown: true },
      text: { zh: e02cZhGossip + e02cZhSmith.coin,
              en: "You asked the half-question at the well, and heard the rest of it: the crossing, the little escort of soldiers, the ferry that never came in. The two washerwomen each vouch for her own version — and you notice the two versions do not even agree on the month.\n\nAfter leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"Coin,\" he says, eyes on the iron. \"People who carry money walk like it. Debt-collector's walk. Old debts chase old things.\" He looks up at you, once. \"Fire-year things chasing folk — I won't stand in their way. Just don't burn my village a second time.\"" } },
    { when: { keep: "arrow" },
      text: { zh: e02cZhSmith.arrow, en: "After leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"You keep touching that shoulder,\" he says, eyes on the iron. \"Old wound? — You smell of fire-year rust. In this village, the ones who could smell that are mostly underground now.\"" } },
    { when: { keep: "ring" },
      text: { zh: e02cZhSmith.ring, en: "After leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"Silver,\" he says, eyes on the iron. \"Something silver under that collar, rubbing your skin. The families here who could afford silver — most are in the ground now. Where are you from, and where are you going?\"" } },
    { when: { keep: "coin" },
      text: { zh: e02cZhSmith.coin, en: "After leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat.\n\n\"Coin,\" he says, eyes on the iron. \"People who carry money walk like it. Debt-collector's walk. Old debts chase old things.\" He looks up at you, once. \"Fire-year things chasing folk — I won't stand in their way. Just don't burn my village a second time.\"" } },
    { text: { zh: "离开井边以后，你路过了铁匠铺。\n\n铁匠正坐在门口磨一把锄头，火星溅在他的靴尖上；你经过的时候，他的锤子漏了半拍。\n\n他什么也没说，可你听见了那半拍。",
              en: "After leaving the well, you pass the smithy. The smith is grinding a hoe on his doorstep, sparks kissing his boots. As you pass, his hammer misses half a beat. He says nothing. But you hear the half-beat." } }
  ],
  choices: [
    { text: { zh: "取出藏在肩鳞下的东西，放到他的铁砧上，放到光里。",
              en: "Take out what rides under your shoulder scale. Lay it on his anvil. " +
                  "Let it see some light." },
      set: { legendCrack1: true, sus1: true }, next: "e03" },
    { text: { zh: "按住那片鳞，转而问他那把锄头多少钱。",
              en: "Press the scale down, and ask him the price of the hoe instead." },
      set: { sus1: true }, next: "e03" },
    { text: { zh: "换条街走。铁匠的眼睛从来不缺过路人可看。",
              en: "Take the other street. The smith's eyes are not short of passers-by." },
      next: "e03" }
  ]
});

// ---------- e03 常量：屠龙者之歌完整正文 + 铁匠亮宝后果前缀 ----------

const e03ZhBody =
  "酒馆的门敞着，歌声从里面一路淌了出来。\n\n你先认出了调子，然后才认出了词。每个山谷都有这样一支曲子，四拍子，天生就是拿来拍桌子的。\n\n你刚一走进灯光里，歌词便迎面撞了过来：\n\n“大火那年天落灰，\n恶兽扑来烈焰飞，\n烧了麦田烧谷仓，\n直到英雄提剑归——”\n\n歌手坐在凳子上，一只靴子搭着木箱，年纪很轻，手指上还沾着墨迹。\n\n拨弦的时候，那双手看都不用看，因为那双眼睛正像摇骰盅一样，把整间屋子扫了一遍又一遍。\n\n一头乱发怎么也不肯服帖，而那副嗓子，仿佛就是为这间屋子、这种麦酒量身定做的。\n\n歌手头顶的灯烧得很低，火苗一跳一跳。\n\n你身旁的醉汉把杯子往桌上一砸。“坠落！”\n\n他吼道，“唱坠落那段！”\n\n歌手咧嘴一笑，遂了他的愿：\n\n“英雄喝道：孽畜休猖狂！\n恶兽俯冲，长剑迎风扬——\n它坠落的那座山，名叫托尔岗，\n朋友们哪，它一坠再没回天上。”\n\n满屋子都炸开了，拍桌子的、跺靴跟的、喝彩的，响成一片。\n\n你站在人群里，顶着刚选好的脸和两个小小的人类鼻孔，听着一首关于你自己的歌，关于那个救了他们、却从来没有人想过要问一问的你，在吼声里唱完，又从头唱了起来。";
const e03EnBody =
  "The tavern door is open, and the song is inside it.\n\n" +
  "You know the tune before you know the words. Every valley has a tune like " +
  "this — four beats, built for pounding tables — and as you cross into the " +
  "lamplight, the words arrive:\n\n" +
  "\"In the year of the burning, the sky rained down ash,\n" +
  "and the beast came off the mountain, with fire for a lash.\n" +
  "It burned up the cornfields, it burned up the barns,\n" +
  "till a hero came walking with a sword in his arms—\"\n\n" +
  "The singer sits on a stool with one boot on a crate. Young. Ink-stained " +
  "fingers moving on the strings without looking, because the eyes are on " +
  "the room, rolling it like a dice cup. Hair that has never once " +
  "behaved. A voice built for this exact room, this exact ale.\n\n" +
  "The lamp above the stool is burning low, and its light jumps.\n\n" +
  "The drunk beside you slams his cup. \"The fall!\" he bellows. \"Give us the " +
  "fall!\"\n\n" +
  "And the singer grins, and gives them the fall:\n\n" +
  "\"And the hero said, beast, you have burned your last barn,\n" +
  "and the beast came down hungry, and the sword went up—\n" +
  "and the mountain it fell from was called the High Tor,\n" +
  "and it fell, good people, it fell ever more.\"\n\n" +
  "They thunder. Tables. Boots. You stand in the middle of it with your new " +
  "face and your two small nose-holes, and the song about you — the you that " +
  "saved them, the you they never asked — finishes to a roar, and starts " +
  "again from the top.";

// e02c 把旧藏亮给铁匠看（legendCrack1）的后果前缀：铁匠记下了
const e03ZhShow =
  "铁匠的锤声在你身后停了。\n\n他没有叫住你，也没有追出来，你把那件东西从铁砧上取回来时，他甚至连头都没有抬。\n\n可你知道，今天下午那把锤子不会再响了：他已经把看见的一切都收进了眼底，那是一件从大火那年熬过来的东西。\n\n";
const e03EnShow =
  "The smith's hammer falls silent behind you. He does not call out and " +
  "does not follow — and when you lift the thing back off the anvil, he " +
  "never looks up. But you know that hammer will not sound again this " +
  "afternoon: he has pocketed what he saw, a thing that lived through " +
  "the year of the fire.\n\n";

// ============================================================
//  e03 · 杀戮之歌（B 登场；性别三选在本页选项上，反馈在 e03b）
// ============================================================
EVENTS.push({
  id: "e03",
  title: { zh: "屠龙者之歌", en: "The Slaying-Song" },
  text: [
    { when: { legendCrack1: true },
      text: { zh: e03ZhShow + e03ZhBody, en: "The smith's hammer falls silent behind you. He does not call out and does not follow — and when you lift the thing back off the anvil, he never looks up. But you know that hammer will not sound again this afternoon: he has pocketed what he saw, a thing that lived through the year of the fire.\n\nThe tavern door is open, and the song comes flowing out.\n\nYou know the tune before you know the words. Every valley has a tune like this — four beats, built for pounding tables — and as you cross into the lamplight, the words arrive:\n\n\"In the year of the burning, the sky rained down ash,\nand the beast came off the mountain, with fire for a lash.\nIt burned up the cornfields, it burned up the barns,\ntill a hero came walking with a sword in his arms—\"\n\nThe singer sits on a stool with one boot on a crate. Young. Ink-stained fingers moving on the strings without looking, because the eyes are on the room, rolling it like a dice cup. Hair that has never once behaved. A voice built for this exact room, this exact ale.\n\nThe lamp above the stool is burning low, and its light jumps.\n\nThe drunk beside you slams his cup. \"The fall!\" he bellows. \"Give us the fall!\"\n\nAnd the singer grins, and gives them the fall:\n\n\"And the hero said, beast, you have burned your last barn,\nand the beast came down hungry, and the sword went up—\nand the mountain it fell from was called the High Tor,\nand it fell, good people, it fell ever more.\"\n\nThey thunder. Tables. Boots. You stand in the middle of it with your new face and your two small nose-holes, and the song about you — the you that saved them, the you they never asked — finishes to a roar, and starts again from the top." } },
    { text: { zh: e03ZhBody, en: "The tavern door is open, and the song comes flowing out.\n\nYou know the tune before you know the words. Every valley has a tune like this — four beats, built for pounding tables — and as you cross into the lamplight, the words arrive:\n\n\"In the year of the burning, the sky rained down ash,\nand the beast came off the mountain, with fire for a lash.\nIt burned up the cornfields, it burned up the barns,\ntill a hero came walking with a sword in his arms—\"\n\nThe singer sits on a stool with one boot on a crate. Young. Ink-stained fingers moving on the strings without looking, because the eyes are on the room, rolling it like a dice cup. Hair that has never once behaved. A voice built for this exact room, this exact ale.\n\nThe lamp above the stool is burning low, and its light jumps.\n\nThe drunk beside you slams his cup. \"The fall!\" he bellows. \"Give us the fall!\"\n\nAnd the singer grins, and gives them the fall:\n\n\"And the hero said, beast, you have burned your last barn,\nand the beast came down hungry, and the sword went up—\nand the mountain it fell from was called the High Tor,\nand it fell, good people, it fell ever more.\"\n\nThey thunder. Tables. Boots. You stand in the middle of it with your new face and your two small nose-holes, and the song about you — the you that saved them, the you they never asked — finishes to a roar, and starts again from the top." } }
  ],
  choices: [
    { text: { zh: "灯下是个年轻男人。", en: "Under the lamp: a young man." },
      set: { roB_sex: "male" }, next: "e03b" },
    { text: { zh: "灯下是个年轻女人。", en: "Under the lamp: a young woman." },
      set: { roB_sex: "female" }, next: "e03b" },
    { text: { zh: "灯光里，那张脸始终定不下来。你不再试图分辨。", en: "The face won't settle in the lamplight. You stop sorting." },
      set: { roB_sex: "nonbinary" }, next: "e03b" }
  ]
});

// ============================================================
//  e03b · 灯下（B 性别三选的当页反馈；歌的应对挪到这页）
// ============================================================
EVENTS.push({
  id: "e03b",
  title: { zh: "灯光", en: "Lamplight" },
  text: [
    { when: { roB_sex: "male" },
      text: { zh: "灯光稳住了。\n\n歌手是个年轻男人，脸上还带着刚开始刮胡子的那股青涩，脚跟在木箱上打着拍子。\n\n唱到“坠落”的时候，他往后一仰，仿佛他自己的歌能把他掀翻似的。\n\n他注意到你在看他。\n\n他并不害羞，而是在暗暗记账。",
              en: "The lamp steadies. The singer is a young man: a jaw still finding " +
                  "its razor, heel keeping time on the crate, and when the word fall " +
                  "lands he tips back like a man his own song could push over.\n\n" +
                  "He sees you seeing him. Not shy about it — logging." } },
    { when: { roB_sex: "female" },
      text: { zh: "灯光稳住了。\n\n歌手是个年轻女人，袖子挽过了手肘。\n\n唱到“坠落”的时候，她踮起脚尖，仿佛整块地板都该跟着她一起升起来。\n\n她注意到你在看她。\n\n她并不害羞，而是在暗暗记账。",
              en: "The lamp steadies. The singer is a young woman: sleeves shoved " +
                  "past the elbow, and when the word fall lands she rises on her " +
                  "toes, lifting, like the whole floor should jump with her.\n\n" +
                  "She sees you seeing her. Not shy about it — logging." } },
    { text: { zh: "灯光稳住了。\n\n那张脸在灯晕里变了两回，唱英雄那段时是少年的傲气，唱到怪物那段，又借来了某种更老、更沉的东西。\n\n你不再试图分辨，歌手看见你放弃了，便冲你一笑，毫不难为情，照样在暗暗记账。",
              en: "The lamp steadies. The face turns twice in the light — a boy's " +
                  "insolence for the hero's verse, something older and borrowed " +
                  "for the beast's. You give up sorting. The singer sees you give " +
                  "up, and grins. Not shy — logging." } }
  ],
  choices: [
    { text: { zh: "往歌手的杯子里丢一枚硬币。", en: "Put a coin in the singer's cup." },
      set: { songChoice: "coin" }, next: "e04" },
    { text: { zh: "“歌里的英雄没有名字。”", en: "\"The hero has no name in the song.\"" },
      set: { songChoice: "noname" }, next: "e04" },
    { text: { zh: "“龙是从托尔岗上坠下来的？不是磨坊边那道悬崖？”", en: "\"Dragon fell at the Tor, did it? Not the cliff by the mill?\"" },
      set: { songChoice: "cliff" }, next: "e04" },
    { text: { zh: "把整首歌听完。每个字。听两遍。", en: "Hear the song out. Every word. Twice." },
      set: { songChoice: "listen" }, next: "e04" }
  ]
});

// ============================================================
//  e04 · 剑之纪念堂（A 登场；性别三选在本页选项上，反馈在 e04c）
// ============================================================
EVENTS.push({
  id: "e04",
  title: { zh: "长剑祠", en: "The Shrine of the Sword" },
  text: [
    { when: { songChoice: "coin" },
      text: { zh: "你离开时，歌手朝你举了举杯。\n\n{bHe}看见你投了币，只一眼就把你从头到脚掂量了个透，然后把下一句径直唱向了你那一桌。\n\n那不是调情，而是在盘点。\n\n离得近了，雕像看起来既矮了些，又高了些，这是只有石头才讲得通的道理。\n\n墙边立着一块比雕像还要老的墓碑，上面并排刻着两个女人的名字，出自同一只手，中间隔着一道藤蔓纹，被擦得和周围的石头一样光亮。\n\n" + e04ZhTail,
              en: "On your way out, the singer lifts {bHis} cup to you — {bHe} saw you do it, saw you, the whole of you, one look — and sings the next verse straight at your table. It is not flirtation. It is \"inventory.\"\n\nThe statue is smaller up close, and taller. That is a true thing about stone.\n\nBy the wall, a headstone older than the statue: two women's names cut side by side by the same hand, a vine between them — polished as bright as any other stone there.\n\nThe keeper is there before you are — you assumed it was a beggar kneeling at the statue's base, but the rag in that hand is polish, not alms, and the shoulders under the coat are gentry shoulders, if slightly weighed down and set crooked by some private duty of their own.\n\nDiligent. Polished. Afraid of something the keeper can't name — that is the whole of them in three words, and you could pick all three out of that voice before it even speaks. On the breast, pinned slightly crooked, a badge too big for the shoulders under it: the crossed sword of the Slaying, a family's whole honor, worn like a borrowed thing.\n\nThe keeper is cleaning the statue's face. Up on the toes, the rag in small circles on the stone brow — talking while working, low, familiar, someone talking to a face known longer than their own.\n\n\"—because if I don't, who will,\" to the mouth of the statue, \"and the anniversary is in three days, and the whole family is coming, and—\" Then the shadow of you lands on the marble, and is noticed.\n\nDown off the toes, like someone caught singing.\n\n\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The keeper looks up at it — and then, because you are standing in exactly the wrong light, or exactly the right one, looks at yours.\n\nThe rag stops in the air.\n\nAnd by that same light, you see the face." } },
    { when: { songChoice: "cliff" },
      text: { zh: "歌声戛然而止。\n\n歌手看着你，就像一个等了好多年、只等有人把错话说对的人。“……\n\n你是从哪儿听来的？”\n\n你走开的时候，能感觉到{bHis}目光一直钉在你的背上。\n\n离得近了，雕像看起来既矮了些，又高了些，这是只有石头才讲得通的道理。\n\n墙边立着一块比雕像还要老的墓碑，上面并排刻着两个女人的名字，出自同一只手，中间隔着一道藤蔓纹，被擦得和周围的石头一样光亮。\n\n" + e04ZhTail,
              en: "The singing stops entirely. The singer looks at you like someone who has been waiting years for someone to say the wrong thing, correctly. \"...Where did you hear that?\" You leave with {bHis} gaze still pinned between your shoulders.\n\nThe statue is smaller up close, and taller. That is a true thing about stone.\n\nBy the wall, a headstone older than the statue: two women's names cut side by side by the same hand, a vine between them — polished as bright as any other stone there.\n\nThe keeper is there before you are — you assumed it was a beggar kneeling at the statue's base, but the rag in that hand is polish, not alms, and the shoulders under the coat are gentry shoulders, if slightly weighed down and set crooked by some private duty of their own.\n\nDiligent. Polished. Afraid of something the keeper can't name — that is the whole of them in three words, and you could pick all three out of that voice before it even speaks. On the breast, pinned slightly crooked, a badge too big for the shoulders under it: the crossed sword of the Slaying, a family's whole honor, worn like a borrowed thing.\n\nThe keeper is cleaning the statue's face. Up on the toes, the rag in small circles on the stone brow — talking while working, low, familiar, someone talking to a face known longer than their own.\n\n\"—because if I don't, who will,\" to the mouth of the statue, \"and the anniversary is in three days, and the whole family is coming, and—\" Then the shadow of you lands on the marble, and is noticed.\n\nDown off the toes, like someone caught singing.\n\n\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The keeper looks up at it — and then, because you are standing in exactly the wrong light, or exactly the right one, looks at yours.\n\nThe rag stops in the air.\n\nAnd by that same light, you see the face." } },
    { when: { songChoice: "listen" },
      text: { zh: "你听着自己在四拍子里被杀死了两回，什么也没买，什么也没说，却把那个谎言的轮廓摸了个一清二楚。\n\n你离开的时候，歌还在唱。\n\n离得近了，雕像看起来既矮了些，又高了些，这是只有石头才讲得通的道理。\n\n墙边立着一块比雕像还要老的墓碑，上面并排刻着两个女人的名字，出自同一只手，中间隔着一道藤蔓纹，被擦得和周围的石头一样光亮。\n\n" + e04ZhTail,
              en: "You listen to yourself be killed twice, in four-beat time, and buy nothing, and say nothing, and learn the shape of the lie from inside. The song is still going as you leave.\n\nThe statue is smaller up close, and taller. That is a true thing about stone.\n\nBy the wall, a headstone older than the statue: two women's names cut side by side by the same hand, a vine between them — polished as bright as any other stone there.\n\nThe keeper is there before you are — you assumed it was a beggar kneeling at the statue's base, but the rag in that hand is polish, not alms, and the shoulders under the coat are gentry shoulders, if slightly weighed down and set crooked by some private duty of their own.\n\nDiligent. Polished. Afraid of something the keeper can't name — that is the whole of them in three words, and you could pick all three out of that voice before it even speaks. On the breast, pinned slightly crooked, a badge too big for the shoulders under it: the crossed sword of the Slaying, a family's whole honor, worn like a borrowed thing.\n\nThe keeper is cleaning the statue's face. Up on the toes, the rag in small circles on the stone brow — talking while working, low, familiar, someone talking to a face known longer than their own.\n\n\"—because if I don't, who will,\" to the mouth of the statue, \"and the anniversary is in three days, and the whole family is coming, and—\" Then the shadow of you lands on the marble, and is noticed.\n\nDown off the toes, like someone caught singing.\n\n\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The keeper looks up at it — and then, because you are standing in exactly the wrong light, or exactly the right one, looks at yours.\n\nThe rag stops in the air.\n\nAnd by that same light, you see the face." } },
    { when: { songChoice: "noname" },
      text: { zh: "那句“歌里的英雄没有名字”，一直跟着你走出了酒馆。没有人接话，那本来也不是一句要人接的话。\n\n它一路跟着你走到祠堂门前，越走越沉：歌里没有的名字，都要由石头来补上。\n\n离得近了，雕像看起来既矮了些，又高了些，这是只有石头才讲得通的道理。\n\n墙边立着一块比雕像还要老的墓碑，上面并排刻着两个女人的名字，出自同一只手，中间隔着一道藤蔓纹，被擦得和周围的石头一样光亮。\n\n" + e04ZhTail,
              en: "The line follows you out of the tavern: \"the hero has no name in the song.\" Nobody picks it up — it was never a line that needed picking up. It walks you all the way to the shrine, heavier at every step: the name the song leaves out, the stone supplies.\n\nThe statue is smaller up close, and taller. That is a true thing about stone.\n\nBy the wall, a headstone older than the statue: two women's names cut side by side by the same hand, a vine between them — polished as bright as any other stone there.\n\nThe keeper is there before you are — you assumed it was a beggar kneeling at the statue's base, but the rag in that hand is polish, not alms, and the shoulders under the coat are gentry shoulders, if slightly weighed down and set crooked by some private duty of their own.\n\nDiligent. Polished. Afraid of something the keeper can't name — that is the whole of them in three words, and you could pick all three out of that voice before it even speaks. On the breast, pinned slightly crooked, a badge too big for the shoulders under it: the crossed sword of the Slaying, a family's whole honor, worn like a borrowed thing.\n\nThe keeper is cleaning the statue's face. Up on the toes, the rag in small circles on the stone brow — talking while working, low, familiar, someone talking to a face known longer than their own.\n\n\"—because if I don't, who will,\" to the mouth of the statue, \"and the anniversary is in three days, and the whole family is coming, and—\" Then the shadow of you lands on the marble, and is noticed.\n\nDown off the toes, like someone caught singing.\n\n\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The keeper looks up at it — and then, because you are standing in exactly the wrong light, or exactly the right one, looks at yours.\n\nThe rag stops in the air.\n\nAnd by that same light, you see the face." } },
    { text: { zh: "歌声仍在你身后。\n\n离得近了，雕像看起来既矮了些，又高了些，这是只有石头才讲得通的道理。\n\n墙边立着一块比雕像还要老的墓碑，上面并排刻着两个女人的名字，出自同一只手，中间隔着一道藤蔓纹，被擦得和周围的石头一样光亮。\n\n" + e04ZhTail,
              en: "The song is still behind you.\n\nThe statue is smaller up close, and taller. That is a true thing about stone.\n\nBy the wall, a headstone older than the statue: two women's names cut side by side by the same hand, a vine between them — polished as bright as any other stone there.\n\nThe keeper is there before you are — you assumed it was a beggar kneeling at the statue's base, but the rag in that hand is polish, not alms, and the shoulders under the coat are gentry shoulders, if slightly weighed down and set crooked by some private duty of their own.\n\nDiligent. Polished. Afraid of something the keeper can't name — that is the whole of them in three words, and you could pick all three out of that voice before it even speaks. On the breast, pinned slightly crooked, a badge too big for the shoulders under it: the crossed sword of the Slaying, a family's whole honor, worn like a borrowed thing.\n\nThe keeper is cleaning the statue's face. Up on the toes, the rag in small circles on the stone brow — talking while working, low, familiar, someone talking to a face known longer than their own.\n\n\"—because if I don't, who will,\" to the mouth of the statue, \"and the anniversary is in three days, and the whole family is coming, and—\" Then the shadow of you lands on the marble, and is noticed.\n\nDown off the toes, like someone caught singing.\n\n\"Forgive me.\" A breath. \"It's the face. People stare at the face.\" The keeper looks up at it — and then, because you are standing in exactly the wrong light, or exactly the right one, looks at yours.\n\nThe rag stops in the air.\n\nAnd by that same light, you see the face." } }
  ],
  choices: [
    { text: { zh: "雕像下是个男人。", en: "Under the statue: a man." },
      set: { roA_sex: "male" }, next: "e04c" },
    { text: { zh: "雕像下是个女人。", en: "Under the statue: a woman." },
      set: { roA_sex: "female" }, next: "e04c" },
    { text: { zh: "那张脸什么也不肯透露，只给你看那枚大得不合身的徽章，轻轻摇晃。", en: "The face gives you neither — only the too-big badge, swaying." },
      set: { roA_sex: "nonbinary" }, next: "e04c" }
  ]
});

// ============================================================
//  e04c · 守祠人（A 性别三选的当页反馈；原纪念堂对答挪到这页）
// ============================================================
EVENTS.push({
  id: "e04c",
  title: { zh: "守祠人", en: "The Keeper" },
  text: [
    { when: { roA_sex: "male" },
      text: { zh: "那是一个三十来岁的男人，袖口已经磨毛了，倒不是因为穷，而是因为同一份活儿干得太久了。\n\n“……你是本地人吗？”他问得过分小心，仿佛你的每一个回答，都会改动账本上的一行。",
              en: "A man, thirty or so, cuffs frayed to a fuzz — not poverty; the " +
                  "same job, done too many years.\n\n" +
                  "\"…Are you local?\" he asks, too carefully, as if every answer " +
                  "will alter a ledger." } },
    { when: { roA_sex: "female" },
      text: { zh: "那是一个三十来岁的女人，她把擦拭布对折两次，压平，再塞进袖口，叠得就像一件圣物。\n\n“……你是本地人吗？”她问得过分小心，仿佛你的每一个回答，都会改动账本上的一行。",
              en: "A woman, thirty or so, and she puts the rag away like a relic — " +
                  "folded twice, pressed flat, into her sleeve.\n\n" +
                  "\"…Are you local?\" she asks, too carefully, as if every answer " +
                  "will alter a ledger." } },
    { text: { zh: "日光下，那张脸看不出性别，只有一种专注，像是有人在仔细核对一笔账。\n\n守祠人把布对折两次，压平，像收起一件圣物那样把它收好。\n\n“……你是本地人吗？”这个问题问得过分小心，仿佛你的每一个回答，都会改动账本上的一行。",
              en: "The face in daylight gives you neither, and gives you all its attention, like a ledger being balanced. The keeper folds the rag twice, presses it flat, and puts it away like a relic.\n\n\"…Are you local?\" The question comes too carefully, as if every answer will alter a ledger." } }
  ],
  choices: [
    { text: { zh: "“那座雕像，就是照着我刻的。”", en: "\"That statue was carved from me.\"" },
      set: { keeperChoice: "sarcasm" }, next: "e04b" },
    { text: { zh: "“不是。我只是来看看。”", en: "\"No. I'm just looking.\"" },
      set: { keeperChoice: "passing" }, next: "e04b" },
    { text: { zh: "“那是谁的脸？”", en: "\"Whose face is it?\"" },
      set: { keeperChoice: "legend", legendTold: true }, next: "e04b" }
  ]
});

// ============================================================
//  e04b · 屠龙游戏（孩子；前接守祠人对答后果段）
// ============================================================
EVENTS.push({
  id: "e04b",
  title: { zh: "屠龙游戏", en: "The Slaying Game" },
  text: [
    { when: { keeperChoice: "sarcasm" },
      text: { zh: "这话说出口，比你预想的还要干巴。\n\n{aHe}没忍住笑了出来，短促的一声，刚冒头就被没收了。\n\n“这是亵渎。”守祠人说，语气里却带着一丝隐秘的快意，“也是六十年来，头一回有人对它说实话。”\n\n" + e04bZhTail,
              en: "It comes out drier than you meant, and {aHe} laugh{aVs} before {aHe} can stop {aSelf} — a bark of a laugh, instantly confiscated. \"That's sacrilege,\" {aHe} say{aVs}, with a flicker of private delight. \"Also the first honest thing anyone's said to it in sixty years.\"\n\nThe bell rings for midday, and the grown-ups all pour into church — and the square fills, at once, with children.\n\nThey are playing the game before the last bell dies. You have seen this game countless times, since before this village had walls: one child is the beast, and everyone else is the hero, and the rules of heroism are: run, scream, swarm.\n\n\"You!\" The smallest one — a girl with a wooden sword taller than herself — has appointed you. \"You're the dragon! You have to roar and chase us!\"" } },
    { when: { keeperChoice: "passing" },
      text: { zh: "{aHe}点了点头，却并不信服，{aHis}目光在你的脸和雕像的脸之间来回扫了一遍，就像在复查一把明知已经被撬开了的锁。\n\n" + e04bZhTail,
              en: "{aHe} nod{aVs}, unconvinced, and {aHis} eyes go from your face to the stone face and back, once, like someone checking a lock {aHe} already know{aVs} is picked.\n\nThe bell rings for midday, and the grown-ups all pour into church — and the square fills, at once, with children.\n\nThey are playing the game before the last bell dies. You have seen this game countless times, since before this village had walls: one child is the beast, and everyone else is the hero, and the rules of heroism are: run, scream, swarm.\n\n\"You!\" The smallest one — a girl with a wooden sword taller than herself — has appointed you. \"You're the dragon! You have to roar and chase us!\"" } },
    { when: { keeperChoice: "legend" },
      text: { zh: "{aHe}把整个家族的传说讲给你听，连同它运转的全部机关：火中的陌生人、剑、坠落，还有消失。\n\n{aHe}背诵它就像背诵自己的名字，而在某种意义上，那也确实就是{aHis}名字。\n\n“你要是想听，今晚酒馆里就有人唱。唱出来比说出来好听。”守祠人又补了一句，带着一个小小的、意味难明的笑，“毕竟，唱歌的钱是我家出的。”\n\n原来有人在为这首歌付账。传说不是野生的，而是庄稼，有人年年出钱，雇它长在人们的嘴里。\n\n你把这一条，也记进了心里那本越来越厚的账。\n\n" + e04bZhTail,
              en: "{aHe} tell{aVs} you. Family legend, the whole machine of it: the stranger in the fire, the sword, the fall, the vanishing. {aHe} tell{aVs} it like someone reciting {aHis} own name, which, in a way, {aHe} {aIs}. \"And you'll hear it sung tonight at the inn, if you like. Better sung than said.\" {aHe} add{aVs}, with a small, complicated smile, \"After all, my family pays for the singing.\"\n\nSo the song has a paymaster. Legends are not wild things; they are crops — paid for year after year, farmed in people's mouths. You enter this, too, in that thickening ledger of yours.\n\nThe bell rings for midday, and the grown-ups all pour into church — and the square fills, at once, with children.\n\nThey are playing the game before the last bell dies. You have seen this game countless times, since before this village had walls: one child is the beast, and everyone else is the hero, and the rules of heroism are: run, scream, swarm.\n\n\"You!\" The smallest one — a girl with a wooden sword taller than herself — has appointed you. \"You're the dragon! You have to roar and chase us!\"" } },
    { text: { zh: e04bZhTail, en: "The bell rings for midday, and the grown-ups all pour into church — and the square fills, at once, with children.\n\nThey are playing the game before the last bell dies. You have seen this game countless times, since before this village had walls: one child is the beast, and everyone else is the hero, and the rules of heroism are: run, scream, swarm.\n\n\"You!\" The smallest one — a girl with a wooden sword taller than herself — has appointed you. \"You're the dragon! You have to roar and chase us!\"" } }
  ],
  choices: [
    { text: { zh: "吼——放出你真正的嗓音。", en: "Roar — and let the real voice out." },
      when: { voice: "true" },
      set: { kidResult: "roar", sus1: true }, next: "e05" },
    { text: { zh: "吼——压低一点，柔和点，像人那样。", en: "Roar — pressed down, human-soft." },
      when: { voice: "low" },
      set: { kidResult: "roarFail" }, next: "e05" },
    { text: { zh: "“歌里的龙不追人。”", en: "\"The dragon in the song doesn't chase.\"" },
      set: { kidResult: "norun", taughtKids: true }, next: "e05" },
    { text: { zh: "陪他们玩。让他们当英雄。", en: "Play along. Let them be the heroes." },
      set: { kidResult: "hero" }, next: "e05" }
  ]
});

// ============================================================
//  e05 · 押龙过境（C 登场；前接孩子游戏后果段）
// ============================================================
EVENTS.push({
  id: "e05",
  title: { zh: "笼中之龙", en: "The Dragon in the Cage" },
  text: [
    { when: { kidResult: "roar" },
      text: { zh: "你本来没打算用真嗓子，可那声音还是从你的胸腔里撕了出来，就像世界底下猛地掀开了一道活板门，连三条街外的狗都夹着尾巴趴了下来。\n\n孩子们尖叫起来，欣喜与惊恐的比例恰到好处，教堂门口的母亲们也齐齐转过了身。\n\n" + e05ZhTail,
              en: "You do not mean to use the real voice. It tears out of your chest like a door opening in the floor of the world — even the dogs three streets away lie down, tails tucked. The children scream with joy and terror in perfect proportion. The mothers turn from the church door.\n\nThe dogs start it — all of them at once, one voice, like the village has an opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, all one direction, and you move too, because you know. You have known since the well.\n\nThey bring the cage through the square on a wagon drawn by four oxen. The cage is iron, new-forged, hung with charms that tick and shimmer when they move — the sound of containment, of someone else's fear, well engineered. And inside it:\n\nScale. Faded scale, the color of a fire gone out. A shoulder built for wings. A head that does not rise for the crowd, that has decided not to rise for anything, and a length of tail curled twice around the body the way you yourself once slept — the coiled not-sleep of a thing that is listening to everything while pretending to be cargo.\n\nThen, through the crowd's roar, it does raise its head. Past the children. Past the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — and stays.\n\n\"Torch it! Burn it here!\"\n\nA boy has scrambled up onto the well — someone's boy, someone's darling, thirteen and certain — and he is throwing the hardest thing he can find, which is a stone. It rings off the bars. The crowd laughs, and the soldiers do nothing, and the boy picks up a second stone.\n\nThe eye is still on you." } },
    { when: { kidResult: "roarFail" },
      text: { zh: "你发出了一声礼貌的、近乎无辜的小动静，像一头被请出饭馆的母牛，孩子们连一秒钟都没被骗过。\n\n“不行，”最小的那个说，“得像龙那样吼。”你道了歉，他们勉强接受了。\n\n" + e05ZhTail,
              en: "You produce a small, polite, almost innocent noise, like a cow being asked to leave a restaurant. The children are not fooled. \"No,\" the small one says, \"a DRAGON roar.\" You apologize. They accept it grudgingly.\n\nThe dogs start it — all of them at once, one voice, like the village has an opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, all one direction, and you move too, because you know. You have known since the well.\n\nThey bring the cage through the square on a wagon drawn by four oxen. The cage is iron, new-forged, hung with charms that tick and shimmer when they move — the sound of containment, of someone else's fear, well engineered. And inside it:\n\nScale. Faded scale, the color of a fire gone out. A shoulder built for wings. A head that does not rise for the crowd, that has decided not to rise for anything, and a length of tail curled twice around the body the way you yourself once slept — the coiled not-sleep of a thing that is listening to everything while pretending to be cargo.\n\nThen, through the crowd's roar, it does raise its head. Past the children. Past the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — and stays.\n\n\"Torch it! Burn it here!\"\n\nA boy has scrambled up onto the well — someone's boy, someone's darling, thirteen and certain — and he is throwing the hardest thing he can find, which is a stone. It rings off the bars. The crowd laughs, and the soldiers do nothing, and the boy picks up a second stone.\n\nThe eye is still on you." } },
    { when: { kidResult: "norun" },
      text: { zh: "最小的那个眯起眼看你。“就是要追。游戏就是这么玩的。”\n\n“歌里的龙不追人，”你说，“龙放火，英雄去找它。”\n\n广场上一时鸦雀无声。\n\n“……你根本不会玩。”她宣布，用木剑敲了你一下，转身把龙的角色派给了别人。\n\n可你眼看着自己的新规则传开了。\n\n广场那头有人在喊：“这回龙不追，英雄自己上山找它！”也有孩子抗议，只是抗议无效。\n\n一个玩了六十年的游戏，原来改起来只要一个下午。\n\n" + e05ZhTail,
              en: "The small one squints up at you. \"Yes it does. That's the whole game.\" \"The dragon in the song doesn't chase,\" you say. \"The dragon burns, and the hero comes to it.\" The square is very quiet for a moment. \"…You don't know how to play,\" she declares, and taps you with the wooden sword, and appoints someone else.\n\nBut the new rule travels. Across the square someone shouts, \"This time the dragon doesn't chase — the hero climbs the mountain to find it!\" A few children protest; the protest fails. Sixty years of a game, and it took one afternoon to change.\n\nThe dogs start it — all of them at once, one voice, like the village has an opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, all one direction, and you move too, because you know. You have known since the well.\n\nThey bring the cage through the square on a wagon drawn by four oxen. The cage is iron, new-forged, hung with charms that tick and shimmer when they move — the sound of containment, of someone else's fear, well engineered. And inside it:\n\nScale. Faded scale, the color of a fire gone out. A shoulder built for wings. A head that does not rise for the crowd, that has decided not to rise for anything, and a length of tail curled twice around the body the way you yourself once slept — the coiled not-sleep of a thing that is listening to everything while pretending to be cargo.\n\nThen, through the crowd's roar, it does raise its head. Past the children. Past the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — and stays.\n\n\"Torch it! Burn it here!\"\n\nA boy has scrambled up onto the well — someone's boy, someone's darling, thirteen and certain — and he is throwing the hardest thing he can find, which is a stone. It rings off the bars. The crowd laughs, and the soldiers do nothing, and the boy picks up a second stone.\n\nThe eye is still on you." } },
    { when: { kidResult: "hero" },
      text: { zh: "孩子们挥着木剑一拥而上，最后你倒在最小那个孩子的致命一击之下，在一片胜利的尖叫声中死得无比夸张。\n\n“你倒得真好。”有个孩子这样评价道。\n\n你心想，在这个村子里，这差不多算得上是祖传的手艺了。\n\n" + e05ZhTail,
              en: "They swarm you with wooden swords and you fall, at last, under the fatal blow of the smallest one, dying elaborately, to shrieks of triumph. One of them says, \"You fell good,\" which in this village, you reflect, is the family trade.\n\nThe dogs start it — all of them at once, one voice, like the village has an opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, all one direction, and you move too, because you know. You have known since the well.\n\nThey bring the cage through the square on a wagon drawn by four oxen. The cage is iron, new-forged, hung with charms that tick and shimmer when they move — the sound of containment, of someone else's fear, well engineered. And inside it:\n\nScale. Faded scale, the color of a fire gone out. A shoulder built for wings. A head that does not rise for the crowd, that has decided not to rise for anything, and a length of tail curled twice around the body the way you yourself once slept — the coiled not-sleep of a thing that is listening to everything while pretending to be cargo.\n\nThen, through the crowd's roar, it does raise its head. Past the children. Past the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — and stays.\n\n\"Torch it! Burn it here!\"\n\nA boy has scrambled up onto the well — someone's boy, someone's darling, thirteen and certain — and he is throwing the hardest thing he can find, which is a stone. It rings off the bars. The crowd laughs, and the soldiers do nothing, and the boy picks up a second stone.\n\nThe eye is still on you." } },
    { text: { zh: e05ZhTail, en: "The dogs start it — all of them at once, one voice, like the village has an opinion. And then the noise of hooves, iron rings on wood, and the crowd moving, all one direction, and you move too, because you know. You have known since the well.\n\nThey bring the cage through the square on a wagon drawn by four oxen. The cage is iron, new-forged, hung with charms that tick and shimmer when they move — the sound of containment, of someone else's fear, well engineered. And inside it:\n\nScale. Faded scale, the color of a fire gone out. A shoulder built for wings. A head that does not rise for the crowd, that has decided not to rise for anything, and a length of tail curled twice around the body the way you yourself once slept — the coiled not-sleep of a thing that is listening to everything while pretending to be cargo.\n\nThen, through the crowd's roar, it does raise its head. Past the children. Past the pikes. Its eye finds you in the crowd like a lamp carried into a dark room — and stays.\n\n\"Torch it! Burn it here!\"\n\nA boy has scrambled up onto the well — someone's boy, someone's darling, thirteen and certain — and he is throwing the hardest thing he can find, which is a stone. It rings off the bars. The crowd laughs, and the soldiers do nothing, and the boy picks up a second stone.\n\nThe eye is still on you." } }
  ],
  choices: [
    { text: { zh: "抓住男孩的手腕。", en: "Grab the boy's wrist." },
      set: { cageChoice: "stop", stoppedStone: true }, next: "e06" },
    { text: { zh: "先移开目光。", en: "Look away first." },
      set: { cageChoice: "away" }, next: "e06" },
    { text: { zh: "迎着那只眼睛，看回去。", en: "Meet the eye, and look back." },
      set: { cageChoice: "hold" }, next: "e06" }
  ]
});

// ============================================================
//  e06 · 老兵火塘（前接押龙后果段）
// ============================================================
EVENTS.push({
  id: "e06",
  title: { zh: "老兵的火堆", en: "The Old Soldier's Fire" },
  text: [
    { when: { cageChoice: "stop" },
      text: { zh: "石头从他手里脱了出来。男孩带着一个孩子能拿出的全部怒气，猛地转过身来，人群的笑声也随之变了调：此刻，广场上最有意思的东西成了你。\n\n“它杀过当兵的，”男孩啐道，“还烧过一整座农庄。”\n\n被你截下的那块石头落进你的掌心，还带着他手心的温度。\n\n" + e06ZhTail,
              en: "The stone drops. He wheels on you with the total fury of the small — and the crowd's laughter changes register: now you are the interesting thing in the square. \"It 'killed' soldiers,\" the boy spits. \"It burned a whole farm.\" The stone you intercepted lands in your palm, still warm from his hand.\n\nHe has been at three of the same five places you have been today. You noticed him at the well, at the cage, at the shrine — an old man with a straight back and eyes like a dropped fork: everywhere something happened.\n\nAt dusk he is outside the inn with a fire, a pot of stew, and two cups, and he says, \"Sit,\" the way soldiers say it — a courtesy worn down to an instruction.\n\nOn the table between you, propped against the jug: a badge. Crossed sword, old make, older scratches. A twin to the one hanging slightly crooked on the keeper's chest.\n\n\"Ioreth's badge,\" he says, when he sees you see it. \"I was theirs. Before the fire, and after it. Sixty years ago I was small enough to hide in a rain barrel, and I am the last one living who 'saw.'\" He pours. The fire snaps. \"So. I'll ask the question the whole village is too polite — and too afraid — to ask you to your face.\"\n\nHe looks at your face, and it takes him a long time.\n\n\"Whose face is that? And what name goes with it?\"" } },
    { when: { cageChoice: "away" },
      text: { zh: "你很擅长装成一件货物。笼中那只眼睛把灯笼般的黄色目光在你身上又停留了一会儿，既耐心，又轻蔑；\n\n随后牛车嘎吱一声往前走去，人群在它身后重新合拢了。\n\n" + e06ZhTail,
              en: "You are very good at pretending to be cargo. The eye in the cage keeps its lamp on you a moment longer — patient, contemptuous — and then the wagon creaks past, and the crowd closes behind it.\n\nHe has been at three of the same five places you have been today. You noticed him at the well, at the cage, at the shrine — an old man with a straight back and eyes like a dropped fork: everywhere something happened.\n\nAt dusk he is outside the inn with a fire, a pot of stew, and two cups, and he says, \"Sit,\" the way soldiers say it — a courtesy worn down to an instruction.\n\nOn the table between you, propped against the jug: a badge. Crossed sword, old make, older scratches. A twin to the one hanging slightly crooked on the keeper's chest.\n\n\"Ioreth's badge,\" he says, when he sees you see it. \"I was theirs. Before the fire, and after it. Sixty years ago I was small enough to hide in a rain barrel, and I am the last one living who 'saw.'\" He pours. The fire snaps. \"So. I'll ask the question the whole village is too polite — and too afraid — to ask you to your face.\"\n\nHe looks at your face, and it takes him a long time.\n\n\"Whose face is that? And what name goes with it?\"" } },
    { when: { cageChoice: "hold" },
      text: { zh: "你任由它看。六十年来，它是第一个透过这副人形、把你整个看穿的东西。\n\n穿过人群的喧哗向你传来的并不是仇恨，而是比仇恨更糟的东西：一种裹着仇恨外衣的相认。\n\n" + e06ZhTail,
              en: "You let it look. It is the first thing in sixty years to see you, all of you, through this human shape — and what comes down the crowd-noise to you is not hatred. It is worse. It is \"recognition,\" dressed in hatred's clothes.\n\nHe has been at three of the same five places you have been today. You noticed him at the well, at the cage, at the shrine — an old man with a straight back and eyes like a dropped fork: everywhere something happened.\n\nAt dusk he is outside the inn with a fire, a pot of stew, and two cups, and he says, \"Sit,\" the way soldiers say it — a courtesy worn down to an instruction.\n\nOn the table between you, propped against the jug: a badge. Crossed sword, old make, older scratches. A twin to the one hanging slightly crooked on the keeper's chest.\n\n\"Ioreth's badge,\" he says, when he sees you see it. \"I was theirs. Before the fire, and after it. Sixty years ago I was small enough to hide in a rain barrel, and I am the last one living who 'saw.'\" He pours. The fire snaps. \"So. I'll ask the question the whole village is too polite — and too afraid — to ask you to your face.\"\n\nHe looks at your face, and it takes him a long time.\n\n\"Whose face is that? And what name goes with it?\"" } },
    { text: { zh: e06ZhTail, en: "He has been at three of the same five places you have been today. You noticed him at the well, at the cage, at the shrine — an old man with a straight back and eyes like a dropped fork: everywhere something happened.\n\nAt dusk he is outside the inn with a fire, a pot of stew, and two cups, and he says, \"Sit,\" the way soldiers say it — a courtesy worn down to an instruction.\n\nOn the table between you, propped against the jug: a badge. Crossed sword, old make, older scratches. A twin to the one hanging slightly crooked on the keeper's chest.\n\n\"Ioreth's badge,\" he says, when he sees you see it. \"I was theirs. Before the fire, and after it. Sixty years ago I was small enough to hide in a rain barrel, and I am the last one living who 'saw.'\" He pours. The fire snaps. \"So. I'll ask the question the whole village is too polite — and too afraid — to ask you to your face.\"\n\nHe looks at your face, and it takes him a long time.\n\n\"Whose face is that? And what name goes with it?\"" } }
  ],
  choices: [
    { text: { zh: "报给这堆火一个名字。", en: "Give the fire a name." },
      input: true, set: { named: true }, next: "e07a" },
    { text: { zh: "“村子会替我起一个的。”", en: "\"The village will come up with something.\"" },
      set: { nameChoice: "byface" }, next: "e07a" },
    { text: { zh: "“谁的都不是。长得像的脸多了。”", en: "\"Nobody's. Faces repeat.\"" },
      set: { nameChoice: "nobody" }, next: "e07a" },
    { text: { zh: "“伊奥瑞斯。”你朝徽章点点头，“英雄救下的，就是你们家？”",
              en: "\"Ioreth,\" you nod at the badge. \"Yours was the family the hero saved?\"" },
      set: { nameChoice: "iorth", askedIoreth: true }, next: "e07a" }
  ]
});

// ============================================================
//  e07a · 黄昏的守祠人（邀 A；前接老兵火塘后果段）
// ============================================================
EVENTS.push({
  id: "e07a",
  title: { zh: "黄昏的守祠人", en: "The Keeper at Dusk" },
  text: [
    { when: { nameChoice: "byface" },
      text: { zh: "老人哼了一声。“那是自然。疤脸，书呆子，猎户。村子总爱给看不懂的东西起名字，起完了，就以为自己懂了。”\n\n" + e07aZhTail,
              en: "He snorts. \"That it will. The scarred one. The scholar. The hunter. Villages name what they don't understand, and then they think they understand it.\"\n\nYou find {aHim} where the statue finds everyone in the end: at its feet. The shrine is closed for the night, but {aHe} {aIs} still there, kneeling in the last light, and the rag is going in small circles on the stone brow, and you realize the same square foot of face has been under that rag for some time now. {aHe} {aIs} not cleaning. {aHe} {aIs} stalling.\n\n\"Three days,\" {aHe} say{aVs}, without looking around. \"Then the whole family arrives. There's a service, and a supper, and at the supper I stand up and say the words. I have said the words since I was nine years old.\" Circle. Circle. \"My father said them. {aHis} father's before that. You know what I keep thinking, stranger?\"\n\n{aHe} look{aVs} up at the face — your face, worn honest in stone.\n\n\"I keep thinking it's listening.\"\n\n{aHe} laugh{aVs} at {aSelf}, shortly. \"The family eats well off this story. Off that face. I'm not such a fool as to bite the hand. But you—\" {aHe} stand{aVs}, knees cracking; the too-big badge swings and settles. \"You looked at its face today like a man reading a bill of debts. Who are you, to look at it that way?\"" } },
    { when: { nameChoice: "nobody" },
      text: { zh: "老人抬眼看你。“长得像的脸是多，”他说，“可这一张，我六十年里只见过一回。”\n\n他给自己又斟了一杯，没有再追问，接下来的一阵子，就由火堆替你们俩说话。\n\n" + e07aZhTail,
              en: "The old man's eyes come up. \"Faces repeat,\" he says. \"That face, I have seen once in sixty years.\" He pours himself another, and doesn't push, and the fire does the talking for a while.\n\nYou find {aHim} where the statue finds everyone in the end: at its feet. The shrine is closed for the night, but {aHe} {aIs} still there, kneeling in the last light, and the rag is going in small circles on the stone brow, and you realize the same square foot of face has been under that rag for some time now. {aHe} {aIs} not cleaning. {aHe} {aIs} stalling.\n\n\"Three days,\" {aHe} say{aVs}, without looking around. \"Then the whole family arrives. There's a service, and a supper, and at the supper I stand up and say the words. I have said the words since I was nine years old.\" Circle. Circle. \"My father said them. {aHis} father's before that. You know what I keep thinking, stranger?\"\n\n{aHe} look{aVs} up at the face — your face, worn honest in stone.\n\n\"I keep thinking it's listening.\"\n\n{aHe} laugh{aVs} at {aSelf}, shortly. \"The family eats well off this story. Off that face. I'm not such a fool as to bite the hand. But you—\" {aHe} stand{aVs}, knees cracking; the too-big badge swings and settles. \"You looked at its face today like a man reading a bill of debts. Who are you, to look at it that way?\"" } },
    { when: { nameChoice: "iorth" },
      text: { zh: "他笑了一声，又干又薄，没有半点笑意。“是靠英雄起了家的那一家，”他说，“‘救下’是歌里的说法。\n\n这村子的人说这个词时是什么意思，你还不知道。”\n\n" + e07aZhTail,
              en: "He laughs — one note, no joy. \"The family the hero 'made',\" he says. \"Saved is what the song calls it. You don't know what anyone means by that word yet.\"\n\nYou find {aHim} where the statue finds everyone in the end: at its feet. The shrine is closed for the night, but {aHe} {aIs} still there, kneeling in the last light, and the rag is going in small circles on the stone brow, and you realize the same square foot of face has been under that rag for some time now. {aHe} {aIs} not cleaning. {aHe} {aIs} stalling.\n\n\"Three days,\" {aHe} say{aVs}, without looking around. \"Then the whole family arrives. There's a service, and a supper, and at the supper I stand up and say the words. I have said the words since I was nine years old.\" Circle. Circle. \"My father said them. {aHis} father's before that. You know what I keep thinking, stranger?\"\n\n{aHe} look{aVs} up at the face — your face, worn honest in stone.\n\n\"I keep thinking it's listening.\"\n\n{aHe} laugh{aVs} at {aSelf}, shortly. \"The family eats well off this story. Off that face. I'm not such a fool as to bite the hand. But you—\" {aHe} stand{aVs}, knees cracking; the too-big badge swings and settles. \"You looked at its face today like a man reading a bill of debts. Who are you, to look at it that way?\"" } },
    { when: { named: true },
      text: { zh: "{name}。\n\n你把这个名字报给了火堆，火堆收下了。\n\n老兵把它在心里翻来覆去地掂量了一番，点点头，就让它留下了。\n\n" + e07aZhTail,
              en: "{name}. You give the fire the name, and the fire accepts it. The " +
                  "old soldier turns it over once, nods, keeps it.\n\n" + e07aEnTail } },
    { text: { zh: "火堆没有等到你的名字。\n\n老兵也不追问，只当你是想不起来了，便由它去了。\n\n" + e07aZhTail,
              en: "The fire never gets your name. The old soldier takes it for what it " +
                  "is — a name you could not reach — and lets it go.\n\n" + e07aEnTail } }
  ],
  choices: [
    { text: { zh: "“跟我来，你就明白了。别急着念那段话。来看看这首歌底下到底埋着什么。”",
              en: "\"Come with me and find out. Don't rush to say the words — see what the song was built on.\"" },
      set: { aAsk: "invite", inPartyA: true }, next: "e07b" },
    { text: { zh: "“你说得对。它养活了你。继续守着它吧。”",
              en: "\"You're right. It feeds you. Guard it.\"" },
      set: { aAsk: "guard" }, next: "e07b" },
    { text: { zh: "“也许它真的在听。你都把它擦得这么锃亮了。”",
              en: "\"Maybe it is listening. You've polished it bright enough.\"" },
      set: { aAsk: "listen" }, next: "e07b" }
  ]
});

// ============================================================
//  e07b · 歌手的报酬（邀 B）
// ============================================================
EVENTS.push({
  id: "e07b",
  title: { zh: "歌手的酬劳", en: "The Singer's Pay" },
  text: [
    { when: { aAsk: "invite" },
      text: { zh: "{aHe}僵住了，连布从手里滑落都没察觉。“三天。”\n\n{aHe}又说了一遍，可这一回，听上去却像是在数一笔早就认命要花掉的钱。\n\n守祠人跟在你身后走进酒馆，站在门边，像一件被搬错了屋子的家具，脊背却挺得笔直。\n\n" + e07bZhTail,
              en: "{aHe} halt{aVs}, absolutely still. The rag drops from {aHis} hand, unnoticed. " +
                  "\"Three days,\" {aHe} say{aVs} again — but {aHe} say{aVs} it like someone " +
                  "counting coins {aHe} had already decided to spend.\n\n" +
                  "The keeper comes in behind you and stands in the doorway like " +
                  "furniture carried into the wrong room, but {aHe} stand{aVs} very " +
                  "straight.\n\n" + e07bEnTail } },
    { when: { aAsk: "guard" },
      text: { zh: "{aHe}慢慢点头，看上去既释然又失望。“你是第一个说这话时没笑的人。晚安，陌生人。”\n\n" + e07bZhTail,
              en: "{aHe} nod{aVs} slowly, relieved and disappointed at once. \"You're the " +
                  "first person to say so without laughing. Good night, stranger.\"" +
                  "\n\n" + e07bEnTail } },
    { when: { aAsk: "listen" },
      text: { zh: "{aHe}久久地看着你，又看了看那张脸，{aHis}眼底有什么东西合上了一线，就像空屋里一扇被风推动的门。\n\n" + e07bZhTail,
              en: "{aHe} look{aVs} at you for a long moment — then at the face — and " +
                  "something behind {aHis} eyes closes a fraction, like a door moved by " +
                  "wind in an empty house.\n\n" + e07bEnTail } },
    { text: { zh: e07bZhTail, en: e07bEnTail } }
  ],
  choices: [
    { text: { zh: "“别数了，跟我来。我们把每一句歌词都追回大火那年——每个名字，每个日子，每道悬崖。”",
              en: "\"Stop counting, and come with me. We'll trace every verse back to the fire year. Every name, every date, every cliff.\"" },
      set: { bAsk: "walk", inPartyB: true }, next: "e07c" },
    { text: { zh: "“那就唱得再响点。毕竟你也得吃饭。”", en: "\"Sing loud, then. It's a living.\"" },
      set: { bAsk: "stay" }, next: "e07c" },
    { text: { zh: "“给我唱一首不是屠龙的歌吧。就一首，在明天到来之前。”",
              en: "\"Sing me something that isn't the slaying-song. Just once, before tomorrow gets here.\"" },
      set: { bAsk: "ballad", bHeart: true }, next: "e07c" }
  ]
});

// ============================================================
//  e07c · 墙外的营地（夜访押送营 · C）
// ============================================================
EVENTS.push({
  id: "e07c",
  title: { zh: "墙外的营地", en: "The Camp Beyond the Wall" },
  text: [
    { when: { bAsk: "walk" },
      text: { zh: "佩兰把硬币一把扫进口袋。“我去拿那本书。”\n\n{bHe}陪你一直走到最后一道栅栏，才停下脚步。“我就送到这儿，”{bHe}说，“书里可没写过该怎么对着铁笼唱歌。”\n\n" + e07cZhBody,
              en: "{bHe} sweep{bVs} the coins into {bHis} pocket in one motion. \"I'll bring " +
                  "the book.\"\n\n" +
                  "Perrin walks beside you as far as the last fence, and stops " +
                  "there. \"This is where I stop,\" {bHe} say{bVs}. \"Nothing in the book " +
                  "about singing to cages.\"\n\n" + e07cEnBody } },
    { when: { bAsk: "stay" },
      text: { zh: "“是啊。”{bHe}答道。承认这一点，显然让{bHim}费了些力气，“你说得一点没错。”\n\n" + e07cZhBody,
              en: "\"It is,\" {bHe} agree{bVs}. It costs {bHim} something to agree. \"You're exactly right.\"\n\nThe camp is a mile out, past the last fence: six tents, a ring of pickets, and the cage sitting alone in the firelight like a thing the fire was built to apologize for. The charms on the bars tick and shimmer. Somewhere a sentry coughs, bored into carelessness.\n\nThe eye is open. It was waiting.\n\n\"The soft-foot,\" says the dragon, and its voice comes up through the ground more than the air, a voice kept in a coal cellar for sixty years. \"Come to let me out? The whole village is rehearsing it.\" A ripple goes down the faded scales — laughter, or the place where laughter lived. \"Don't.\"" } },
    { when: { bAsk: "ballad" },
      text: { zh: "{bHe}没有回答，只是久久地看着你，像是在验一枚硬币的真假。\n\n然后，{bHe}压低了嗓子，免得吵醒那些不该吵醒的人家，轻声给你唱了六小节和龙毫不相干的歌。\n\n那是一首老路歌，唱的是初霜时节，磨坊主的女儿和卖毛线的女人下山来，一个等在桥这头，一个等在桥那头。\n\n这是一首傻气的歌，可它是六十年来你听到的第一样与你无关的东西，你觉得自己能一连听上一个星期。\n\n唱到一半，{bHe}忽然不好意思起来，像个被当场逮住的贼一样停了下来。“好了，”{bHe}说，“现在你知道我也会唱别的了。”\n\n" + e07cZhBody,
              en: "{bHe} give{bVs} no answer. {bHe} look{bVs} at you for a long moment — someone checking whether a coin is real — and then, softly, so as not to wake the wrong houses, {bHe} sing{bVs} six bars of something with no dragons in it. An old road song — the miller's daughter, and the wool-woman who comes down with the first frost, one waiting at this end of the bridge, one at that. A foolish one. It is the first thing you have heard in sixty years that is not about you, and you could listen to it for a week.\n\n{bHe} stop{bVs} mid-bar, embarrassed as a thief. \"Well,\" {bHe} say{bVs}. \"Now you know I can sing other things.\"\n\nThe camp is a mile out, past the last fence: six tents, a ring of pickets, and the cage sitting alone in the firelight like a thing the fire was built to apologize for. The charms on the bars tick and shimmer. Somewhere a sentry coughs, bored into carelessness.\n\nThe eye is open. It was waiting.\n\n\"The soft-foot,\" says the dragon, and its voice comes up through the ground more than the air, a voice kept in a coal cellar for sixty years. \"Come to let me out? The whole village is rehearsing it.\" A ripple goes down the faded scales — laughter, or the place where laughter lived. \"Don't.\"" } },
    { text: { zh: e07cZhBody, en: e07cEnBody } }
  ],
  choices: [
    { text: { zh: "“你为什么不让我放你出去？”", en: "\"Why won't you let me set you free?\"" },
      set: { cAsk: "why", cageTalk: true }, next: "e07c2" },
    { text: { zh: "“就算你不肯，我也能打开笼子。”",
              en: "\"I could open it anyway.\"" },
      set: { cAsk: "force", cageTalk: true }, next: "e07c2" },
    { text: { zh: "“我给你带了样东西。”", en: "\"I brought you something.\"" },
      set: { cAsk: "feed", feedC: true }, next: "e07c2" }
  ]
});

// ============================================================
//  e07c2 · 软脚（去留）
// ============================================================
EVENTS.push({
  id: "e07c2",
  title: { zh: "两脚龙", en: "Soft-Foot" },
  text: [
    { when: { cAsk: "why" },
      text: { zh: "“因为我在你那道悬崖底下待了六十年，两脚龙。两个星期前，他们把我挖出来，塞进箱子，又把我往回送。送往托尔岗。真是走运。”\n\n那只灯黄色的眼睛在火光里转向你，“早在你们村子围起栅栏之前，我就想回到那座山底下去了。让他们带我去吧。”\n\n" + e07c2ZhTail,
              en: "\"Because I've spent sixty years under your cliff, soft-foot, and " +
                  "two weeks ago they dug me out, put me in a box, and pointed me " +
                  "back at it. At the Tor. Look at my luck.\" The eye turns, " +
                  "lamp-yellow in the firelight. \"I've been trying to get back " +
                  "under that mountain since before your village had fences. Let " +
                  "them carry me.\"\n\n" + e07c2EnTail } },
    { when: { cAsk: "force" },
      text: { zh: "“打开啊。然后等到天亮，田里会有士兵，山脊上会有狗，还会多出一个关于两条龙的新故事，谁也活不到听完它的那一天。”\n\n它压低了声音，不知为何这反倒更糟，“我不是在逃离那座山，两脚龙。我是在回去。问题是，你来不来？”\n\n" + e07c2ZhTail,
              en: "\"Open it. And by morning there'd be soldiers in the fields, dogs on the ridges, and a story about two dragons that no one will ever finish hearing.\" The voice goes softer, which is somehow worse. \"I'm not running from the mountain, soft-foot. I'm going to it. The question is whether you're coming with me.\"\n\nThe fire spits. A sentry shifts his weight. The eye watches you from the firelight, in no hurry at all.\n\nSix tents. A ring of pickets. A road back to the village." } },
    { when: { cAsk: "feed" },
      text: { zh: "你把面包从栏杆间递了进去。\n\n那颗巨大的头颅缓缓低下来，就像一座小礼拜堂在端详一粒面包屑。\n\n“面包，”它说，“六十年了，他们还是送面包。”话虽这么说，它还是把一整块都吃完了。\n\n" + e07c2ZhTail,
              en: "You pass the bread through the bars. The great head comes down to it slowly — a thing the size of a chapel investigating a crumb. \"Bread,\" it says at last. \"Sixty years, and they send bread.\" But it eats all of it.\n\nThe fire spits. A sentry shifts his weight. The eye watches you from the firelight, in no hurry at all.\n\nSix tents. A ring of pickets. A road back to the village." } },
    { text: { zh: e07c2ZhTail, en: e07c2EnTail } }
  ],
  choices: [
    { text: { zh: "“那我跟你一起去。去托尔岗，去看那底下埋着什么。”",
              en: "\"Then I'm coming with you. To the Tor, and whatever's under it.\"" },
      set: { inPartyC: true }, next: "e07c4" },
    { text: { zh: "“我去。但有一个条件：从现在到圣地，每天晚上你都得回答我一个问题。”",
              en: "\"I'll come. But a rule: from here to the holy ground, you answer me one question every night.\"" },
      set: { inPartyC: true, cQpact: true }, next: "e07c4" },
    { text: { zh: "“我向来独来独往。”", en: "\"I travel alone.\"" },
      next: "e07c4" }
  ]
});

// ============================================================
//  e07c4 · 夜话（随行者段落：A/B/C 入队组合变体）
// ============================================================

// 随行者段落常量（按组合拼接）
const sZhAB =
  "守祠人和歌手一路沉默着往回走，直到教堂的影子吞没了道路。终于，其中一个开了口：“明天。”\n\n“明天怎么了？”\n\n“……不知道。就是，明天。”\n\n做了一辈子邻居的两个人，头一回听上去像是在用同一副嗓子说话。";
const sEnAB =
  "The keeper and the singer walk the whole way in silence, until the church's shadow " +
  "swallows the road. \"Tomorrow,\" one of them says. \"What about it?\" \"Don't know. " +
  "Just — tomorrow.\" Two neighbors of sixty years, speaking in one voice for the " +
  "first time.\n\n";
const sZhA =
  "守祠人把外套裹紧了些。“我这辈子从没在夜里走过这么远，”{aHe}说，“把责任在屋里关得太久，人就忘了该怎么站在外头。”";
const sEnA =
  "The keeper pulls {aHis} coat tighter. \"I have not walked this far at night in my " +
  "life,\" {aHe} say{aVs}. \"When the duty stays indoors, one forgets where to put " +
  "oneself.\"\n\n";
const sZhB =
  "佩兰哼着一支既没找到调子、也没找到词的歌，不是那首屠龙歌，而是另一首，一首{bHe}还没有捉住的歌。\n\n“歌词对不上，”{bHe}忽然说，“我{bGrand}当年是真心实意抄下来的。一样东西信了六十年，结果是错的——总得有人给老人家捎一句实话。”";
const sEnB =
  "Perrin hums something that has found neither tune nor words — not the " +
  "slaying-song; some other one, the one {bHe} {bIs} yet to find. \"The verses don't " +
  "add up,\" {bHe} say{bVs}, suddenly. \"My {bGrand} copied them believing. When a " +
  "belief has been wrong for sixty years, somebody owes {bGrand} the telling. " +
  "Somebody does.\"\n\n";
const sZhC =
  "在雾的那一头，营地的方向，那只眼睛大概还睁着。\n\n你已经答应过与它同行，一边走一边想：他们要带它去的地方，正是埋着你答案的地方，至少这一段路，你们是同路的。";
const sEnC =
  "Somewhere past the mist, toward the camp, the eye is probably still open. You " +
  "agreed to travel together. You walk and think it over: the place they are " +
  "taking it is the place your answers are buried — for this leg of the road at " +
  "least, you and it are going the same way.\n\n";
const sZhAlone =
  "夜路上没有什么可以作伴，这正是你六十年前熟悉的那种夜晚。";
const sEnAlone =
  "The night road keeps no one at your side. The kind of night you were used to, " +
  "sixty years ago.\n\n";

EVENTS.push({
  id: "e07c4",
  title: { zh: "夜谈", en: "The Night Talk" },
  text: [
    { when: { inPartyA: true, inPartyB: true, inPartyC: true },
      text: { zh: sZhAB + "\n\n" + sZhC, en: sEnAB + sEnC } },
    { when: { inPartyA: true, inPartyB: true },
      text: { zh: sZhAB, en: sEnAB } },
    { when: { inPartyA: true, inPartyC: true },
      text: { zh: sZhA + "\n\n" + sZhC, en: sEnA + sEnC } },
    { when: { inPartyB: true, inPartyC: true },
      text: { zh: sZhB + "\n\n" + sZhC, en: sEnB + sEnC } },
    { when: { inPartyA: true },
      text: { zh: sZhA, en: sEnA } },
    { when: { inPartyB: true },
      text: { zh: sZhB, en: sEnB } },
    { when: { inPartyC: true },
      text: { zh: sZhC, en: sEnC } },
    { text: { zh: sZhAlone, en: sEnAlone } }
  ],
  choices: [
    { text: { zh: "把剩下的夜路走完。", en: "Walk the rest of your night." },
      next: "e07c5" }
  ]
});

// ============================================================
//  e07c5 · 夜宿（桥段#11：龙身觉得人的床太软太窄）
// ============================================================
EVENTS.push({
  id: "e07c5",
  title: { zh: "龙睡在哪儿", en: "Where a Dragon Sleeps" },
  text: {
    zh: "夜已经深了。白天结束以后，往后的钟点都属于你，可这具借来的人身，该睡在哪儿呢？",
    en: "The night bottoms out. The day is done, and the small hours are yours — " +
        "this borrowed body of yours: where does it sleep?"
  },
  choices: [
    { text: { zh: "谷仓里。干草暖和，借来的鼻子能忍一夜草料味。",
              en: "The barn. The hay is warm, and the borrowed nose will put up with " +
                  "the smell of feed for one night." },
      set: { bedChoice: "barn" }, next: "e07d" },
    { text: { zh: "教堂的末排长椅。硬木硌得后背生疼——很好。疼痛足以让梦里的那条龙闭嘴。",
              en: "The back pew of the church. The bench bites the back — good. The " +
                  "bite keeps a dream from talking dragon." },
      set: { bedChoice: "church" }, next: "e07d" },
    { text: { zh: "不睡在村里。翻过栅栏上山，回到悬崖下的旧巢——至少有一夜，睡在你自己的皮里。",
              en: "Not in the village. Out past the fence, up the mountain, back to " +
                  "the den below the cliff — sleep in your own shape, one night." },
      set: { bedChoice: "den" }, next: "e07d" }
  ]
});

// ============================================================
//  e07d · 明日何往（态度三选 · 第二章入口）
// ============================================================
EVENTS.push({
  id: "e07d",
  title: { zh: "明日何往", en: "Which Way Tomorrow" },
  text: [
    // C 同行＋床位认领：营地回声 → 认领句 → 龙式清点（先匹配具体组合）
    { when: { inPartyC: true, bedChoice: "barn" },
      text: { zh: e07dZhCHead + e07dZhBed.barn + "\n\n" + e07dZhTail,
              en: "Before you lie down, that moment at the camp comes back to you: you are only forty yards gone when the dragon settles its length along the bars. \"Now that is the first thing anyone in this valley has said to me in two weeks that wasn't a prayer or an order.\"\n\nAnd then, to your back — not loudly, exactly — just loud enough for you to hear: \"Soft-foot. Ask them who lit the first fire.\"\n\nThe barn hay catches you — softer than you remembered, and warmer.\n\nYou sleep the way dragons sleep, which is to say: you close your eyes and take inventory of everything you have heard. The song. The badge. The coins. The cliff that isn't where the song says it is. The bread. Sixty years is not so long as it turns out — long enough for a rescue to become a murder, and short enough that the oldest woman in the village still stirs her soup with the same hand.\n\nBelow the hill, the village sleeps in its song." } },
    { when: { inPartyC: true, bedChoice: "church" },
      text: { zh: e07dZhCHead + e07dZhBed.church + "\n\n" + e07dZhTail,
              en: "Before you lie down, that moment at the camp comes back to you: you are only forty yards gone when the dragon settles its length along the bars. \"Now that is the first thing anyone in this valley has said to me in two weeks that wasn't a prayer or an order.\"\n\nAnd then, to your back — not loudly, exactly — just loud enough for you to hear: \"Soft-foot. Ask them who lit the first fire.\"\n\nThe empty church keeps only its saints. You can't make out their faces, and they can't make out yours.\n\nYou sleep the way dragons sleep, which is to say: you close your eyes and take inventory of everything you have heard. The song. The badge. The coins. The cliff that isn't where the song says it is. The bread. Sixty years is not so long as it turns out — long enough for a rescue to become a murder, and short enough that the oldest woman in the village still stirs her soup with the same hand.\n\nBelow the hill, the village sleeps in its song." } },
    { when: { inPartyC: true, bedChoice: "den" },
      text: { zh: e07dZhCHead + e07dZhBed.den + "\n\n" + e07dZhTail,
              en: "Before you lie down, that moment at the camp comes back to you: you are only forty yards gone when the dragon settles its length along the bars. \"Now that is the first thing anyone in this valley has said to me in two weeks that wasn't a prayer or an order.\"\n\nAnd then, to your back — not loudly, exactly — just loud enough for you to hear: \"Soft-foot. Ask them who lit the first fire.\"\n\nThe old den still knows you — you fold yourself back into the hollow you wore in the stone, and it fits.\n\nYou sleep the way dragons sleep, which is to say: you close your eyes and take inventory of everything you have heard. The song. The badge. The coins. The cliff that isn't where the song says it is. The bread. Sixty years is not so long as it turns out — long enough for a rescue to become a murder, and short enough that the oldest woman in the village still stirs her soup with the same hand.\n\nBelow the hill, the village sleeps in its song." } },
    // 仅床位认领（未与 C 同行）
    { when: { bedChoice: "barn" },
      text: { zh: e07dZhBed.barn + "\n\n" + e07dZhTail,
              en: e07dEnBed.barn + "\n\n" + e07dEnTail } },
    { when: { bedChoice: "church" },
      text: { zh: e07dZhBed.church + "\n\n" + e07dZhTail,
              en: e07dEnBed.church + "\n\n" + e07dEnTail } },
    { when: { bedChoice: "den" },
      text: { zh: e07dZhBed.den + "\n\n" + e07dZhTail,
              en: e07dEnBed.den + "\n\n" + e07dEnTail } },
    // 防御兜底（e07c5 是唯一前驱，正常流程不可达）
    { when: { inPartyC: true },
      text: { zh: e07dZhCHead + e07dZhTail, en: "Before you lie down, that moment at the camp comes back to you: you are only forty yards gone when the dragon settles its length along the bars. \"Now that is the first thing anyone in this valley has said to me in two weeks that wasn't a prayer or an order.\"\n\nAnd then, to your back — not loudly, exactly — just loud enough for you to hear: \"Soft-foot. Ask them who lit the first fire.\"\n\nYou sleep the way dragons sleep, which is to say: you close your eyes and take inventory of everything you have heard. The song. The badge. The coins. The cliff that isn't where the song says it is. The bread. Sixty years is not so long as it turns out — long enough for a rescue to become a murder, and short enough that the oldest woman in the village still stirs her soup with the same hand.\n\nBelow the hill, the village sleeps in its song." } },
    { text: { zh: e07dZhTail, en: e07dEnTail } }
  ],
  choices: [
    { text: { zh: "“他们想要一个英雄。我就给他们一个。”",
              en: "\"They want a hero. Then let them have one.\"" },
      set: { path: "comply" }, next: "ch2a" },
    { text: { zh: "“这首歌从头就唱错了。我要当着所有人的面，把它揭穿。”",
              en: "\"The song breaks on a wrong beat. I'm going to break it where everyone can hear.\"" },
      set: { path: "probe" }, next: "ch2b" },
    { text: { zh: "“让他们接着唱吧。那道悬崖，是我欠他们的。”",
              en: "\"Let them sing. The cliff is what I owe.\"" },
      set: { path: "flee" }, next: "ch2c" }
  ]
});

