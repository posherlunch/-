// ============================================================
//  第三章 · 破链
//  zh：谷歌翻译稿＋人工修硬伤   en：英文原稿（待润色）
//  链：ch3p1 上山（三线汇合）→ ch3a 圣地 → ch3b 剑誓
//      → ch3c 引信 → ch3d 破链与火 → ch3e 踩踏与鞋
//      → ch3f 弩阵与皮囊 → ch3g 天空与选择（终拍）
//      → endA/endB/endC/endH → ENDING_CHECK
//  ch3p2 守夜祷：仅 A 线经过（a4 → ch3p2 → a5），在村里前夜。
// ============================================================

// ---------- P1 共享正文段 ----------

// P1 开场（大路一天）
const p1ZhOpen =
  "沿着大路上托尔岗，得走上整整一天。队伍就像一头慢吞吞的巨兽，牛车、铁笼、四列王家卫兵走在前头，后面跟着穿着节日衣裳、一路唱着歌的村民。\n\n一个讲了六十年的故事，正一步一步走上山，去给自己收尾。\n\n磨坊边那道悬崖从你的左手边缓缓移过，那才是真正的那道崖，从来没有哪首歌叫过它的名字。肩头那片松鳞底下的东西朝它微微偏了过去，就像旧伤总在变天时隐隐作痛，可你没有停步。树梢之上，山顶的黑石已经露了出来。";
const p1EnOpen =
  "The big road up the Tor takes the whole day, and the procession is a slow beast: oxen, " +
  "the cage, the royal guard in files of four, and the village trailing behind in its " +
  "festival clothes, singing. Sixty years of a story, walking up a mountain to be finished.\n\n" +
  "The cliff by the mill slides past on your left — the real one, the one no song has ever " +
  "named. Something under the loose scale at your shoulder leans toward it, the way old " +
  "aches lean toward weather. You do not stop. The black stones of the summit are already " +
  "in view above the trees.";

// P1 收尾
const p1ZhClose =
  "\n\n笼中的龙望着树木一棵棵往后退去，一次也没有看向山顶。\n\n它看上去，倒像是一个正在回家的东西。";
const p1EnClose =
  "\n\nInside the cage, the dragon watches the trees go by. It has not looked at the summit " +
  "once. It looks, instead, like a thing on its way home.";

// ============================================================
//  ch3p1 · 上山路（三线汇合入口）
// ============================================================
EVENTS.push({
  id: "ch3p1",
  title: { zh: "上山路", en: "The Road Up" },
  text: [
    { when: { stayEnd: true },
      text: { zh: p1ZhOpen +
                "\n\n你一路走在铁笼旁边，它的眼睛也一路睁着。\n\n只有一回，在第二道折弯处，那副没有展开的翅肩朝你偏了半寸。\n\n你们之间的对话，就只有这么多，可这已经够了。" + p1ZhClose,
              en: "The big road up the Tor takes the whole day, and the procession is a slow beast: oxen, the cage, the royal guard in files of four, and the village trailing behind in its festival clothes, singing. Sixty years of a story, walking up a mountain to be finished.\n\nThe cliff by the mill slides past on your left — the real one, the one no song has ever named. Something under the loose scale at your shoulder leans toward it, the way old aches lean toward weather. You do not stop. The black stones of the summit are already in view above the trees.\n\nYou have walked beside the cage the whole way. Its eye has been open the whole way. Once, on the second switchback, the shoulder of the folded wing turned half an inch toward you, and that was the whole of the conversation, and it was enough.\n\nInside the cage, the dragon watches the trees go by. It has not looked at the summit once. It looks, instead, like a thing on its way home." } },
    { when: { fleeEnd: true },
      text: { zh: p1ZhOpen +
                "\n\n你原本打算让他们自己去的，是渡口边磨坊的那口钟拽住了你。\n\n那钟声破旧而欢快，又带着一股不敲不行的尽责劲儿，于是你就像一个终于不再跟旧债较劲的人那样，走到队尾，跟了上去。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nYou meant to let them go without you. The mill bell caught you at the ford — " +
                  "a cracked, cheerful, obligatory sound — and you joined the back of the " +
                  "procession like a man returning to a debt he has stopped disputing." + p1EnClose } },
    { when: { truthEnd: true },
      text: { zh: p1ZhOpen +
                "\n\n你回到村里，把真相讲给了一个空荡荡的村子听。听完的只有一条狗和几只鸡，至少那条狗看起来像是信了。后来，钟声又找上了你，于是此刻，你跟在一个自己拒绝加入的故事后头，口袋里还揣着一份墨迹未干的供词。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nYou went back and told the truth to an empty village. A dog and some hens " +
                  "heard you out; the dog at least believed you. Then the bell found you, and now " +
                  "you walk at the rear of a story you declined to be part of, with your confession " +
                  "still wet in your pocket." + p1EnClose } },
    { when: { ridgeGo: true },
      text: { zh: p1ZhOpen +
                "\n\n你先绕了一段远路，翻过焦黑的山肩，回到了旧巢。六十年过去，那里除了光线，什么都没有变。\n\n你用真身蜷进自己压在石头里的那个凹槽，真正地休息了一个钟头，然后起身奔跑，在第三道折弯处追上了队伍，身上还沾着自己床铺里的灰。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nYou took the long way first — back over the burned shoulder, to the den. " +
                  "Nothing had moved in sixty years except the light. You slept one hour in the " +
                  "dent your own weight wore into the stone — one hour of the true rest of your " +
                  "true shape — then ran, and caught the procession at the third switchback, " +
                  "wearing the dust of your own bed." + p1EnClose } },
    // charmGiven（a5 亲手挂符铃）：祝福句改为符铃措辞，并追加符铃回收段
    { when: { path: "comply", charmGiven: true },
      text: { zh: p1ZhOpen +
                "\n\n昨夜宴席的气味还沾在你的斗篷上。祝福的话你没有说，拒绝的话你也没有说，你只是抬起了手，做了一件手能做的事。昨夜守夜祈祷时的那三句话，此刻也还含在你嘴里：火已熄，剑已举，世已安。\n\n它们比那首歌更老，也更简单，而你正穿着这几句话上山，就像穿着一件替别人裁的外套。\n\n笼顶新添的那只符铃，是你亲手挂上去的。一路上，它跟着满笼的符铃一起叮当作响，分不出彼此，只有你和笼子里的那一位知道，这一只是不同的。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nThe feast still clings to your cloak. You spoke no blessing and no " +
                  "refusal — you only lifted your hand, and let the hand do what it could. " +
                  "The three lines of the vigil prayer are still in your mouth from last " +
                  "night, older than the song and simpler: the fire went out; the sword was " +
                  "raised; the world was kept. You walk up the mountain inside a sentence " +
                  "like that, and it fits like a coat tailored for someone else.\n\nThe " +
                  "newest charm on the cage's crown is the one you hung there yourself. All " +
                  "the way up it rings among the others, indistinguishable — only you, and " +
                  "the one inside the bars, know this one is different." + p1EnClose } },
    { when: { path: "comply" },
      text: { zh: p1ZhOpen +
                "\n\n昨夜宴席的气味还沾在你的斗篷上，而你给出的、或是拒绝给出的那句祝福，也还压在你的齿后。昨夜守夜祈祷时的那三句话，此刻也还含在你嘴里：火已熄，剑已举，世已安。\n\n它们比那首歌更老，也更简单，而你正穿着这几句话上山，就像穿着一件替别人裁的外套。" + p1ZhClose,
              en: "The big road up the Tor takes the whole day, and the procession is a slow beast: oxen, the cage, the royal guard in files of four, and the village trailing behind in its festival clothes, singing. Sixty years of a story, walking up a mountain to be finished.\n\nThe cliff by the mill slides past on your left — the real one, the one no song has ever named. Something under the loose scale at your shoulder leans toward it, the way old aches lean toward weather. You do not stop. The black stones of the summit are already in view above the trees.\n\nThe feast still clings to your cloak, and the blessing you gave — or refused — still sits somewhere behind your teeth. The three lines of the vigil prayer are still in your mouth from last night, older than the song and simpler: the fire went out; the sword was raised; the world was kept. You walk up the mountain inside a sentence like that, and it fits like a coat tailored for someone else.\n\nInside the cage, the dragon watches the trees go by. It has not looked at the summit once. It looks, instead, like a thing on its way home." } },
    { when: { path: "probe", swordShown: true },
      text: { zh: p1ZhOpen +
                "\n\n话总是比队伍爬得快。在你身后，两个农夫还在争论那把剑到底有没有刃。信念是一种倔强的庄稼，一场旱灾晒不死它，但它至少不再往上长了。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nWord has climbed the road faster than the procession. Behind you, two " +
                  "farmers are still arguing about the sword — the edge of it, or the lack of one. " +
                  "Belief is a stubborn crop; it does not die of one dry season. But it has " +
                  "stopped growing." + p1EnClose } },
    { when: { path: "probe", dragonSpeaks: true },
      text: { zh: p1ZhOpen +
                "\n\n龙会说话的消息，比这条山路传得还要快。半个村子决定装作没听见，另一半人则一直盯着铁笼，就像盯着一扇忽然学会了开口的门。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nWord of the dragon's voice has climbed faster than the road. Half the " +
                  "village has decided not to have heard it. The other half keeps looking at the " +
                  "cage the way one looks at a door that has learned to speak." + p1EnClose } },
    { when: { path: "probe" },
      text: { zh: p1ZhOpen +
                "\n\n人群里有人把脸埋进披肩里哭，也没有人去拦。\n\n你在广场上说的那些话，如今散落在整座山上，借着窃窃私语沿着队伍往上爬，一路把那首歌磨出了一个个窟窿。" + p1ZhClose,
              en: p1EnOpen +
                  "\n\nSomeone in the crowd is weeping into her shawl, and no one stops her. Your " +
                  "words from the square are loose on this mountain now, traveling the column in " +
                  "whispers, wearing holes in the song as they go." + p1EnClose } },
    { text: { zh: p1ZhOpen + p1ZhClose, en: p1EnOpen + p1EnClose } }
  ],
  choices: [
    { text: { zh: "走在最前头，那是英雄的位置。",
              en: "Walk at the front, where a hero walks." },
      set: { paradePos: "front" }, next: "aConfess" },
    { text: { zh: "走在最后头，那是见证者的位置。",
              en: "Walk at the rear, where a witness walks." },
      set: { paradePos: "back" }, next: "aConfess" },
    { text: { zh: "走在铁笼旁边，那是你自己的位置。",
              en: "Walk beside the cage, where you walk." },
      set: { paradePos: "cage" }, next: "aConfess" }
  ]
});

// ============================================================
//  aConfess · 第一个名字（A 告白页：黄昏扎营，真选择双版本；
//  告白版＝inPartyA＋aHeart；战友版＝仅 inPartyA；兜底＝无 A）
// ============================================================
EVENTS.push({
  id: "aConfess",
  title: { zh: "第一个名字", en: "The First Name" },
  text: [
    { when: { inPartyA: true, aHeart: true, nameChoice: "byface" },
      text: { zh: "暮色落下，帐篷一顶顶地支了起来。\n\n守祠人走到你站岗的地方，在你身边停下，酝酿了很久，{aHe}遇上难办的事，向来如此。\n\n然后，那个词终于来了，那是你的名字。不是“英雄”，不是村子给那张脸起的称号，而是你真正的名字，{aHe}说得很慢，就像在轻轻放下一件易碎的东西。\n\n在你们身后，营地正在学着入睡，而你们俩没有。",
              en: "Dusk, and the tents going up one by one. The keeper comes to where you stand watch and settles in beside you, working up to something the way {aHe} work{aVs} up to a difficult corner.\n\nThen it comes: your name. Not \"hero\" — the one the village gave the face, said slowly, the way you set down something breakable." } },
    { when: { inPartyA: true, aHeart: true, nameChoice: "nobody" },
      text: { zh: "暮色落下，帐篷一顶顶地支了起来。\n\n守祠人过来陪你站岗，沉默了很久，像是在为一句难以出口的话攒着力气。\n\n然后{aHe}终于问道：“我该怎么叫你？不要歌里那个词，要你自己的。”\n\n一个替别人守了一辈子故事的人，终于开口向你要一个只属于你的名字。\n\n在你们身后，营地正在学着入睡，而你们俩没有。",
              en: "Dusk, and the tents going up one by one. The keeper comes to stand beside you at the watch, and works up to something for a long moment.\n\nThen — not \"hero\" — {aHe} ask{aVs}: \"What do I call you? Not the song's word. Yours.\" Sixty years minding other people's story, and {aHe} {aIs} asking you for a name that is yours alone." } },
    { when: { inPartyA: true, aHeart: true, nameChoice: "iorth" },
      text: { zh: "暮色落下，帐篷一顶顶地支了起来。\n\n守祠人过来陪你站岗，沉默了很久。\n\n然后{aHe}叫了你的名字。不是“英雄”，也不是“伊奥瑞斯”，而是介于两者之间的某种叫法，带着一种只有{aHe}才给得出的分量，轻得就像一支护在掌心、走过风口的蜡烛。\n\n在你们身后，营地正在学着入睡，而你们俩没有。",
              en: "Dusk, and the tents going up one by one. The keeper comes to stand beside you at the watch, and works up to something for a long moment.\n\nThen {aHe} say{aVs} your name — not \"hero,\" and not Ioreth either. Something in between, with a weight only {aHe} know{aVs} how to give, light as a candle shielded in a palm and carried through wind." } },
    { when: { inPartyA: true, aHeart: true, named: true },
      text: { zh: "暮色落下，帐篷一顶顶地支了起来。\n\n守祠人过来陪你站岗，沉默了很久。\n\n然后{aHe}叫了你的名字：{name}。不是“英雄”。\n\n你在老兵的火堆边随口报出的那个词，到了{aHe}嘴里，第一次有了被认真收藏起来的样子。\n\n在你们身后，营地正在学着入睡，而你们俩没有。",
              en: "Dusk, and the tents going up one by one. The keeper comes to stand beside you at the watch, and works up to something for a long moment.\n\nThen {aHe} say{aVs} your name — {name}. Not \"hero.\" The word you tossed to a campfire, kept for the first time like it was worth keeping." } },
    { when: { inPartyA: true, aHeart: true },
      text: { zh: "暮色落下，帐篷一顶顶地支了起来。\n\n守祠人过来陪你站岗，沉默了很久。\n\n然后{aHe}开口了，叫的不是“英雄”，而是一个很短的名字，只属于你们两个。\n\n在你们身后，营地正在学着入睡，而你们俩没有。",
              en: "Dusk, and the tents going up one by one. The keeper comes to stand beside you at the watch, and works up to something for a long moment.\n\nThen {aHe} speak{aVs} — and it is not \"hero.\" It is a name, a short one, that belongs to the two of you alone." } },
    { when: { inPartyA: true },
      text: { zh: "黄昏时分，帐篷一顶顶地支了起来。\n\n守祠人绕着营地巡视，仔细得像是在查账，数木桩，数绳索，数一切数得清的东西，因为营地正中那个关在笼里的东西，是怎么也算不清的。",
              en: "Dusk, and the tents going up one by one. The keeper walks the " +
                  "camp's edge with a ledger's attention — counting pegs, counting " +
                  "ropes, counting everything that can be counted, because the " +
                  "thing that cannot be counted is standing in a cage at the " +
                  "center of the camp." } },
    { text: { zh: "黄昏时分，帐篷照着老规矩支了起来，骡子发着牢骚，划到第二根火柴，火才点着。山在上头等着，耐心得就像早已把明天读完了一样。",
              en: "Dusk. The tents go up in the old order, mules complaining, the " +
                  "fire catching on the second match. The mountain waits above " +
                  "with the patience of a thing that has already read tomorrow." } }
  ],
  choices: [
    { text: { zh: "你应了。那个名字一旦由你自己接住，分量就不一样了。",
              en: "You answer it. Out loud. The name carries differently with you " +
                  "holding it." },
      when: { inPartyA: true, aHeart: true }, set: { aLove: true }, next: "aKiss" },
    { text: { zh: "你没有回答，只是伸出手，让那只擦了一辈子石头、磨出老茧的手找到你的手。",
              en: "You don't answer. You put out your hand, and the calluses from " +
                  "sixty years of polishing find it." },
      when: { inPartyA: true, aHeart: true }, set: { aBond: "hand" }, next: "ch3p1b" },
    { text: { zh: "你轻轻退开半步。有些话，需要比今晚更长的夜。",
              en: "You step back, gentle about it. Some words need more night " +
                  "than this one has." },
      when: { inPartyA: true, aHeart: true }, set: { aBond: "step" }, next: "ch3p1b" },
    { text: { zh: "你们一言不发，一起守完这一班岗。",
              en: "Together, wordless, you take the same watch." },
      when: { inPartyA: true }, hide: { aHeart: true }, next: "ch3p1b" },
    { text: { zh: "“过了明天，”你问，“那座祠堂会怎么样？”",
              en: "\"After tomorrow,\" you ask, \"what happens to the shrine?\"" },
      when: { inPartyA: true }, hide: { aHeart: true }, next: "ch3p1b" },
    { text: { zh: "你绕营地走了一圈，回去歇下。",
              en: "You walk the camp once, and turn in." },
      next: "ch3p1b" }
  ]
});

// ============================================================
//  aKiss · 歌里没唱（A 亲密页：接吻＋黑屏；仅 aLove 路径经过）
// ============================================================
EVENTS.push({
  id: "aKiss",
  title: { zh: "歌里没有的那一节", en: "What the Song Left Out" },
  text: {
    zh: "那个名字还悬在你们之间，距离却已经没有了。\n\n这个吻起初和守祠人做的每一件事一样，短促、克制而小心，然后忽然之间，就一点也不克制了。\n\n不知哪里的一支蜡烛灭了，你没有看见是谁的手指掐灭了烛芯。\n\n歌里没有这一节。\n\n它也从来不需要有。",
    en: "The name is still hanging in the air between you when the distance " +
        "closes. The kiss is brief, and careful, the way the keeper does " +
        "everything — and then not careful at all.\n\n" +
        "Somewhere, a candle goes out. You do not see whose fingers pinched it.\n\n" +
        "The song has no verse for this. It never needed one."
  },
  choices: [
    { text: { zh: "还有一班岗要守。只是这一回，你们站得比先前近。",
              en: "There is a watch to stand. You stand it closer than before." },
      next: "ch3p1b" }
  ]
});

// ============================================================
//  ch3p1b · 夜访（桥段#16：仪式前夜的隔笼再谈）
// ============================================================
EVENTS.push({
  id: "ch3p1b",
  title: { zh: "第二次探访", en: "The Second Visit" },
  text: [
    { when: { inPartyC: true, cQpact: true },
      text: { zh: "队伍在一片高处的草坡上扎营，夜来得格外早。篝火围成一圈，铁笼就在正中，火烧得那么旺，像是专门在向什么东西赔罪。\n\n哨兵咳得比在低处时更凶，离圣地越近，人就睡得越不安稳。\n\n你本来就没打算睡，它也没打算让你睡。木桩外头，那只灯黄色的眼睛睁着。“我们的约定还作数，”它省掉了所有的客套，“前几晚欠你的也算上。今晚的问题，问吧。”",
              en: "Night drops early on the high pasture where the procession camps. Fires in a ring, the cage at the ring's heart — the whole circle of flame lit, it seems, as an apology to one thing. The sentries cough more than they did on the low road: the nearer the holy ground, the worse men sleep.\n\nYou did not plan to sleep. It has not planned to let you. Beyond the pickets, the lamp-yellow eye is open. \"Our rule still holds,\" it says, sparing you the courtesies. \"The nights I owe you count too. Tonight's question — ask.\"" } },
    { when: { inPartyC: true },
      text: { zh: "队伍在一片高处的草坡上扎营，夜来得格外早。篝火围成一圈，铁笼就在正中，火烧得那么旺，像是专门在向什么东西赔罪。\n\n哨兵咳得比在低处时更凶，离圣地越近，人就睡得越不安稳。\n\n你本来就没打算睡，它也没打算让你睡。黑暗里，那只灯黄色的眼睛睁着。“你也没睡。”\n\n它说，听上去并不像是在问，“很好。\n\n一个睡不着的见证者，胜过一个睡得着的村子。”",
              en: "Night drops early on the high pasture where the procession camps. Fires in a ring, the cage at the ring's heart — the whole circle of flame lit, it seems, as an apology to one thing. The sentries cough more than they did on the low road: the nearer the holy ground, the worse men sleep.\n\nYou did not plan to sleep. It has not planned to let you. Beyond the pickets, through the dark, the lamp-yellow eye is open. \"You too,\" it says — not a question. \"Good. One witness who cannot sleep is worth more than a village that can.\"" } },
    { text: { zh: "队伍在一片高处的草坡上扎营，夜来得格外早。篝火围成一圈，铁笼就在正中，火烧得那么旺，像是专门在向什么东西赔罪。\n\n哨兵咳得比在低处时更凶，离圣地越近，人就睡得越不安稳。\n\n你装作去看骡子，哨兵也懒得理会一个睡不着的外乡人。\n\n那只眼睛隔着火光等着，等谁来都行，可来的偏偏又是你。“又是你。”\n\n它说，嗓音就像是从搁了六十年的地窖里翻上来的，“底下村子里睡不着的人那么多，两次走到我这堆火边的，却只有你。”",
              en: "Night drops early on the high pasture where the procession camps. Fires in " +
                  "a ring, the cage at the ring's heart — the whole circle of flame lit, it " +
                  "seems, as an apology to one thing. The sentries cough more than they did " +
                  "on the low road: the nearer the holy ground, the worse men sleep.\n\n" +
                  "You pretend to go check on the mules. The sentry cannot be bothered to " +
                  "mind a sleepless stranger. The eye waits behind the firelight — waiting " +
                  "for anyone, and getting you. \"Back again,\" it says, the voice coming up " +
                  "through the ground like something kept in a cellar for sixty years. \"A " +
                  "whole village of sleepless people in those houses below, and it is you " +
                  "who walks to my fire twice.\"" } }
  ],
  choices: [
    { text: { zh: "把今天的口粮从栏杆间递进去。",
              en: "Push the day's ration through the bars." },
      set: { nightVisit: "feed", cHeart: true }, next: "ch3p1c" },
    { text: { zh: "“那一天。跟我讲一点吧。”",
              en: "\"That day. Tell me some of it.\"" },
      set: { nightVisit: "ask" }, next: "ch3p1c" },
    { text: { zh: "什么也不说。就在栏杆外、火堆边坐下。",
              en: "Say nothing. Sit down on the fire's side of the bars." },
      set: { nightVisit: "watch", cHeart: true }, next: "ch3p1c" }
  ]
});

// ============================================================
//  ch3p1c · 隔栏（夜访反应）
// ============================================================
const nvZhHook =
  "\n\n天亮之前，哨兵换了三次班。";
const nvEnHook =
  "\n\nToward morning, the sentries change three times.";

EVENTS.push({
  id: "ch3p1c",
  title: { zh: "栏杆", en: "The Bars" },
  text: [
    { when: { nightVisit: "feed" },
      text: { zh: "“面包。”它说着，从你指间把面包接了过去，动作细巧得完全不像它那副身量。它当着你的面慢慢吃完，连一点渣都没有剩下。“好了，”最后它说，“现在我们俩当中，至少有一个的最后一餐不再只是传闻了。”" + nvZhHook,
              en: "\"Bread,\" it says, and takes it from your fingers with a delicacy " +
                  "nothing that size should own. It eats slowly, in front of you, all of " +
                  "it. \"There,\" it says at last. \"Now one of us has had a last supper " +
                  "that was not a rumor.\"" + nvEnHook } },
    { when: { nightVisit: "ask", dragonTruth: true },
      text: { zh: "那只眼睛缓缓合上，就像一本书被轻轻合拢。“这个问题，你已经问过一次了。”\n\n它说，“剩下的答案都在山上。明天，让山自己开口，让所有人都听见。”" + nvZhHook,
              en: "The eye closes, slowly, like a book shutting. \"You asked me once " +
                  "already,\" it says. \"The rest is on the mountain. Let it speak for " +
                  "itself, tomorrow, where everyone can hear it.\"" + nvEnHook } },
    { when: { nightVisit: "ask" },
      text: { zh: "那只眼睛缓缓合上，就像一本书被轻轻合拢。“去问山吧。”\n\n它说，“山比我记得清楚。我只记得它坠落时的那道光，还有光灭了以后，那些年有多安静。”" + nvZhHook,
              en: "The eye closes, slowly, like a book shutting. \"Ask the mountain,\" it " +
                  "says. \"The mountain remembers it better than I do. I only remember the " +
                  "light when it fell — and how quiet the years were, after the light " +
                  "stopped.\"" + nvEnHook } },
    { text: { zh: "你坐了下来，很久都没有人说话。\n\n最后，它压低了嗓子：“这就够了。六十年来，从没有谁在火的这一边陪我坐过。”接下来的沉默，成了你们之间最长的一次交谈，或许，也是最真的一次。" + nvZhHook,
              en: "You sit, and nothing is said for a long time. \"That is all it needed " +
                  "to be,\" it says at last, quieter. \"Sixty years, and nobody sat on " +
                  "this side of the fire.\" The silence afterward is the longest " +
                  "conversation the two of you have ever had. That, or the truest." +
                  nvEnHook } }
  ],
  choices: [
    { text: { zh: "火已经烧低了。你还不想睡。",
              en: "The fire is lower now. You are not ready to sleep." }, next: "bConfess" }
  ]
});

// ============================================================
//  bConfess · 佩兰的告白（深夜火堆；inPartyB+bHeart 时唱那支歌）
//  判定链：inPartyB → bHeart（点唱 ballad 或歌续章命名）→ 告白页 → bLove
// ============================================================
EVENTS.push({
  id: "bConfess",
  title: { zh: "唯一的听众", en: "An Audience of One" },
  text: [
    { when: { inPartyB: true, bHeart: true, named: true },
      text: { zh: "营地里的人横七竖八地睡着，佩兰却还醒着，坐在余烬的另一头。\n\n{bHe}没有在写，书已经合上，墨也收了起来，只是在调弦，轻得连琴弦自己都不太肯承认。\n\n然后，没有任何前奏，{bHe}低声唱了六小节，只唱给一个人听：磨坊主的女儿，卖毛线的女人，桥的两头。\n\n你第一次听这首歌时，它只是一首路歌，可现在不是了。歌词一个字也没有改，所以你听懂了。\n\n唱完最后一个音，{bHe}没有收弦，只是抬起眼睛，叫了你一声：{name}。歌是六十年前借来的，名字却是你自己的，{bHe}把这两样都还到了你的手里。",
              en: "The camp sleeps in heaps. Perrin is still awake, at the far end of the coals, not writing — the book shut, the ink put away. {bHe} {bIs} tuning, softly enough the strings barely admit to it.\n\nThen, without preamble, {bHe} sing{bVs} — six bars, under the breath, an audience of one. The miller's daughter. The wool-trader. The two ends of the bridge. The first time you heard it, it was a road song. It is not one now. Not one word has been changed. So you understand.\n\nThe last note dies, and {bHe} let{bVs} the string ring on — {bHe} only look{bVs} up and say{bVs} your name: {name}. The song was borrowed sixty years ago; the name is your own. {bHe} hand{bVs} you back both." } },
    { when: { inPartyB: true, bHeart: true },
      text: { zh: "营地里的人横七竖八地睡着，佩兰却还醒着，坐在余烬的另一头。\n\n{bHe}没有在写，书已经合上，墨也收了起来，只是在调弦，轻得连琴弦自己都不太肯承认。\n\n然后，没有任何前奏，{bHe}低声唱了六小节，只唱给一个人听：磨坊主的女儿，卖毛线的女人，桥的两头。\n\n你第一次听这首歌时，它只是一首路歌，可现在不是了。歌词一个字也没有改，所以你听懂了。",
              en: "The camp sleeps in heaps. Perrin is still awake, at the far end of the coals, not writing — the book shut, the ink put away. {bHe} {bIs} tuning, softly enough the strings barely admit to it.\n\nThen, without preamble, {bHe} sing{bVs} — six bars, under the breath, an audience of one. The miller's daughter. The wool-trader. The two ends of the bridge. The first time you heard it, it was a road song. It is not one now. Not one word has been changed. So you understand." } },
    { when: { inPartyB: true },
      text: { zh: "营地里的人横七竖八地睡着，佩兰却还醒着，借着炭火的光在抄写，不是为了唱，而是为了改。笔尖在两行字上停了又停：这首歌已经唱了六十年，错处早就唱顺了口，跟对的地方一样分辨不出来。\n\n“过了明天，”{bHe}头也不抬地说，“这首歌要么被唱对，要么就再也别唱了。去睡吧。这一页我留着。”",
              en: "The camp sleeps in heaps. Perrin is still awake, copying by the coal-light — not to sing it, to fix it. The pen stops and stops again on two lines: sixty years of smooth-sung verses, and the wrong parts no longer look different from the right.\n\n\"After tomorrow,\" {bHe} say{bVs} without looking up, \"either this song gets sung right, or it stops being sung. Sleep. This page I'll keep.\"" } },
    { text: { zh: "山里的夜又冷又干净。第二班岗已经换过了，火塌成了炭，营地一直睡着。很长一段时间里，你只是听着，听木柴燃烧时细碎的噼啪声，听锁链偶尔轻轻一碰，听风贴着山脊低低扫过。没有人唱歌，今晚也不需要歌。",
              en: "The mountain night is cold and clean. The second watch changes; the fires collapse to coals; the camp sleeps through it. For a long time you just listen: the tick of burning wood, the occasional soft clink of chain, wind pressed low along the ridge. No one sings. The night does not need a song." } }
  ],
  choices: [
    { text: { zh: "“再唱一遍。慢一点。”",
              en: "\"Once more. Slower.\"" },
      when: { inPartyB: true, bHeart: true },
      set: { bLove: true }, next: "bKiss" },
    { text: { zh: "你什么也没说，只是隔着炭火伸过手去，把掌心平平按在琴弦上。",
              en: "You say nothing. You reach across the coals and press your palm flat against the string." },
      when: { inPartyB: true, bHeart: true }, set: { bBond: "string" }, next: "ch3p1d" },
    { text: { zh: "你往火里添了一根柴——给手找点事做，也在你们之间划出一道更亮的线。",
              en: "You feed the fire another stick — something for your hands to do, and a brighter line drawn between you." },
      when: { inPartyB: true, bHeart: true }, set: { bBond: "stick" }, next: "ch3p1d" },
    { text: { zh: "你等{bHim}抄完那一页，然后把火拨旺一些。",
              en: "You wait for {bHim} to finish copying the page, then stir the fire brighter." },
      when: { inPartyB: true }, hide: { bHeart: true }, next: "ch3p1d" },
    { text: { zh: "“过了明天，”你问，“这首歌会是谁的？”",
              en: "\"After tomorrow,\" you ask, \"whose song is it?\"" },
      when: { inPartyB: true }, hide: { bHeart: true }, next: "ch3p1d" },
    { text: { zh: "你把火拨旺一点，回到自己的铺盖上。",
              en: "You stir the fire brighter and go back to your pallet." },
      next: "ch3p1d" }
  ]
});

// ============================================================
//  bKiss · 亲密（bLove；「歌里没唱」黑屏，CoG 正牌级止于接吻）
// ============================================================
EVENTS.push({
  id: "bKiss",
  title: { zh: "桥", en: "The Bridge" },
  text: {
    zh: "唱第二遍时，正唱到桥中央等待的那一段，歌声就在你的唇边停住了，只剩下琴弦最后一点余颤，和彼此的呼吸。炭火咔嗒响了两下，像是有什么在替你们打着拍子。\n\n歌里没有这一节。\n\n它也从来不需要有。",
    en: "On the second time through, in the middle of the bridge — the verse about waiting — the song stops against your mouth. The last of the string, and breath. The coals click twice, like something keeping time.\n\nThere is no verse for this in the song. There never needed to be."
  },
  choices: [
    { text: { zh: "天还远没亮。你们就这样一起坐到了深夜。",
              en: "Dawn is a long way off. You sit together into the small hours." },
      next: "ch3p1d" }
  ]
});

// ============================================================
//  ch3p1d · 化形（C 走出笼子；男形/女形/流变三选在本页选项上）
// ============================================================
EVENTS.push({
  id: "ch3p1d",
  title: { zh: "它化作的模样", en: "The Shape It Takes" },
  text: [
    { when: { inPartyC: true, cHeart: true },
      text: { zh: "第三班岗换过以后，火塌成了一堆红炭。铁笼那边传来一阵折叠的声响，鳞片一层层地收拢，就像一封信被折进信封，越折越小。\n\n等声音停下，那些铁栏忽然显得有些可笑。\n\n一个身影从栏杆之间滑了出来，绕过火堆，在你对面坐下，手指搭在一件“借来”的外套扣子上。\n\n这一回，它没有问你扣子该怎么扣，只是说：\n\n“我穿的，是你一直藏在心里的那副模样。六十年来，我看着你睡觉，你做梦时用的就是这个样子。要是我穿错了，你来纠正。”\n\n它抬起下巴，让你看个清楚。",
              en: "The third watch changes; the fires collapse to red coals. From the cage comes a sound of gathering — scales folding, like a letter folded into its envelope, smaller and smaller.\n\nWhen it is done, the bars look suddenly ridiculous. A figure slips out between them, comes around the fire, and sits across from you, fingers resting on the buttons of the \"borrowed\" coat. This time it does not ask which way they go. It says:\n\n\"I wear the shape you kept in your heart. Sixty years, I watched you sleep — this is the one you use, when you dream. If I have it wrong, correct me.\"\n\nIt lifts its chin, and lets you see." } },
    { text: {
        zh: "第三班岗换过以后，火塌成了一堆红炭。铁笼那边传来一阵折叠的声响，那不是铁，而是鳞片，就像一封信被折进信封，越折越小。\n\n等声音停下，那些铁栏忽然显得有些可笑。\n\n一个身影从栏杆之间滑了出来，绕过火堆，在你对面坐下，身上裹着一件不知从谁的行李里顺来的外套，手指搭在扣子上。\n\n“这玩意儿，”它说，“扣子该往哪边扣，我记不得了。你来定。”\n\n它没有低头等着，而是抬起下巴，让你看个清楚。",
        en: "The third watch changes; the fires collapse to red coals. From the cage " +
            "comes a sound of gathering — not metal; scales. Like a letter being " +
            "folded into its envelope, smaller and smaller.\n\n" +
            "When it is done, the bars of the cage look suddenly ridiculous. A figure " +
            "slips out between them, comes around the fire, and sits across from you, " +
            "wrapped in a coat lifted from who knows which cargo bundle, fingers " +
            "resting on the buttons.\n\n" +
            "\"This thing,\" it says. \"Which way the buttons go, I no longer " +
            "remember. You decide.\"\n\n" +
            "It does not bow its head to wait. It lifts its chin, and lets you see."
      } }
  ],
  choices: [
    { text: { zh: "“照男人的扣法。”", en: "\"The way men wear it.\"" },
      set: { roC_sex: "male", cHeart: true }, next: "ch3p1e" },
    { text: { zh: "“照女人的扣法。”", en: "\"The way women wear it.\"" },
      set: { roC_sex: "female", cHeart: true }, next: "ch3p1e" },
    { text: { zh: "“哪边都行。扣子从来就扣不住你。”", en: "\"Either way. Buttons never held you.\"" },
      set: { roC_sex: "nonbinary", cHeart: true }, next: "ch3p1e" }
  ]
});

// ============================================================
//  ch3p1e · 人形（C 化形结果；镜像变体优先：流变×玩家未核实）
// ============================================================
EVENTS.push({
  id: "ch3p1e",
  title: { zh: "邻人", en: "The Neighbor" },
  text: [
    { when: { roC_sex: "nonbinary", gender: "unspoken" },
      text: { zh: "它照你说的扣上了，扣得有点歪，也就那么歪着了。火光里，那张脸同时带着两边的影子，有男人那样分明的颧骨，也有女人那样柔和的下颌，还有一双随着火光变色的眼睛，不论火往哪边吹，都是同一双眼睛。\n\n“有意思，”它说，“你也从没让谁仔细看过你。”它顿了顿，小心翼翼地试着用了一句借来的话：“晚上好。守夜的人都这么说……邻居。”\n\n外套底下，不时传来鳞片细微而干涩的摩擦声。\n\n那件外套遮得住它的身形，却遮不住底下藏着的东西。\n\n天快亮的时候，它站起身，把外套叠好放回原处，又一层一层地把自己折回了铁栏后面，连一把锁都没有碰过。离圣地这么近，没有人敢敲钟，所以这一天，你只能自己醒过来。",
              en: "It buttons the coat as you say — crooked, and left so. In the firelight the face is both at once: a man's cut of cheekbone and a woman's soft jaw, and eyes that change with the fire, whichever way it burns.\n\n\"Interesting,\" it says. \"You never let anyone check you either.\" A pause, then, carefully, like a borrowed phrase: \"Good evening. The fire-watchers all say it. Neighbors.\"\n\nUnder the cloth, all the way down, a small dry sound of scales — the coat can hold the cloth; it cannot hold what's under it.\n\nToward morning it stands, folds the coat back where it found it, and folds itself, layer by layer, behind the bars again — without touching a single lock. This close to the holy ground, nobody dares ring a bell; today you wake on your own." } },
    { when: { roC_sex: "male" },
      text: { zh: "它照着男人的样子慢慢扣上扣子，像是头一回学。火光里坐着的是一个男人，眉骨太重，肩膀太宽，外套绷在身上，像是受了冒犯。形体虽然是男人的，坐姿却还是龙的，两膝大开，脊背挺得理直气壮。\n\n“晚上好。”它试着说道，每个字都咬得有点太重，“守夜的人都这么说……邻居。”\n\n外套底下，不时传来鳞片细微而干涩的摩擦声。\n\n那件外套遮得住它的身形，却遮不住底下藏着的东西。\n\n天快亮的时候，它站起身，把外套叠好放回原处，又一层一层地把自己折回了铁栏后面，连一把锁都没有碰过。离圣地这么近，没有人敢敲钟，所以这一天，你只能自己醒过来。",
              en: "It does the buttons the way men do, slowly, like a first time. In the firelight sits a man: brow too heavy, shoulders too wide, the coat strained on him like something insulted. The shape is a man's; the sitting is still a dragon's — knees wide, spine unapologetic.\n\n\"Good evening,\" it tries, biting the words too hard. \"The fire-watchers all say it. Neighbors.\"\n\nUnder the cloth, all the way down, a small dry sound of scales — the coat can hold the cloth; it cannot hold what's under it.\n\nToward morning it stands, folds the coat back where it found it, and folds itself, layer by layer, behind the bars again — without touching a single lock. This close to the holy ground, nobody dares ring a bell; today you wake on your own." } },
    { when: { roC_sex: "female" },
      text: { zh: "它照着女人的样子扣上扣子，手比你想的还要稳。火光里坐着的是一个女人，那张脸安静得过分，像一张还没有决定要长成什么样的脸，可肩膀渐渐落定，终于成了女人的轮廓。形体虽然是她的，坐姿却还是龙的，两膝大开，脊背挺得理直气壮。\n\n“晚上好。”它试着说道，每个字都咬得有点太重，“守夜的人都这么说……邻居。”\n\n外套底下，不时传来鳞片细微而干涩的摩擦声。\n\n那件外套遮得住它的身形，却遮不住底下藏着的东西。\n\n天快亮的时候，它站起身，把外套叠好放回原处，又一层一层地把自己折回了铁栏后面，连一把锁都没有碰过。离圣地这么近，没有人敢敲钟，所以这一天，你只能自己醒过来。",
              en: "It does the buttons the way women do, hands steadier than you expected. In the firelight sits a woman: the face too quiet, quiet as a face that has not yet decided what to grow into — but the shoulders settle, and they settle into a woman's. The shape is hers; the sitting is still a dragon's — knees wide, spine unapologetic.\n\n\"Good evening,\" it tries, biting the words too hard. \"The fire-watchers all say it. Neighbors.\"\n\nUnder the cloth, all the way down, a small dry sound of scales — the coat can hold the cloth; it cannot hold what's under it.\n\nToward morning it stands, folds the coat back where it found it, and folds itself, layer by layer, behind the bars again — without touching a single lock. This close to the holy ground, nobody dares ring a bell; today you wake on your own." } },
    { text: { zh: "不等你说完，它就把扣子反着扣上了，而且就这么留着。“哪边都不合身，”它说，“那就两边都要。”火光里，那张脸同时带着两边的影子，有男人那样分明的颧骨，也有女人那样柔和的下颌，还有一双随着火光变色的眼睛，不论火往哪边吹，都是同一双眼睛。\n\n“晚上好。”它试着说道，每个字都咬得有点太重，“守夜的人都这么说……邻居。”\n\n外套底下，不时传来鳞片细微而干涩的摩擦声。\n\n那件外套遮得住它的身形，却遮不住底下藏着的东西。\n\n天快亮的时候，它站起身，把外套叠好放回原处，又一层一层地把自己折回了铁栏后面，连一把锁都没有碰过。离圣地这么近，没有人敢敲钟，所以这一天，你只能自己醒过来。",
              en: "It does not wait for you to finish — buttons done the wrong way round, and left so. \"Neither side fits,\" it says. \"Then both stay.\" In the firelight the face is both at once: a man's cut of cheekbone and a woman's soft jaw, and eyes that change with the fire, whichever way it burns.\n\n\"Good evening,\" it tries, biting the words too hard. \"The fire-watchers all say it. Neighbors.\"\n\nUnder the cloth, all the way down, a small dry sound of scales — the coat can hold the cloth; it cannot hold what's under it.\n\nToward morning it stands, folds the coat back where it found it, and folds itself, layer by layer, behind the bars again — without touching a single lock. This close to the holy ground, nobody dares ring a bell; today you wake on your own." } }
  ],
  choices: [
    { text: { zh: "握住那只搭在扣子上的手。",
              en: "Take the hand resting on the buttons." },
      when: { inPartyC: true, cHeart: true },
      set: { cLove: true }, next: "cKiss" },
    { text: { zh: "什么也不说，朝火边挪半步，挨着{cHim}坐下。",
              en: "Say nothing. Move half a step toward the fire, and sit down beside {cHim}." },
      when: { inPartyC: true, cHeart: true }, set: { cNightPost: "sit" }, next: "ch3a" },
    { text: { zh: "站起来。天快亮了。",
              en: "Stand up. Morning is close." },
      when: { inPartyC: true, cHeart: true }, set: { cNightPost: "stand" }, next: "ch3a" },
    { text: { zh: "你回到自己的铺盖上。",
              en: "You climb back down to your pallet." },
      hide: { inPartyC: true, cHeart: true }, set: { cNightPost: "bed" }, next: "ch3a" }
  ]
});

// ============================================================
//  cKiss · 亲密（cLove；「歌里没唱」黑屏，CoG 正牌级止于接吻）
//  化形页（ch3p1d）即告白本身；本页为回应档的收束拍
// ============================================================
EVENTS.push({
  id: "cKiss",
  title: { zh: "扣子", en: "The Buttons" },
  text: {
    zh: "你把那只手从扣子上挪开，扣子便忽然变得不重要了。\n\n这个吻起初是凉的，就像这副刚借来的身子还没有焐热；随后，底下的热度渗了出来，像是炉膛里攒了六十年的火。\n\n外套的领口下，传来鳞片细微而干涩的声响。歌里没有这一节，它也从来不需要有。",
    en: "You lift that hand away from the buttons, and the buttons stop mattering. The kiss is cool at first — this borrowed shape has not warmed through yet — and then the heat underneath comes through, sixty years banked in a furnace heart.\n\nUnder the coat's collar, a small dry sound of scales. There is no verse for this in the song. There never needed to be."
  },
  choices: [
    { text: { zh: "天亮之前，你们谁也没再说一句话。它回笼子之前，替你把火拨旺了。",
              en: "No one speaks again before dawn. Before it goes back to the cage, it stirs the fire brighter for you." },
      next: "ch3a" }
  ]
});

// ============================================================
//  ch3p2 · 守夜祷（仅 A 线：a4 → ch3p2 → a5）
// ============================================================
EVENTS.push({
  id: "ch3p2",
  title: { zh: "守夜祈祷", en: "The Vigil Prayer" },
  text: [
    { when: { named: true },
      text: { zh: "在村里的最后一夜，他们提着灯来敲你的窗，有长者、三个老祖母、磨坊主，还有五六个被父亲抱在怀里装睡的孩子。六十年来，守夜祈祷都是对着雕像念的，今晚，村子头一回有了一个真人可以对着念，于是人人都有点害怕。\n\n这段祷词比那首歌更老，也更简单，只有三句：火已熄，剑已举，世已安。\n\n他们站成了一道半月形的烛光。\n\n人群里，有个声音先试着叫了出来：{name}。声音很轻，像是怕叫错。\n\n明天就要上山了。今晚，这是他们要你做的最后一件事。",
              en: "The last night in the village, they come to your window with lanterns — the elder, three grandmothers, the miller, half the children pretending to be asleep in their fathers' arms. The hero leads the vigil prayer. It has always been so, for sixty years, with a statue standing in for the hero. Tonight, for the first time, the village has the real article, and it is terrified.\n\nThe prayer is older than the song, and simpler. Three lines: the fire went out. The sword was raised. The world was kept.\n\nThey stand in a half-moon of candlelight, and somewhere in it one voice tries your name first — {name}, softly, afraid of getting it wrong.\n\nTomorrow, the mountain. Tonight, this is the last thing they ask of you." } },
    { text: { zh: "在村里的最后一夜，他们提着灯来敲你的窗，有长者、三个老祖母、磨坊主，还有五六个被父亲抱在怀里装睡的孩子。六十年来，守夜祈祷都是对着雕像念的，今晚，村子头一回有了一个真人可以对着念，于是人人都有点害怕。\n\n这段祷词比那首歌更老，也更简单，只有三句：火已熄，剑已举，世已安。\n\n他们站成了一道半月形的烛光，等着你开口。\n\n明天就要上山了。今晚，这是他们要你做的最后一件事。",
            en: "The last night in the village, they come to your window with lanterns — the elder, three grandmothers, the miller, half the children pretending to be asleep in their fathers' arms. The hero leads the vigil prayer. It has always been so, for sixty years, with a statue standing in for the hero. Tonight, for the first time, the village has the real article, and it is terrified.\n\nThe prayer is older than the song, and simpler. Three lines: the fire went out. The sword was raised. The world was kept.\n\nThey stand in a half-moon of candlelight and wait for your voice.\n\nTomorrow, the mountain. Tonight, this is the last thing they ask of you." } }
  ],
  choices: [
    { text: { zh: "从头到尾稳稳念完，一字不差。",
              en: "Steady, all the way through, like it was written." },
      set: { leadPray: "hard", legendHard2: true }, next: "a5" },
    { text: { zh: "一路念下去——直到“剑已举”那一句，字像鱼刺一样卡在了牙缝里。",
              en: "You get through it — until \"the sword was raised\" sticks in your teeth " +
                  "like a fishbone." },
      set: { leadPray: "crack", legendCrack1: true }, next: "a5" },
    { text: { zh: "“我不太会祈祷。火把交给我拿吧。”",
              en: "\"I'm no hand at prayers. I'll carry the torch instead.\"" },
      set: { leadPray: "no" }, next: "a5" }
  ]
});

// ============================================================
//  ch3a · 圣地（处决仪式）
// ============================================================
EVENTS.push({
  id: "ch3a",
  title: { zh: "圣地", en: "The Holy Ground" },
  text: [
    { when: { recordsRead: true },
      text: { zh: "托尔岗的山顶是一张黑石台，它比那首歌还要老，或许比“托尔岗”这个名字还要老。石面上刻着线条，那不是装饰，而是有用处的，它们从中央的圆环向边缘伸展，像是根须，又像是血脉。冰冷的铁桩正一根根钉进交汇点，锤声平淡得让人记不住。\n\n铁笼被抬到了圆环正中，锁链从笼上垂下，落进石槽，刻线便开始发光。\n\n那光微弱而耐心，是那种有活儿要干的光。\n\n长者向众人宣读文书，文书里写着烧毁山谷的恶兽、到期的旧债，以及维系世间秩序的屠戮。王家卫兵列好了队，弩口朝地，卫队长却一直仰头看着天，像一个在看天色的农夫。\n\n这些刻线你认得。\n\n你不是在这座山上认得的，而是在一只抽屉里，在大火那年那本册子的页边，见过一模一样的记号，出自一只早已不在人世的手。\n\n这不是行刑的纹路，而是锁的纹路。\n\n这座山不是刑台，它是一把挂锁。\n\n铁栏里，那条龙看着发光的刻线。\n\n那眼神不像是囚犯在看刑场，倒像是一个曾经被关在里面的东西，又一次看见了那扇老门。",
              en: "The summit of the Tor is a table of black stone older than the song, older maybe than the words for it. Lines are cut into the stone — not carved for beauty; engineered — running out from a central ring to the edges like roots, or veins. Cold iron stakes are being set at their joints with hammers that make no sound worth remembering.\n\nThe cage is lifted onto the heart of the ring. The chains run down off it into channels in the stone, and the lines begin to glow. Faint. Patient. A light with work to do.\n\nThe elder reads the writ for the crowd: the beast that burned the valley, the debt come due, the slaying that keeps the world kept. The royal guard stand in files with their crossbows grounded. Their captain keeps looking at the sky, the way farmers do.\n\nYou know these lines. Not from the mountain — from a desk drawer, from the margins of a fire-year book: the same marks, drawn by a hand sixty years dead. They are not execution marks. They are lock marks. The mountain is not a scaffold. It is a hasp.\n\nInside the bars, the dragon watches the glowing lines — not the way a prisoner watches an execution ground, but the way something that was once locked inside looks at the old door again." } },
    { when: { keeperAlly: true },
      text: { zh: "托尔岗的山顶是一张黑石台，它比那首歌还要老，或许比“托尔岗”这个名字还要老。石面上刻着线条，那不是装饰，而是有用处的，它们从中央的圆环向边缘伸展，像是根须，又像是血脉。冰冷的铁桩正一根根钉进交汇点，锤声平淡得让人记不住。\n\n铁笼被抬到了圆环正中，锁链从笼上垂下，落进石槽，刻线便开始发光。\n\n那光微弱而耐心，是那种有活儿要干的光。\n\n长者向众人宣读文书，文书里写着烧毁山谷的恶兽、到期的旧债，以及维系世间秩序的屠戮。王家卫兵列好了队，弩口朝地，卫队长却一直仰头看着天，像一个在看天色的农夫。\n\n守祠人站在人群的最前面，那枚过大的徽章沉沉地坠在{aHis}胸口。刻线亮起的那一刻，{aHe}猛地吸了一口气。“这不是杀戮的形状。”\n\n{aHe}低声说，像是说给你听，也像是说给{aSelf}听，“这是打结的形状。今晚，有人要把什么东西重新绑牢。”\n\n铁栏里，那条龙看着发光的刻线。\n\n那眼神不像是囚犯在看刑场，倒像是一个曾经被关在里面的东西，又一次看见了那扇老门。",
              en: "The summit of the Tor is a table of black stone older than the song, older maybe than the words for it. Lines are cut into the stone — not carved for beauty; engineered — running out from a central ring to the edges like roots, or veins. Cold iron stakes are being set at their joints with hammers that make no sound worth remembering.\n\nThe cage is lifted onto the heart of the ring. The chains run down off it into channels in the stone, and the lines begin to glow. Faint. Patient. A light with work to do.\n\nThe elder reads the writ for the crowd: the beast that burned the valley, the debt come due, the slaying that keeps the world kept. The royal guard stand in files with their crossbows grounded. Their captain keeps looking at the sky, the way farmers do.\n\nThe keeper stands at the front of the crowd with {aHis} too-big badge, and when the lines begin to glow, {aHis} breath catches audibly. \"That is not the shape of a killing,\" {aHe} say{aVs} — low, to you, to {aSelf}. \"That is the shape of a knot. Tonight somebody is tying something down again.\"\n\nInside the bars, the dragon watches the glowing lines — not the way a prisoner watches an execution ground, but the way something that was once locked inside looks at the old door again." } },
    { when: { inPartyA: true },
      text: { zh: "托尔岗的山顶是一张黑石台，它比那首歌还要老，或许比“托尔岗”这个名字还要老。石面上刻着线条，那不是装饰，而是有用处的，它们从中央的圆环向边缘伸展，像是根须，又像是血脉。冰冷的铁桩正一根根钉进交汇点，锤声平淡得让人记不住。\n\n铁笼被抬到了圆环正中，锁链从笼上垂下，落进石槽，刻线便开始发光。\n\n那光微弱而耐心，是那种有活儿要干的光。\n\n长者向众人宣读文书，文书里写着烧毁山谷的恶兽、到期的旧债，以及维系世间秩序的屠戮。王家卫兵列好了队，弩口朝地，卫队长却一直仰头看着天，像一个在看天色的农夫。\n\n守祠人背着手，沿着圆环的边缘走，读着那些根须般的符纹，就像在核查{aHis}家族的账本，越读，就越不喜欢这笔账。\n\n铁栏里，那条龙看着发光的刻线。\n\n那眼神不像是囚犯在看刑场，倒像是一个曾经被关在里面的东西，又一次看见了那扇老门。",
              en: "The summit of the Tor is a table of black stone older than the song, older maybe than the words for it. Lines are cut into the stone — not carved for beauty; engineered — running out from a central ring to the edges like roots, or veins. Cold iron stakes are being set at their joints with hammers that make no sound worth remembering.\n\nThe cage is lifted onto the heart of the ring. The chains run down off it into channels in the stone, and the lines begin to glow. Faint. Patient. A light with work to do.\n\nThe elder reads the writ for the crowd: the beast that burned the valley, the debt come due, the slaying that keeps the world kept. The royal guard stand in files with their crossbows grounded. Their captain keeps looking at the sky, the way farmers do.\n\nThe keeper walks the ring's edge with {aHis} hands behind {aHis} back, reading the glyph-roots like someone auditing {aHis} own family's ledger, and not liking the arithmetic.\n\nInside the bars, the dragon watches the glowing lines — not the way a prisoner watches an execution ground, but the way something that was once locked inside looks at the old door again." } },
    { text: { zh: "托尔岗的山顶是一张黑石台，它比那首歌还要老，或许比“托尔岗”这个名字还要老。石面上刻着线条，那不是装饰，而是有用处的，它们从中央的圆环向边缘伸展，像是根须，又像是血脉。冰冷的铁桩正一根根钉进交汇点，锤声平淡得让人记不住。\n\n铁笼被抬到了圆环正中，锁链从笼上垂下，落进石槽，刻线便开始发光。\n\n那光微弱而耐心，是那种有活儿要干的光。\n\n长者向众人宣读文书，文书里写着烧毁山谷的恶兽、到期的旧债，以及维系世间秩序的屠戮。王家卫兵列好了队，弩口朝地，卫队长却一直仰头看着天，像一个在看天色的农夫。\n\n铁栏里，那条龙看着发光的刻线。\n\n那眼神不像是囚犯在看刑场，倒像是一个曾经被关在里面的东西，又一次看见了那扇老门。",
              en: "The summit of the Tor is a table of black stone older than the song, older maybe than the words for it. Lines are cut into the stone — not carved for beauty; engineered — running out from a central ring to the edges like roots, or veins. Cold iron stakes are being set at their joints with hammers that make no sound worth remembering.\n\nThe cage is lifted onto the heart of the ring. The chains run down off it into channels in the stone, and the lines begin to glow. Faint. Patient. A light with work to do.\n\nThe elder reads the writ for the crowd: the beast that burned the valley, the debt come due, the slaying that keeps the world kept. The royal guard stand in files with their crossbows grounded. Their captain keeps looking at the sky, the way farmers do.\n\nInside the bars, the dragon watches the glowing lines — not the way a prisoner watches an execution ground, but the way something that was once locked inside looks at the old door again." } }
  ],
  choices: [
    { text: { zh: "亲自沿着刻线走一遍。读懂这座山到底在干什么。",
              en: "Walk the lines yourself. Read what the mountain is doing." }, next: "ch3b" },
    { text: { zh: "客客气气地问卫队长：文书里没写的是什么。",
              en: "Ask the guard captain, politely, what the writ does not say." }, next: "ch3b" },
    { text: { zh: "先去笼边。不管接下来发生什么，都让它发生在一张它认得的脸面前。",
              en: "Go to the cage. Whatever happens next, let it happen where it can see a face " +
                  "it knows." }, next: "ch3b" }
  ]
});

// —— ch3a 开场认领（回声工单 S10＋S2＋凑数工单 N 批，次序：N → S10 → S2 → Love → 原文）——
// N 认领（凑数工单）：ch3p1e 守夜收尾三选（cNightPost 三值），插在「天亮了」之前
// S10 桥接：上一页 ch3p1e 守夜收束三选（兼容含 cKiss 全部入口，全变体前插）
// S2 认领：ch3p1 行军位置三选（paradePos 三值；全员必经，无值走防御兜底）
// 原 4 变体逐字保留，运行时扩为 16 条（nightZh 为 stack 内条件条目，不扩条数）
// 英文已于 2026-10-20 按《工单-致GLM-漏译25句对照》回填（A1-D3；A1 与 def 路径逐字同句）
// stack 条目不写段尾 \n\n：引擎 join("\n\n") 自带分段，写了会产生双空行
const ch3aZhDawn = "天亮以后，营地拔了帐篷，队伍走完了最后一段山路。";
const ch3aEnDawn = "After dawn, the camp struck its tents, and the procession walked the last stretch of the mountain road.";
const ch3aZhPos = {
  front: "昨天一路上，你都走在队伍的最前头，到了今早最后一段坡，村民们仍旧自觉地让你先上。",
  back:  "昨天你一直走在队伍最后，看了一整天全村人的后背。今早登顶时，你也是最后一个踏上黑石的人，所有人都落在你的眼里。",
  cage:  "昨天你一路走在铁笼旁边，卫兵们起初还皱着眉，后来连管都懒得管了。今早爬最后一段坡时，那条龙的呼吸声一直就在你的身侧。"
};
const ch3aEnPos = {
  front: "Yesterday you walked at the head of the line the whole way, and this morning, on the last slope, the villagers still made way for you without being asked.",
  back:  "Yesterday you walked at the back the whole way and spent the day looking at the backs of the whole village. This morning you were the last onto the black stone as well, with every one of them in your sight.",
  cage:  "Yesterday you walked beside the iron cage the whole way. The guards scowled at first, and later could not even be bothered. This morning, on the last slope, the dragon's breathing stayed at your side the whole climb."
};
(function () {
  const ev = EVENTS[EVENTS.length - 1]; // ch3a
  // G3 渗透段（情感线工单 · Claude 成句）：三线 Love 各一句，可并存按序拼接，
  // 插在位置认领之后、仪式场原文之前；龙在笼中被抬上山（鳞声），未出笼。
  const loveZh = [
    { when: { aLove: true },
      text: { zh: "路上，守祠人把水囊递给你，指尖在你的手背上多停了一下，可你们谁也没有提起。",
              en: "On the road, the keeper passed you the waterskin; the fingertips lingered a moment longer on the back of your hand. Neither of you mentioned it." } },
    { when: { bLove: true },
      text: { zh: "佩兰一路哼着一支调子，你听了半天才听出来，那是那晚火堆边的六小节。",
              en: "Perrin hummed a tune the whole way, and it took you most of the road to place it: the six bars from the fire that night." } },
    { when: { cLove: true },
      text: { zh: "铁栏后面，鳞片随着牛车的颠簸轻轻摩擦，就像有谁在一遍又一遍地折着一封写不完的信。",
              en: "Behind the bars, the scales rubbed softly with the jolt of the oxcart, like someone folding the same unfinished letter over and over." } }
  ];
  // 凑数工单 N-sit/N-stand/N-bed：ch3p1e 守夜收尾三选的落点认领；英文已回填（D1-D3）
  const nightZh = [
    { when: { cNightPost: "sit" },
      text: { zh: "后半夜，你们谁也没有再说话。你挨着它坐着，看火一点点小下去；回笼之前，它还伸手替你添了一回柴。",
              en: "After midnight neither of you spoke again. You sat close beside it and watched the fire burn down; before it went back into the cage, it reached over and fed the fire one more stick for you." } },
    { when: { cNightPost: "stand" },
      text: { zh: "你站起身的时候，它并没有留你。天边那层黑，已经开始松动了。",
              en: "When you stood, it did not ask you to stay. Along the skyline, the dark had already begun to come loose." } },
    { when: { cNightPost: "bed" },
      text: { zh: "你回到铺盖上，背对着铁笼躺下。夜很长，铁栏后面鳞片翻身时那点轻微的声响，你听得比自己的心跳还要清楚。",
              en: "You went back to your pallet and lay down with your back to the cage. The night was long; behind the bars, the small sound of scales turning over was clearer to you than your own heartbeat." } }
  ].map(o => ({ when: Object.assign({}, o.when), text: { zh: o.text.zh, en: o.text.en || "" } }));
  const src = ev.text, out = [];
  src.forEach(v => {
    const w = v.when || {};
    ["front", "back", "cage"].forEach(p => {
      out.push({ when: Object.assign({ paradePos: p }, w), stack: [
        ...nightZh,
        { text: { zh: ch3aZhDawn + "\n\n" + ch3aZhPos[p], en: ch3aEnDawn + "\n\n" + ch3aEnPos[p] } },
        ...loveZh.map(o => ({ when: Object.assign({}, o.when), text: { zh: o.text.zh, en: o.text.en || "" } })),
        { text: v.text }
      ] });
    });
    const def = { stack: [
      ...nightZh,
      { text: { zh: ch3aZhDawn, en: ch3aEnDawn } },
      ...loveZh.map(o => ({ when: Object.assign({}, o.when), text: { zh: o.text.zh, en: o.text.en || "" } })),
      { text: v.text }
    ] };
    if (v.when) def.when = Object.assign({}, v.when);
    out.push(def);
  });
  ev.text = out;
})();

// ============================================================
//  ch3b · 剑誓（执剑戏）
// ============================================================

// ch3b 共享开场（前夜擦剑）—— S11 桥接＋Claude 建议免标志句「龙的目光跟了你一路」（对 ch3a 三选均成立，8 变体共用）
const p4ZhOpen =
  "等你回到圆环边上时，能确认的都已经确认过了，再也没有什么可以让你拖延。铁栏里，那条龙的目光跟了你一路。\n\n" +
  "昨夜篝火将熄的时候，老兵来到你的铺盖前，双掌平托着那把传说中的剑，像是托着一个婴儿，又像是托着一盏随时会翻倒的油灯，然后跪了下来。六十年里，他在三面旗帜下擦过兵器，手从来没有抖过一次，可那一夜，却抖了。\n\n“这个故事，我守了大半辈子。”他没有抬头，“要是你真是它一直在等的那个——”他的手停住了，那句话，他终究没有说完。\n\n而此刻，在圆环边上，当着所有人的面，他抬头望着你的脸，望了很久，然后跪了下去，先是一条腿，再是另一条，直到额头贴上了黑石。\n\n“屠龙者的脸。”他说，沙哑的嗓音在山顶炸开，就像投石索甩出的一块石头，“屠龙者回来了。”";
const p4EnOpen =
  "Last night, on the cold stone with the campfires guttering, the old soldier came to your " +
  "pallet carrying the sword of the legend flat across both palms, the way a man carries a " +
  "baby, or a bomb. He knelt. He has polished weapons for sixty years, under three flags, and " +
  "his hands never once shook. They shook now.\n\n" +
  "\"Three generations I have kept this story warm,\" he said, not looking up. \"If you are " +
  "what it has been waiting for —\" The rag stopped moving. He never did finish it.\n\n" +
  "Now, at the ring's edge, in front of everyone, he looks up into your face for one long " +
  "moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n" +
  "\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the " +
  "report of a sling. \"The Slayer's come back.\"";

// ch3b 共享续（全村跪）
const p4ZhMid =
  "\n\n于是整个村子就像被风吹过的麦田，齐齐伏倒在地。母亲们揪着孩子节日衣裳的领子，把他们按到地上。王家卫兵没有跪，因为他们不属于这个村子，可每一张弩都松松地垂在身侧，像是被人忘了。长者双手捧起那把传说中的剑，隔着发光的圆环递向了你。";
const p4EnMid =
  "\n\nAnd the village goes down like wheat before it. Mothers pull children down by the " +
  "collars of their festival clothes. The royal guard do not kneel — they are not the " +
  "village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword " +
  "of the legend in both hands and holds it out to you across the glowing ring.";

// ch3b 共享收尾
const p4ZhClose =
  "\n\n“做个了结吧。”长者说道。封印的光顺着剑身往上爬，却找不到一点刃口可以攀附，“杀了这怪物，英雄，世间才能安稳。”";
const p4EnClose =
  "\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to " +
  "catch. \"Slay the beast, hero, and the world stays kept.\"";

// ch3b 变体段（A=守祠人在场／Exam=摸过剑／Hard=祝过福）
const p4ZhA =
  "\n\n守祠人站在最前面。全村人跪拜的，是那张养活了{aHis}家族六十年的脸，却不是{aHim}。\n\n{aHe}紧紧攥着那枚过大的徽章，就像攥着一句还没决定要不要说出口的话。";
const p4EnA =
  "\n\nThe keeper of the shrine stands at the very front of the crowd. The whole " +
  "village kneels to the face {aHis} family has fed for sixty years — and not " +
  "{aHim}. {aHe} close{aVs} {aHis} fist around the too-big badge, like someone holding a sentence " +
  "{aHe} {aIs} still deciding whether to say.";
const p4ZhExam =
  "\n\n你很清楚递到你面前的是什么：那是一根敲成剑形、从来没有开过刃的铁条，轻得就像一句谎话，如今却要充当一台运转了六十年的老机器的铰链。";
const p4EnExam =
  "\n\nYou know exactly what is coming toward you: a bar of iron beaten into the shape " +
  "of a sword and never once given an edge, light as a lie, about to be made the " +
  "hinge of a sixty-year machine.";
const p4ZhHard =
  "\n\n你已经为这支队伍祝过一次福了。可信念就像讨债人，而村子认定，你还欠他们一个奇迹。";
const p4EnHard =
  "\n\nYou have blessed this procession once already. Belief is a debt collector, and " +
  "the village believes you owe one more miracle.";

EVENTS.push({
  id: "ch3b",
  title: { zh: "剑之誓", en: "The Sword Oath" },
  text: [
    { when: { inPartyA: true, swordExamined: true },
      text: { zh: p4ZhOpen + p4ZhMid + p4ZhA + p4ZhExam + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\nThe keeper stands at the very front of the crowd. The whole village kneels to the face {aHis} family has fed for sixty years — and not {aHim}. {aHe} close{aVs} {aHis} fist around the too-big badge, like someone holding a sentence {aHe} {aIs} still deciding whether to say.\n\nYou know exactly what is coming toward you: a bar of iron beaten into the shape of a sword and never once given an edge, light as a lie, about to be made the hinge of a sixty-year machine.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } },
    { when: { inPartyA: true, legendHard2: true },
      text: { zh: p4ZhOpen + p4ZhMid + p4ZhA + p4ZhHard + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\nThe keeper stands at the very front of the crowd. The whole village kneels to the face {aHis} family has fed for sixty years — and not {aHim}. {aHe} close{aVs} {aHis} fist around the too-big badge, like someone holding a sentence {aHe} {aIs} still deciding whether to say.\n\nYou have blessed this procession once already. Belief is a debt collector, and the village believes you owe one more miracle.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } },
    { when: { inPartyA: true },
      text: { zh: p4ZhOpen + p4ZhMid + p4ZhA + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\nThe keeper stands at the very front of the crowd. The whole village kneels to the face {aHis} family has fed for sixty years — and not {aHim}. {aHe} close{aVs} {aHis} fist around the too-big badge, like someone holding a sentence {aHe} {aIs} still deciding whether to say.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } },
    { when: { swordExamined: true },
      text: { zh: p4ZhOpen + p4ZhMid + p4ZhExam + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\nYou know exactly what is coming toward you: a bar of iron beaten into the shape of a sword and never once given an edge, light as a lie, about to be made the hinge of a sixty-year machine.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } },
    { when: { legendHard2: true },
      text: { zh: p4ZhOpen + p4ZhMid + p4ZhHard + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\nYou have blessed this procession once already. Belief is a debt collector, and the village believes you owe one more miracle.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } },
    { text: { zh: p4ZhOpen + p4ZhMid + p4ZhClose,
              en: "By the time you come back to the ring, everything that could be confirmed has been confirmed, and there is nothing left to hold you back. Inside the bars, the dragon's eye has followed you the whole way.\n\nLast night, on the cold stone with the campfires guttering, the old soldier came to your pallet carrying the sword of the legend flat across both palms, the way a man carries a baby, or a lamp that might tip over. He knelt. He has polished weapons for sixty years, under three flags, and his hands never once shook. They shook now.\n\n\"Most of my life I have kept this story warm,\" he said, not looking up. \"If you are what it has been waiting for —\" His hand stopped moving. He never did finish it.\n\nNow, at the ring's edge, in front of everyone, he looks up into your face for one long moment — and goes down. Knee, then knee, then forehead to the black stone.\n\n\"The Slayer's face,\" he says, and his cracked voice carries across the summit like the report of a sling. \"The Slayer's come back.\"\n\nAnd the village goes down like wheat before it. Mothers pull children down by the collars of their festival clothes. The royal guard do not kneel — they are not the village's — but every crossbow hangs forgotten at its hip while the elder lifts the sword of the legend in both hands and holds it out to you across the glowing ring.\n\n\"Finish it,\" the elder says. The seal-light runs up the blade and finds nothing to catch. \"Slay the beast, hero, and the world stays kept.\"" } }
  ],
  choices: [
    { text: { zh: "接过剑。把谎言的分量握进手里。",
              en: "Take the sword. Weigh the lie in your hand." },
      set: { finaleSword: "took" }, next: "ch3c" },
    { text: { zh: "让双手空着。让所有人看清，你手里什么也没有。",
              en: "Keep your hands open. Let them see them empty." },
      set: { finaleSword: "open" }, next: "ch3c" },
    { text: { zh: "先转向铁笼。“你已经等了六十年。再等一分钟。”",
              en: "Turn to the cage first. \"You have waited sixty years. Wait one more " +
                  "minute.\"" },
      set: { finaleSword: "turned" }, next: "ch3c" }
  ]
});

// ============================================================
//  ch3c · 引信（中段抉择）
// ============================================================

// ch3c 共享正文
const p5ZhBase =
  "符纹亮着，文书也念完了。\n\n这台机器只剩下最后一步，那是六十年来从没变过的一步，也是那首歌存在的唯一理由：\n\n屠龙者必须挥剑。\n\n光已经爬满了山上的一切，唯独没有爬上你，它停在你的脚边，就像一条被喝令坐下的狗。山可以等，它已经等了六十年；等不了的是锁链。从铁笼落地的那一刻起，它们就一直在低低地嗡鸣，而嗡鸣，就是锁链发问的方式。\n\n龙没有看剑，它在看你的手。";
const p5EnBase =
  "The glyphs have their light. The writ has been read. One step is left in the machine, and " +
  "it has always been the same step, the step the whole song exists to justify:\n\n" +
  "The slayer must strike.\n\n" +
  "The glow has climbed everything on this mountain except you. It waits at your hands like a " +
  "dog that has been told to sit. The mountain can wait — it has waited sixty years. It is " +
  "the chains that cannot: they have been humming since the cage was set down, and humming is " +
  "what a chain does instead of asking.\n\n" +
  "The dragon does not look at the sword. It looks at your hands.";

// ch3c 共享收尾
const p5ZhClose =
  "\n\n“要么动手，要么让开，英雄。”卫队长隔着火光喊道，把一句命令说得像是玩笑。\n\n嗡鸣又高了一个调。\n\n这座山等着它被许诺的东西，已经快要等不住了。";
const p5EnClose =
  "\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke, in " +
  "a voice dressed as patience.\n\n" +
  "The humming climbs a note. Whatever the mountain was promised, it is not going to get it.";

// —— ch3c 执剑认领（上一页 ch3b 三选的回声，e07d 样板；不动原矩阵段优先级）——
const ch3cZhSword = {
  took:   "长者松开了手，就像卸下了一副扛了六十年的担子。剑落进你的掌心，轻得不像是一件凶器。",
  open:   "你没有伸手。\n\n那把剑就横在圆环上方，长者举着它，既递不过来，也收不回去。",
  turned: "在你身后，长者举剑的手僵在了半空。笼子里，龙把下巴搁回了前爪上：六十年都等过来了，这一分钟，它等得起。"
};
const ch3cEnSword = {
  took:   "You take the sword. The elder's hands keep the shape of the offering a while longer before they remember to come down.",
  open:   "You don't reach for it. The sword stays in the elder's hands, caught between pressing forward and drawing back.",
  turned: "Across the ring, your words land. The dragon gives you one slow blink — sixty years of patience, pocketing the minute."
};

// —— ch3c 中段常量（原 5 条目矩阵的中段逐字抽离，内容不变）——
const p5ZhM2 = "\n\n它曾经对你说过，它不会和锁链较劲。此刻它也正是这么做的，而那份耐心，比任何挣扎都更加可怕。";
const p5EnM2 = "\n\nIt told you once that it would not fight the chains. It is keeping that, too, with a patience that is somehow worse than struggle.";
const p5ZhM3 = "\n\n人群中，那些看清了那把剑没有刃的人，再也忘不掉了。\n\n一个简单而干净的问题，已经在跪着的村民之间传开了：这把剑，到底杀得了什么？";
const p5EnM3 = "\n\nSomewhere in the crowd is someone who has seen the sword's missing edge and cannot un-see it, and that one clean question — what, exactly, would that sword have slain? — has gotten loose among the kneeling.";
const p5ZhM4 = "\n\n抬头看你的人，已经比低头看地的人多了。\n\n一道裂缝一旦被人看见，就成了一扇门。";
const p5EnM4 = "\n\nThere are more faces turned up at you now than turned down. A crack, once noticed, is a door.";

EVENTS.push({
  id: "ch3c",
  title: { zh: "引信", en: "The Fuse" },
  text: [
    { when: { finaleSword: "took", dragonTruth: true },
      text: { zh: ch3cZhSword.took + p5ZhBase + p5ZhM2 + p5ZhClose,
              en: "The elder lets go, the way a man sets down a burden he has carried for sixty years. The sword falls into your palm, too light to be a weapon. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nIt told you once that it would not fight the chains. It is keeping that, too, with a patience that is somehow worse than struggle.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "took", swordShown: true },
      text: { zh: ch3cZhSword.took + p5ZhBase + p5ZhM3 + p5ZhClose,
              en: "The elder lets go, the way a man sets down a burden he has carried for sixty years. The sword falls into your palm, too light to be a weapon. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nSomewhere in the crowd is someone who has seen the sword's missing edge and cannot un-see it, and that one clean question — what, exactly, would that sword have slain? — has gotten loose among the kneeling.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "took", legendCrack2: true },
      text: { zh: ch3cZhSword.took + p5ZhBase + p5ZhM4 + p5ZhClose,
              en: "The elder lets go, the way a man sets down a burden he has carried for sixty years. The sword falls into your palm, too light to be a weapon. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nThere are more faces turned up at you now than turned down. A crack, once noticed, is a door.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "took" },
      text: { zh: ch3cZhSword.took + p5ZhBase + p5ZhClose,
              en: "The elder lets go, the way a man sets down a burden he has carried for sixty years. The sword falls into your palm, too light to be a weapon. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "open", dragonTruth: true },
      text: { zh: ch3cZhSword.open + p5ZhBase + p5ZhM2 + p5ZhClose,
              en: "You don't reach for it.\n\nThe sword hangs above the ring. The elder holds it out — unable to pass it on, unable to take it back. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nIt told you once that it would not fight the chains. It is keeping that, too, with a patience that is somehow worse than struggle.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "open", swordShown: true },
      text: { zh: ch3cZhSword.open + p5ZhBase + p5ZhM3 + p5ZhClose,
              en: "You don't reach for it.\n\nThe sword hangs above the ring. The elder holds it out — unable to pass it on, unable to take it back. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nSomewhere in the crowd is someone who has seen the sword's missing edge and cannot un-see it, and that one clean question — what, exactly, would that sword have slain? — has gotten loose among the kneeling.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "open", legendCrack2: true },
      text: { zh: ch3cZhSword.open + p5ZhBase + p5ZhM4 + p5ZhClose,
              en: "You don't reach for it.\n\nThe sword hangs above the ring. The elder holds it out — unable to pass it on, unable to take it back. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nThere are more faces turned up at you now than turned down. A crack, once noticed, is a door.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "open" },
      text: { zh: ch3cZhSword.open + p5ZhBase + p5ZhClose,
              en: "You don't reach for it.\n\nThe sword hangs above the ring. The elder holds it out — unable to pass it on, unable to take it back. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "turned", dragonTruth: true },
      text: { zh: ch3cZhSword.turned + p5ZhBase + p5ZhM2 + p5ZhClose,
              en: "Behind you, the elder's sword-hand freezes in midair. In the cage, the dragon sets its chin back on its forepaws: it has waited sixty years; it can wait one minute. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nIt told you once that it would not fight the chains. It is keeping that, too, with a patience that is somehow worse than struggle.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "turned", swordShown: true },
      text: { zh: ch3cZhSword.turned + p5ZhBase + p5ZhM3 + p5ZhClose,
              en: "Behind you, the elder's sword-hand freezes in midair. In the cage, the dragon sets its chin back on its forepaws: it has waited sixty years; it can wait one minute. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nSomewhere in the crowd is someone who has seen the sword's missing edge and cannot un-see it, and that one clean question — what, exactly, would that sword have slain? — has gotten loose among the kneeling.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "turned", legendCrack2: true },
      text: { zh: ch3cZhSword.turned + p5ZhBase + p5ZhM4 + p5ZhClose,
              en: "Behind you, the elder's sword-hand freezes in midair. In the cage, the dragon sets its chin back on its forepaws: it has waited sixty years; it can wait one minute. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\nThere are more faces turned up at you now than turned down. A crack, once noticed, is a door.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { when: { finaleSword: "turned" },
      text: { zh: ch3cZhSword.turned + p5ZhBase + p5ZhClose,
              en: "Behind you, the elder's sword-hand freezes in midair. In the cage, the dragon sets its chin back on its forepaws: it has waited sixty years; it can wait one minute. The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } },
    { text: { zh: p5ZhBase + p5ZhClose, en: "The glyphs have their light. The writ has been read. One step is left in the machine, and it has always been the same step, the step the whole song exists to justify:\n\nThe slayer must strike.\n\nThe glow has climbed everything on this mountain except you. It waits at your feet like a dog that has been told to sit. The mountain can wait — it has waited sixty years. It is the chains that cannot: they have been humming since the cage was set down, and humming is what a chain does instead of asking.\n\nThe dragon does not look at the sword. It looks at your hands.\n\n\"Use it or lose it, hero,\" the guard captain calls — an order dressed as a joke.\n\nThe humming climbs a note. The mountain has waited for the thing it was promised, and it is running out of patience." } }
  ],
  choices: [
    { text: { zh: "说出来。全说出来——烟里走出的陌生人，两条龙，吞进胸膛的火，六十年的沉睡，笼子里抓错的那头兽。让封印饿死。",
              en: "Say it. All of it — the stranger in the smoke, the two dragons, the fire " +
                  "taken into the lungs, the sixty years of sleep, the wrong beast in the cage. " +
                  "Let the seal starve." },
      set: { fuseBroke: "say" }, next: "ch3c2" },
    { text: { zh: "把剑抵在膝上折断。给这台机器一个结局——只是不是它点名要的那个。",
              en: "Break the sword across your knee. Give the machine an ending — just not the " +
                  "one it ordered." },
      set: { fuseBroke: "snap" }, next: "ch3c2" },
    { text: { zh: "纹丝不动地站着。让光继续往上爬。让所有人好好看看，一个英雄能把架势端多久。",
              en: "Stand still. Let the light climb. Let them all see exactly how long a hero " +
                  "can hold a pose." },
      set: { fuseBroke: "hold" }, next: "ch3c2" }
  ]
});

// ============================================================
//  ch3c2 · 各就各位（破链前一拍；8 入队组合，段常量拼接，e07c4 样板）
//  总纲约束：入队者仅做内部渲染，不改变高潮走向
// ============================================================
const c2ZhOpen =
  "锁链上的光爬到了第二节，卫队长的命令被风吹散了。在下一件事发生之前，你飞快地扫了一眼四周，就像在着火的房子里，清点着该抢出些什么。";
const c2EnOpen =
  "The chain-light climbs the second link. The captain's order breaks apart, " +
  "and the wind takes the pieces. Before the next thing arrives, you look " +
  "around — quickly, like tallying what you would carry out of a burning " +
  "house.";
const c2ZhA =
  "\n\n守祠人往前跨了半步，又微微侧过身，站到了你和弩阵之间，不是去挡，只是站定了位置。\n\n{aHe}把那枚过大的旧徽章举到唇边按了按，就像老兵在亲吻军旗，不求活命，只求被人记住。";
const c2EnA =
  "\n\nThe keeper stands half a step forward and aside, between you and the " +
  "crossbows — not blocking; positioning. {aHe} lifts the too-large old " +
  "medal to {aHis} lips and presses it there, the way old soldiers kiss a " +
  "flag: not asking to live, only to be remembered.";
const c2ZhB =
  "\n\n佩兰已经退到了高处的台阶上，从那儿能看清整片空地。\n\n{bHe}把墨收了起来，摊开手掌，用干燥的指尖在掌纹上写着：这一回墨记不下的，就交给骨头去记。";
const c2EnB =
  "\n\nPerrin has backed to the high step, where the whole field can be " +
  "seen at once. The ink is put away; the palm is open; the fingertips " +
  "write dry on the lines of it — what the ink cannot keep, this time the " +
  "bones will.";
const c2ZhC =
  "\n\n锁链之下，笼中那个身影抬起眼睛，在一片混乱里一下子就找到了你。\n\n那双灯黄色的眼睛里既没有恐惧，也没有求救，它只在问一件事：你站在哪一边。\n\n你几乎能听见这句话。";
const c2EnC =
  "\n\nUnder the chains, the man-shape lifts its eyes and finds you in all " +
  "that chaos — first try. The lamp-yellow eyes are not afraid, not asking " +
  "for rescue. They ask one thing only: which side are you standing on. " +
  "You almost hear it.";
const c2ZhClose = "\n\n你把每个人站的位置都记在了心里。锁链上的光，爬到了顶。";
const c2EnClose = "\n\nYou note where everyone stands. The chain-light " +
  "reaches the top.";

EVENTS.push({
  id: "ch3c2",
  title: { zh: "众人立足之处", en: "Where Everyone Stands" },
  text: [
    { when: { inPartyA: true, inPartyB: true, inPartyC: true },
      text: { zh: c2ZhOpen + c2ZhA + c2ZhB + c2ZhC + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nThe keeper stands half a step forward and aside, between you and the crossbows — not blocking; positioning. {aHe} lifts the too-large old badge to {aHis} lips and presses it there, the way old soldiers kiss a flag: not asking to live, only to be remembered.\n\nPerrin has backed to the high step, where the whole field can be seen at once. {bHe} put{bVs} the ink away; {bHis} palm is open; {bHis} dry fingertips write on the lines of it — what the ink cannot keep, this time the bones will.\n\nUnder the chains, the man-shape lifts its eyes and finds you in all that chaos — first try. The lamp-yellow eyes are not afraid, not asking for rescue. They ask one thing only: which side are you standing on. You almost hear it.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyA: true, inPartyB: true },
      text: { zh: c2ZhOpen + c2ZhA + c2ZhB + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nThe keeper stands half a step forward and aside, between you and the crossbows — not blocking; positioning. {aHe} lifts the too-large old badge to {aHis} lips and presses it there, the way old soldiers kiss a flag: not asking to live, only to be remembered.\n\nPerrin has backed to the high step, where the whole field can be seen at once. {bHe} put{bVs} the ink away; {bHis} palm is open; {bHis} dry fingertips write on the lines of it — what the ink cannot keep, this time the bones will.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyA: true, inPartyC: true },
      text: { zh: c2ZhOpen + c2ZhA + c2ZhC + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nThe keeper stands half a step forward and aside, between you and the crossbows — not blocking; positioning. {aHe} lifts the too-large old badge to {aHis} lips and presses it there, the way old soldiers kiss a flag: not asking to live, only to be remembered.\n\nUnder the chains, the man-shape lifts its eyes and finds you in all that chaos — first try. The lamp-yellow eyes are not afraid, not asking for rescue. They ask one thing only: which side are you standing on. You almost hear it.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyB: true, inPartyC: true },
      text: { zh: c2ZhOpen + c2ZhB + c2ZhC + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nPerrin has backed to the high step, where the whole field can be seen at once. {bHe} put{bVs} the ink away; {bHis} palm is open; {bHis} dry fingertips write on the lines of it — what the ink cannot keep, this time the bones will.\n\nUnder the chains, the man-shape lifts its eyes and finds you in all that chaos — first try. The lamp-yellow eyes are not afraid, not asking for rescue. They ask one thing only: which side are you standing on. You almost hear it.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyA: true },
      text: { zh: c2ZhOpen + c2ZhA + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nThe keeper stands half a step forward and aside, between you and the crossbows — not blocking; positioning. {aHe} lifts the too-large old badge to {aHis} lips and presses it there, the way old soldiers kiss a flag: not asking to live, only to be remembered.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyB: true },
      text: { zh: c2ZhOpen + c2ZhB + c2ZhClose,
              en: "The chain-light climbs the second link. The captain's order breaks apart, and the wind takes the pieces. Before the next thing arrives, you look around — quickly, like tallying what you would carry out of a burning house.\n\nPerrin has backed to the high step, where the whole field can be seen at once. {bHe} put{bVs} the ink away; {bHis} palm is open; {bHis} dry fingertips write on the lines of it — what the ink cannot keep, this time the bones will.\n\nYou note where everyone stands. The chain-light reaches the top." } },
    { when: { inPartyC: true },
      text: { zh: c2ZhOpen + c2ZhC + c2ZhClose,
              en: c2EnOpen + c2EnC + c2EnClose } },
    { text: { zh: c2ZhOpen + c2ZhClose,
              en: c2EnOpen + c2EnClose } }
  ],
  choices: [
    { text: { zh: "吸一口气。让一切开始。",
              en: "Draw a breath. Let it begin." }, next: "ch3d" }
  ]
});

// ============================================================
//  ch3d · 破链与火
// ============================================================

// ch3d 共享开场
const p6ZhOpen =
  "光沿着一道刻线熄灭了，接着是下一道，就像一座房子一间屋一间屋地灭了灯。文书的最后一个字还挂在长者的嘴边，而最后一条锁链的最后一节，成了山上最响的声音。\n\n然后，这座山终于明白了，自己一直按住的是什么。\n\n铁笼与其说是炸开的，不如说是绽开的，铁板像花瓣一样向整个山顶抛散开去，而从里面升起的，再也不是广场上那团蜷着的货物了。六十年的静止在一瞬间舒展开来：双翼一展，遮住了半边天，长颈在余烬色的鳞片里弯出一个问号，随后是一声咆哮，与其说是声音，不如说是一场风暴。山顶上的每一支火把，都在同一秒被吹得歪向了一边。";
const p6EnOpen =
  "The glow gutters out along one root-line, then the next — a house losing its lamps one " +
  "room at a time. The writ is still on the elder's lips. The last link of the last chain is " +
  "the loudest thing on the mountain.\n\n" +
  "Then the mountain learns what the chains have been holding.\n\n" +
  "The cage does not burst so much as bloom — iron petals, thrown the length of the summit — " +
  "and what comes up out of it is not the curled cargo from the square. Sixty years of lying " +
  "still unfold at once: wings the size of the harvest, a neck like a question mark drawn in " +
  "blood-brown scale, and a roar that is not a sound but weather, and every torch on the " +
  "summit leans sideways at once.";

// ch3d 共享中段
const p6ZhMid =
  "\n\n只用了一次心跳的工夫，村子的信仰就整个翻了个面，跪着的人，全都变成了逃跑的人。";
const p6EnMid =
  "\n\nThe village's faith takes one heartbeat to invert. The kneeling become the fleeing.";

// ch3d 共享收尾
const p6ZhClose =
  "\n\n踩踏之中，一只火盆被撞翻了。\n\n那火直到今晚都还只是故事，此刻却长出了腿，走进了人群。混乱里，不知是谁把一个花环朝英雄的肩上抛了过来，像是到了这个时候，还想把节日撑下去，可花环还没落稳，就烧了起来。\n\n你把它从脖子上扯了下来，看着节日的最后一点残余，在你的手里烧成了灰。";
const p6EnClose =
  "\n\nA brazier goes over in the stamp of boots. The fire, which until tonight has been a " +
  "story, walks into the crowd on its own legs. In the crush, somebody flings a garland at " +
  "the hero's shoulders — the way you throw flowers at a procession, or honey-coat a pill — " +
  "and it catches before it settles.\n\n" +
  "You pull it off your neck and watch the last of the festival burn out in your hand.";

EVENTS.push({
  id: "ch3d",
  title: { zh: "断裂与火焰", en: "The Breaking and the Fire" },
  text: [
    { when: { fuseBroke: "say" },
      text: { zh: p6ZhOpen +
                  "\n\n你的话还散落在这座山上，而此刻，龙就站在那些话的正中央，清清楚楚，庞然无比，丝毫没有被自己的传说烧伤。" + p6ZhMid + p6ZhClose,
              en: "The glow gutters out along one line, then the next — a house losing its lamps one room at a time. The writ is still on the elder's lips. The last link of the last chain is the loudest thing on the mountain.\n\nThen the mountain learns what the chains have been holding.\n\nThe cage does not burst so much as bloom — iron petals, thrown the length of the summit — and what comes up out of it is not the curled cargo from the square. Sixty years of lying still unfold at once: wings opening wide enough to blot out half the sky, a long neck bending into a question mark in ember-colored scale, and a roar that is not a sound but weather, and every torch on the summit leans sideways at once.\n\nYour words are still loose on the mountain, and now the dragon stands in the middle of them — visible, enormous, unburned by its own legend.\n\nThe village's faith takes one heartbeat to invert. The kneeling become the fleeing.\n\nA brazier goes over in the stamp of boots. The fire, which until tonight has been a story, walks into the crowd on its own legs. In the crush, somebody flings a garland at the hero's shoulders, as if the festival could still be propped up this late — and it catches before it settles.\n\nYou pull it off your neck and watch the last of the festival burn out in your hand." } },
    { when: { fuseBroke: "snap" },
      text: { zh: p6ZhOpen +
                  "\n\n断成两截的剑，就躺在你扔下它的那块黑石上，跪着的人里，没有一个敢看它一眼。" +
                  p6ZhMid + p6ZhClose,
              en: "The glow gutters out along one line, then the next — a house losing its lamps one room at a time. The writ is still on the elder's lips. The last link of the last chain is the loudest thing on the mountain.\n\nThen the mountain learns what the chains have been holding.\n\nThe cage does not burst so much as bloom — iron petals, thrown the length of the summit — and what comes up out of it is not the curled cargo from the square. Sixty years of lying still unfold at once: wings opening wide enough to blot out half the sky, a long neck bending into a question mark in ember-colored scale, and a roar that is not a sound but weather, and every torch on the summit leans sideways at once.\n\nThe two halves of the sword lie on the black stone where you threw them, and no one, not one kneeling soul, dares look at them.\n\nThe village's faith takes one heartbeat to invert. The kneeling become the fleeing.\n\nA brazier goes over in the stamp of boots. The fire, which until tonight has been a story, walks into the crowd on its own legs. In the crush, somebody flings a garland at the hero's shoulders, as if the festival could still be propped up this late — and it catches before it settles.\n\nYou pull it off your neck and watch the last of the festival burn out in your hand." } },
    { when: { fuseBroke: "hold" },
      text: { zh: p6ZhOpen +
                  "\n\n不是谁先动的，是山先动的。活下来的人，后来都这么说。" + p6ZhMid + p6ZhClose,
              en: "The glow gutters out along one line, then the next — a house losing its lamps one room at a time. The writ is still on the elder's lips. The last link of the last chain is the loudest thing on the mountain.\n\nThen the mountain learns what the chains have been holding.\n\nThe cage does not burst so much as bloom — iron petals, thrown the length of the summit — and what comes up out of it is not the curled cargo from the square. Sixty years of lying still unfold at once: wings opening wide enough to blot out half the sky, a long neck bending into a question mark in ember-colored scale, and a roar that is not a sound but weather, and every torch on the summit leans sideways at once.\n\nNo one moved first. The mountain moved first. That is the version the survivors will tell.\n\nThe village's faith takes one heartbeat to invert. The kneeling become the fleeing.\n\nA brazier goes over in the stamp of boots. The fire, which until tonight has been a story, walks into the crowd on its own legs. In the crush, somebody flings a garland at the hero's shoulders, as if the festival could still be propped up this late — and it catches before it settles.\n\nYou pull it off your neck and watch the last of the festival burn out in your hand." } },
    { text: { zh: p6ZhOpen + p6ZhMid + p6ZhClose,
              en: "The glow gutters out along one line, then the next — a house losing its lamps one room at a time. The writ is still on the elder's lips. The last link of the last chain is the loudest thing on the mountain.\n\nThen the mountain learns what the chains have been holding.\n\nThe cage does not burst so much as bloom — iron petals, thrown the length of the summit — and what comes up out of it is not the curled cargo from the square. Sixty years of lying still unfold at once: wings opening wide enough to blot out half the sky, a long neck bending into a question mark in ember-colored scale, and a roar that is not a sound but weather, and every torch on the summit leans sideways at once.\n\nThe village's faith takes one heartbeat to invert. The kneeling become the fleeing.\n\nA brazier goes over in the stamp of boots. The fire, which until tonight has been a story, walks into the crowd on its own legs. In the crush, somebody flings a garland at the hero's shoulders, as if the festival could still be propped up this late — and it catches before it settles.\n\nYou pull it off your neck and watch the last of the festival burn out in your hand." } }
  ],
  choices: [
    { text: { zh: "护住那些摔倒的人。", en: "Shield the ones who fell." },
      set: { crisisAct: "shield" }, next: "ch3e" },
    { text: { zh: "后退。盯紧那对翅膀。", en: "Give ground. Watch the wings." },
      set: { crisisAct: "retreat" }, next: "ch3e" },
    { text: { zh: "用那副专为此刻而生的嗓子吼一声：“趴下！”",
              en: "Bellow \"DOWN\" — in a voice built for exactly this." },
      set: { crisisAct: "roar" }, next: "ch3e" }
  ]
});

// ============================================================
//  ch3e · 踩踏与鞋
// ============================================================

// ch3e 共享正文
const p7ZhBase =
  "人群朝悬崖小路涌去，那是下山唯一的路。路口窄得像一只漏斗，挤不出半点仁慈，拐杖、火把和手肘搅成一团。不知哪里，一个孩子哭着找妈妈，一个母亲尖叫着喊孩子。\n\n老兵却没有跑。\n\n他独自跪在空地上，一只手在一支倒下的火把旁胡乱摸索。直到这时你才明白过来，他是在找那枚徽章：作为六十年来最后一个活着的见证者，他不肯空着手离开这座山。火正慢慢朝他爬过去，慢得就像老人的悲伤，却也和悲伤一样，无处可躲。\n\n就在这时，有个小东西碰到了你的脚。\n\n那是一只孩子过节时穿的鞋，鞋面上缝着一道金线。而在它后面，人群已经挤成了一堵只剩背影的墙。";
const p7EnBase =
  "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. " +
  "Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is " +
  "screaming back.\n\n" +
  "The old soldier is not running. He is on his knees in the open, one hand raking the ground " +
  "beside a fallen torch — for his badge, you realize. Sixty years of being the last living " +
  "witness, and he will not leave this mountain without the proof. The fire walks toward him " +
  "at the speed of an old man's grief.\n\n" +
  "Something small hits your foot.\n\n" +
  "A shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind " +
  "it, the crowd is a wall of backs.";

// ch3e 页末钩
const p7ZhClose =
  "\n\n头顶上，那对翅膀缓缓绕着山顶盘旋了一圈。\n\n它看的并不是人群，它在找一个人。";
const p7EnClose =
  "\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. " +
  "It is looking for someone.";

// ch3e 石头闪回段（stoppedStone 变体，原内联文本抽出）
const p7ZhStone =
  "\n\n几天前在村子里，一块原本要砸向怪物的石头落进了你的掌心，上面还带着一个男孩手心的温度。\n\n人群决定该朝你扔些什么，这件事早在你戴上这张脸之前，就已经开始了。";
const p7EnStone =
  "\n\nOnce, in this village, a stone meant for a beast landed in your palm " +
  "instead, still warm from a boy's throw. Crowds have been deciding what to " +
  "throw at you since before you had this face.";

// ch3e 入队闪光段（总纲约束：仅内部渲染，不改变走向）
const p7ZhPartyA =
  "\n\n在悬崖小路的入口，守祠人站得笔直，瘦削的身子成了一块路标。\n\n{aHe}不驱赶任何人，只是站在最用得着的地方，把人流引向开阔处。六十年的供奉，第一次在{aHis}手里变成了实实在在派得上用场的东西。";
const p7EnPartyA =
  "\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body " +
  "turned signpost — not driving anyone, just standing where standing helps, bending " +
  "the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is " +
  "a practical thing for the first time.";
const p7ZhPartyB =
  "\n\n佩兰爬上了一辆翻倒的车，{bHe}没有在唱，而是在点人头。\n\n那副曾经压得过酒馆喧闹的嗓子，此刻一个接一个地喊着名字，就像把一只只锚抛进水里。人听见自己的名字，至少能稳住半口气，而有时候，半口气就够活下来了。";
const p7EnPartyB =
  "\n\nPerrin has climbed onto an overturned cart, and {bHe} is not singing — {bHe} is " +
  "counting heads. The voice that used to beat the noise of taverns calls names now, " +
  "one at a time, dropping them like anchors into the water. A person who hears their " +
  "own name steadies for half a breath — and half a breath is enough to live.";
const p7ZhPartyC =
  "\n\n铁笼的残片散了一地，只有那扇笼门还立着，门闩插得好好的，像是有谁在走之前，规规矩矩地把门关上了。在你认识的东西里，只有一个会这么仔细。";
const p7EnPartyC =
  "\n\nThe escort's cage lies tipped by the roadside, and no one is guarding it. Its " +
  "door stands open, opened properly from the inside — nothing forced, no one woken. " +
  "Only one creature you have ever met is that careful.";

EVENTS.push({
  id: "ch3e",
  title: { zh: "奔逃与鞋", en: "The Stampede and the Shoe" },
  text: [
    { when: { stoppedStone: true, inPartyA: true, inPartyB: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyA + p7ZhPartyB + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyA: true, inPartyB: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyA + p7ZhPartyB + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyA: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyA + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyB: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyB + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyA: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyA + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyB: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyB + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { stoppedStone: true },
      text: { zh: p7ZhBase + p7ZhStone + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyA: true, inPartyB: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhPartyA + p7ZhPartyB + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyA: true, inPartyB: true },
      text: { zh: p7ZhBase + p7ZhPartyA + p7ZhPartyB + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyA: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhPartyA + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyB: true, inPartyC: true },
      text: { zh: p7ZhBase + p7ZhPartyB + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyA: true },
      text: { zh: p7ZhBase + p7ZhPartyA + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nAt the mouth of the cliff path the keeper stands very straight, a slight body turned signpost. {aHe} drive{aVs} no one away; {aHe} stand{aVs} where standing helps, bending the flow toward the wide ground. Sixty years of worship, and in {aHis} hands it is a practical thing for the first time.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyB: true },
      text: { zh: p7ZhBase + p7ZhPartyB + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nPerrin has climbed onto an overturned cart, and {bHe} {bIs} not singing — {bHe} {bIs} counting heads. The voice that used to beat the noise of taverns calls names now, one at a time, dropping them like anchors into the water. A person who hears their own name steadies for half a breath — and half a breath is enough to live.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { when: { inPartyC: true },
      text: { zh: p7ZhBase + p7ZhPartyC + p7ZhClose,
              en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nThe iron cage's pieces are scattered over the ground; only the door still stands, its bolt set properly, as if someone had closed it carefully before leaving. Only one creature you have ever met is that careful.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } },
    { text: { zh: p7ZhBase + p7ZhClose, en: "The crowd funnels for the cliff path — the only road down — and a funnel is not kind. Staves, torches, elbows. Somewhere in it a child is screaming for a mother who is screaming back.\n\nThe old soldier is not running. He is on his knees in the open, one hand raking the ground beside a fallen torch — for his badge, you realize. Sixty years of being the last living witness, and he will not leave this mountain empty-handed. The fire walks toward him at the speed of an old man's grief, and, like grief, there is nowhere to hide from it.\n\nSomething small hits your foot.\n\nA shoe. A child's shoe, one of the festival shoes, stitched with a thread of gold. Behind it, the crowd is a wall of backs.\n\nA few days ago, in this village, a stone meant for a beast landed in your palm instead, still warm from a boy's throw. Crowds have been deciding what to throw at you since before you had this face.\n\nOverhead, the wings make one slow turn of the summit. It is not looking at the crowd. It is looking for someone." } }
  ],
  choices: [
    { text: { zh: "先救老兵。徽章就让它烧吧。", en: "The old soldier. The badge can burn." },
      set: { veteranSaved: true }, next: "ch3f" },
    { text: { zh: "先去路口。用肩膀把它撑开，一边数人头。",
              en: "The funnel. Hold it open with your shoulders and count heads." },
      set: { ch3eAct: "funnel" }, next: "ch3f" },
    { text: { zh: "捡起鞋，冲进人群，去找它的主人。",
              en: "Pick up the shoe and go into the stampede after its owner." },
      set: { shoeTaken: true }, next: "ch3f" },
    { text: { zh: "跨过去。天都烧起来了。", en: "Step over it. There is a sky on fire." },
      set: { ch3eAct: "past" }, next: "ch3f" }
  ]
});

// ============================================================
//  ch3f · 弩阵与皮囊
// ============================================================

// ch3f 共享正文
const p8ZhBase =
  "卫队长有一双内行人的眼睛，却半点信仰也没有，干他这一行，这正是最趁手的装备。\n\n他的手下齐刷刷地举起弩，全都指向天空，然而村民还挤在射界里，任何一轮齐射都会变成一场抽签。\n\n可卫队长已经不看龙了。\n\n他在算一笔账，你隔着整个山顶都看得懂：全村人都在往山下跑，唯一一个逆着人流往上走的，偏偏是顶着传说中那张脸的“英雄”。英雄不会去追龙，只有借别人的脸撒谎的人，才会去追龙。\n\n“你。”他隔着火光喊道，这并不是在问，“你不跪，也不跑。你他娘的到底是什么？”";
const p8EnBase =
  "The guard captain has a professional's eye and no faith at all, which is the correct " +
  "equipment for his trade. His men's crossbows come up off the ground in one motion and turn " +
  "skyward — and the villagers behind them are inside the firing lines, so every volley would " +
  "be a lottery.\n\n" +
  "But the captain is not watching the dragon anymore. He is doing arithmetic you can see " +
  "from across the summit: the whole village is running downhill, and the hero of the hour — " +
  "the man with the legend's face — is the only one moving against the stampede. Heroes do not " +
  "chase dragons. Liars in borrowed faces do.\n\n" +
  "\"You,\" he calls across the firelight. Not a question. \"You don't kneel, you don't run. " +
  "What are you?\"";

// ch3f 共享续＋页末
const p8ZhClose =
  "\n\n这座山上只有一样东西，快得能抢在弩箭之前冲上天。三天来，你一直把它藏在这副人皮底下；而六十年来，它一直就是你。\n\n最先脱落的，是你肩头那片松动的鳞片，那是你唯一留下的东西。\n\n这座山迎来了它的第二条龙。";
const p8EnClose =
  "\n\nThere is one thing on this mountain fast enough to reach the sky before the crossbows " +
  "decide. You have been wearing its shape for three days. It has been wearing you for sixty " +
  "years.\n\n" +
  "The loose scale at your shoulder — the one thing you kept — comes unstuck first.\n\n" +
  "The mountain gets its second dragon.";

// C-02 裁决（2026-10-17）：井边起疑回收句从 sus1 整页变体抽出，改为页尾 stack 追加，
// 挂在 habit 层正文之后——起疑玩家不再错过 habit 风味段。零新文本、零新标志位。
const p8ZhSus1 =
  "奔逃的人群里传来一个声音，你上一回听见它，还是在井边：“我就说那家伙不对劲！”而今夜，连这句怀疑都已经成了往事。";
const p8EnSus1 =
  "And from the fleeing crowd, a voice you last heard at the well: \"I said " +
  "there was something wrong about that one!\" Suspicion, tonight, is a kind of " +
  "memory.";

EVENTS.push({
  id: "ch3f",
  title: { zh: "弩与皮", en: "The Crossbows and the Skin" },
  text: [
    { when: { habit: "sniff" },
      stack: [
        { text: { zh: p8ZhBase +
                  "\n\n在披着这副借来身体的最后一秒，你的鼻子照例先做了它总是先做的事：你为前路深深吸进了一口长长的夜，吸进了松针、灰烬、牛的汗味，还有卫兵身上像热气一样蒸腾的恐惧。\n\n然后，你全部放开了。" + p8ZhClose,
              en: "The guard captain has a professional's eye and no faith at all, which is the correct equipment for his trade.\n\nHis men's crossbows come up off the ground in one motion and turn skyward — and the villagers behind them are inside the firing lines, so every volley would be a lottery.\n\nBut the captain is not watching the dragon anymore.\n\nHe is doing arithmetic you can see from across the summit: the whole village is running downhill, and the hero of the hour — the man with the legend's face — is the only one moving against the stampede. Heroes do not chase dragons. Liars in borrowed faces do.\n\n\"You,\" he calls across the firelight. Not a question. \"You don't kneel, you don't run. What the hell are you?\"\n\nAnd in the last second of the borrowed shape, your nose does what it always did first: you drink the whole night in one long breath for the road — pine, ash, ox-sweat, the guard's fear coming off him like heat. Then you let it all go.\n\nThere is one thing on this mountain fast enough to reach the sky before the crossbows decide. For three days you have kept it hidden under this human skin; and for sixty years it has been you.\n\nThe loose scale at your shoulder — the one thing you kept — comes unstuck first.\n\nThe mountain gets its second dragon." } },
        { when: { sus1: true }, text: { zh: p8ZhSus1, en: p8EnSus1 } }
      ] },
    { when: { habit: "finger" },
      stack: [
        { text: { zh: p8ZhBase +
                  "\n\n在披着这副借来身体的最后一秒，你的手指终于停了下来。三天来，它们一直在摆弄着什么，衣缝、硬币，还有别人的神经，一刻也不得安宁。如今再没有什么可摆弄的了，它们在你自己的胸口上敲了一下，又一下，就像在永远离开一座曾经爱过的房子之前，敲一敲它的门。" + p8ZhClose,
              en: "The guard captain has a professional's eye and no faith at all, which is the correct equipment for his trade.\n\nHis men's crossbows come up off the ground in one motion and turn skyward — and the villagers behind them are inside the firing lines, so every volley would be a lottery.\n\nBut the captain is not watching the dragon anymore.\n\nHe is doing arithmetic you can see from across the summit: the whole village is running downhill, and the hero of the hour — the man with the legend's face — is the only one moving against the stampede. Heroes do not chase dragons. Liars in borrowed faces do.\n\n\"You,\" he calls across the firelight. Not a question. \"You don't kneel, you don't run. What the hell are you?\"\n\nAnd in the last second of the borrowed shape, your fingers stop. They have worried at things for three days — seams, coins, other people's nerves — and now, with nothing left to worry, they tap once, twice, on your own chest. Like knocking on the door of a house you loved before leaving it for good.\n\nThere is one thing on this mountain fast enough to reach the sky before the crossbows decide. For three days you have kept it hidden under this human skin; and for sixty years it has been you.\n\nThe loose scale at your shoulder — the one thing you kept — comes unstuck first.\n\nThe mountain gets its second dragon." } },
        { when: { sus1: true }, text: { zh: p8ZhSus1, en: p8EnSus1 } }
      ] },
    { when: { habit: "distance" },
      stack: [
        { text: { zh: p8ZhBase +
                  "\n\n在披着这副借来身体的最后一秒，你照例往后退了三步，和一切活物拉开距离，你一向如此。“不，”你对村子说，对卫兵说，也对谁都没说，“这一回，你们来找我。”" + p8ZhClose,
              en: "The guard captain has a professional's eye and no faith at all, which is the correct equipment for his trade.\n\nHis men's crossbows come up off the ground in one motion and turn skyward — and the villagers behind them are inside the firing lines, so every volley would be a lottery.\n\nBut the captain is not watching the dragon anymore.\n\nHe is doing arithmetic you can see from across the summit: the whole village is running downhill, and the hero of the hour — the man with the legend's face — is the only one moving against the stampede. Heroes do not chase dragons. Liars in borrowed faces do.\n\n\"You,\" he calls across the firelight. Not a question. \"You don't kneel, you don't run. What the hell are you?\"\n\nAnd in the last second of the borrowed shape, you take three steps back — away from everyone alive, the way you always have. \"No,\" you say, to the village, to the guard, to nobody. \"This once, come to me.\"\n\nThere is one thing on this mountain fast enough to reach the sky before the crossbows decide. For three days you have kept it hidden under this human skin; and for sixty years it has been you.\n\nThe loose scale at your shoulder — the one thing you kept — comes unstuck first.\n\nThe mountain gets its second dragon." } },
        { when: { sus1: true }, text: { zh: p8ZhSus1, en: p8EnSus1 } }
      ] },
    { stack: [
        { text: { zh: p8ZhBase + p8ZhClose, en: "The guard captain has a professional's eye and no faith at all, which is the correct equipment for his trade.\n\nHis men's crossbows come up off the ground in one motion and turn skyward — and the villagers behind them are inside the firing lines, so every volley would be a lottery.\n\nBut the captain is not watching the dragon anymore.\n\nHe is doing arithmetic you can see from across the summit: the whole village is running downhill, and the hero of the hour — the man with the legend's face — is the only one moving against the stampede. Heroes do not chase dragons. Liars in borrowed faces do.\n\n\"You,\" he calls across the firelight. Not a question. \"You don't kneel, you don't run. What the hell are you?\"\n\nThere is one thing on this mountain fast enough to reach the sky before the crossbows decide. For three days you have kept it hidden under this human skin; and for sixty years it has been you.\n\nThe loose scale at your shoulder — the one thing you kept — comes unstuck first.\n\nThe mountain gets its second dragon." } },
        { when: { sus1: true }, text: { zh: p8ZhSus1, en: p8EnSus1 } }
      ] }
  ],
  choices: [
    { text: { zh: "一声不出。让那层皮像椅背上的外套一样滑落。",
              en: "In silence. Let the skin drop like a coat on a chair." },
      set: { revealAct: "silent" }, next: "ch3g" },
    { text: { zh: "用上你全部的嗓音——那副你压了三天、压得喉咙生疼的嗓音——一路撕扯着向上。",
              en: "With your whole voice — the pressed-flat one you have paid for every hour " +
                  "of three days. Let it rip going up." },
      set: { revealAct: "voice" }, next: "ch3g" },
    { text: { zh: "最后一次，在卫兵擦亮的盾面上看一眼那张借来的脸。然后放手。",
              en: "One last look at the borrowed face in a guardsman's polished shield. Then " +
                  "let it go." },
      set: { revealAct: "mirror" }, next: "ch3g" }
  ]
});

// —— ch3f 开场认领（回声工单 S4＋S12＋凑数工单 E 批，次序：S4 → E → S12 → 原文）——
// S4 认领：ch3d 危机三选（crisisAct 三值，认领隔一跳——ch3e 已有 16 变体不宜再扩）
// E 认领（凑数工单）：ch3e ②撑路口／④跨过那只鞋（ch3eAct 二值）；救老兵／捡鞋路径无认领，保持现状
// S12 桥接：ch3e 四入口共享开场（撑开路口/跨过/救老兵/捡鞋均接），故全变体前插
// 原 4 变体逐字保留（原 sus1 整页变体已按 C-02 裁决改为页尾 stack 追加），运行时扩为 40 条；防御兜底保留 S12 桥接、无 S4/E 认领
const ch3fZhCrisis = {
  shield:  "你把摔倒的人一个个从地上拽起来，推向下山的路，最后一个爬起来的老头，连谢都忘了说。\n\n",
  retreat: "你一步步退到了火光边上，眼睛始终没有离开那对翅膀，它盘旋到哪里，你的脚尖就跟着转到哪里。\n\n",
  roar:    "那一声“趴下”盖过了满山的哭喊，有那么一瞬间，连天上那对翅膀都顿了一下。\n\n"
};
// 凑数工单 E-funnel/E-past：ch3e 二选的落点认领，插在危机句与回神句之间；英文留待翻译阶段
const ch3fZhAct = {
  funnel: "路口是你用肩膀硬撑开的。\n\n你一边往外放人一边数人头，数到一半，数字就被人潮冲乱了，肩上撞出来的淤青也一片叠着一片。\n\n",
  past:   "你从那只鞋上跨了过去，就在那一瞬，鞋面上的金线在火光里亮了一下。\n\n你没有回头，逆着人潮往山顶走，人群从你两边涌了过去。\n\n"
};
const ch3fZhRoad = "等你回过神来，路口已经空了一半。人潮全都往山下涌去，只剩下你一个人面朝着山顶。\n\n";
(function () {
  const ev = EVENTS[EVENTS.length - 1]; // ch3f
  const src = ev.text, out = [];
  // C-02：源变体可为 text（普通）或 stack（sus1 回收句页尾追加）；
  // 正文首条拼上认领前缀，stack 其余条件条目（sus1 尾句）原样透传
  const mk = (prefixZh, v) => {
    if (!v.stack) return { text: { zh: prefixZh + v.text.zh, en: v.text.en } };
    return { stack: v.stack.map((sv, i) => {
      const e = { text: i === 0 ? { zh: prefixZh + sv.text.zh, en: sv.text.en } : sv.text };
      if (sv.when) e.when = Object.assign({}, sv.when);
      return e;
    }) };
  };
  src.forEach(v => {
    const w = v.when || {};
    ["shield", "retreat", "roar"].forEach(a => {
      ["funnel", "past"].forEach(e => out.push(Object.assign(
        { when: Object.assign({ crisisAct: a, ch3eAct: e }, w) },
        mk(ch3fZhCrisis[a] + ch3fZhAct[e] + ch3fZhRoad, v)
      )));
      out.push(Object.assign(
        { when: Object.assign({ crisisAct: a }, w) },
        mk(ch3fZhCrisis[a] + ch3fZhRoad, v)
      ));
    });
    const def = mk(ch3fZhRoad, v);
    if (v.when) def.when = Object.assign({}, v.when);
    out.push(def);
  });
  ev.text = out;
})();

// ============================================================
//  ch3g · 天空与选择（空中对峙＋终拍）
// ============================================================

// ch3g 共享正文
const p9ZhBase =
  "你从借来的形状里破壳而出，就像泳者冲出漆黑的水面，而山顶上的每一种声音，都在同一瞬间变了温度。\n\n另一条龙在尖塔那么高的地方撞上了你。\n\n它没有逃，尽管整片天空都向它敞开着，连往西的路也敞着，因为它上来不是为了脱身，而只是为了找一样东西。\n\n那样东西，就是你。\n\n你们扣住了彼此。六十年没有练过，那套扣法却还在，身体记得这道算术，爪子分毫不差地找回了旧位置，仿佛那场搏斗只是在六十年前暂停了一下，而双方一直都在热身。在下方的火光里，村子终于看到了自己那首歌的真实版本：两头巨兽，在黑石之上，在真正的天空下，演给他们看。\n\n在这转瞬即逝的高处，谁也够不着你，你也够不着谁。\n\n它凑近了，用那副仿佛从地底传来的嗓音对你说：";
const p9EnBase =
  "You come up out of the borrowed shape the way a swimmer comes up out of dark water, and " +
  "every sound on the summit changes its temperature at once.\n\n" +
  "The other dragon meets you at the height of the spire. It has not fled — the whole sky was " +
  "open to it, road west and all — because it did not come up here to escape. It came up to " +
  "find one thing, and the thing is you.\n\n" +
  "You lock. Sixty years out of practice, and the holds are all still there — the remembered " +
  "arithmetic of it — claws finding the old places as if the fight had only paused, sixty " +
  "years ago, and both parties had kept warm. Below you, in the firelight, the village " +
  "watches the two beasts of its song performing the true version at last: over the black " +
  "stones, under the actual sky.\n\n" +
  "And in the cage of the moment — up where no one can reach you, and you can reach no one — " +
  "it speaks, close, in the voice from under the ground:";

// ch3g 台词变体
const p9ZhSay = {
  truth: "\n\n“现在，两脚龙。我答应你的，都做到了。我没有逃离那座山。我没有和锁链较劲。最后这件也一样：我不会替你做选择。”",
  base:  "\n\n“现在，两脚龙，趁他们还没重新上弦。六十年来，我守着你那道悬崖下的地，一直在想，等你第二次醒来，你会怎么做。选吧，选你要成为什么。”",
  scale: "\n\n那片鳞压在你的臂下，那是你自己的鳞，在山里替你等了六十年。\n\n它的分量，自有它的主张。"
};
const p9EnSay = {
  truth: "\n\n\"Now, soft-foot. I have kept every promise I made you. I did not run from the " +
         "mountain. I did not fight the chains. Here is the last one: I will not choose for " +
         "you.\"",
  base:  "\n\n\"Now, soft-foot. Before they reload. Sixty years I kept the ground under your " +
         "cliff, wondering what you would do with your second day. Choose what you are.\"",
  scale: "\n\nThe scale rides under your arm — its scale, yours now, sixty seconds more. Its " +
         "weight has an opinion."
};

EVENTS.push({
  id: "ch3g",
  title: { zh: "天空，与抉择", en: "The Sky, and the Choice" },
  text: [
    { when: { dragonTruth: true, scaleTaken: true },
      text: { zh: p9ZhBase + p9ZhSay.truth + p9ZhSay.scale,
              en: "You come up out of the borrowed shape the way a swimmer comes up out of dark water, and every sound on the summit changes its temperature at once.\n\nThe other dragon meets you at the height of the spire. It has not fled — the whole sky was open to it, road west and all — because it did not come up here to escape. It came up to find one thing, and the thing is you.\n\nYou lock. Sixty years out of practice, and the holds are all still there — the remembered arithmetic of it — claws finding the old places as if the fight had only paused, sixty years ago, and both parties had kept warm. Below you, in the firelight, the village watches the two beasts of its song performing the true version at last: over the black stones, under the actual sky.\n\nAnd up in the fleeting height — where no one can reach you, and you can reach no one — it speaks, close, in the voice from under the ground:\n\n\"Now, soft-foot. I have kept every promise I made you. I did not run from the mountain. I did not fight the chains. Here is the last one: I will not choose for you.\"\n\nThe scale rides under your arm — your own scale, the one that waited in the mountain for you for sixty years. Its weight has an opinion." } },
    { when: { dragonTruth: true },
      text: { zh: p9ZhBase + p9ZhSay.truth,
              en: "You come up out of the borrowed shape the way a swimmer comes up out of dark water, and every sound on the summit changes its temperature at once.\n\nThe other dragon meets you at the height of the spire. It has not fled — the whole sky was open to it, road west and all — because it did not come up here to escape. It came up to find one thing, and the thing is you.\n\nYou lock. Sixty years out of practice, and the holds are all still there — the remembered arithmetic of it — claws finding the old places as if the fight had only paused, sixty years ago, and both parties had kept warm. Below you, in the firelight, the village watches the two beasts of its song performing the true version at last: over the black stones, under the actual sky.\n\nAnd up in the fleeting height — where no one can reach you, and you can reach no one — it speaks, close, in the voice from under the ground:\n\n\"Now, soft-foot. I have kept every promise I made you. I did not run from the mountain. I did not fight the chains. Here is the last one: I will not choose for you.\"" } },
    { when: { scaleTaken: true },
      text: { zh: p9ZhBase + p9ZhSay.base + p9ZhSay.scale,
              en: "You come up out of the borrowed shape the way a swimmer comes up out of dark water, and every sound on the summit changes its temperature at once.\n\nThe other dragon meets you at the height of the spire. It has not fled — the whole sky was open to it, road west and all — because it did not come up here to escape. It came up to find one thing, and the thing is you.\n\nYou lock. Sixty years out of practice, and the holds are all still there — the remembered arithmetic of it — claws finding the old places as if the fight had only paused, sixty years ago, and both parties had kept warm. Below you, in the firelight, the village watches the two beasts of its song performing the true version at last: over the black stones, under the actual sky.\n\nAnd up in the fleeting height — where no one can reach you, and you can reach no one — it speaks, close, in the voice from under the ground:\n\n\"Now, soft-foot. Before they reload. Sixty years I kept the ground under your cliff, wondering what you would do when you woke a second time. Choose. Choose what you will become.\"\n\nThe scale rides under your arm — your own scale, the one that waited in the mountain for you for sixty years. Its weight has an opinion." } },
    { text: { zh: p9ZhBase + p9ZhSay.base,
              en: "You come up out of the borrowed shape the way a swimmer comes up out of dark water, and every sound on the summit changes its temperature at once.\n\nThe other dragon meets you at the height of the spire. It has not fled — the whole sky was open to it, road west and all — because it did not come up here to escape. It came up to find one thing, and the thing is you.\n\nYou lock. Sixty years out of practice, and the holds are all still there — the remembered arithmetic of it — claws finding the old places as if the fight had only paused, sixty years ago, and both parties had kept warm. Below you, in the firelight, the village watches the two beasts of its song performing the true version at last: over the black stones, under the actual sky.\n\nAnd up in the fleeting height — where no one can reach you, and you can reach no one — it speaks, close, in the voice from under the ground:\n\n\"Now, soft-foot. Before they reload. Sixty years I kept the ground under your cliff, wondering what you would do when you woke a second time. Choose. Choose what you will become.\"" } }
  ],
  choices: [
    { text: { zh: "“抓紧我。”把这场仗一路拖下山，直接撞进弩阵——翅膀，火焰，全部真相一齐砸下——在同一夜里，把箭和故事一起打碎。",
              en: "\"Hold on to me.\" Take the fight down the mountain to the crossbow line — " +
                  "wings, fire, the whole truth at full weight — break the bolts and break the " +
                  "story on the same night." },
      set: { climaxEnd: "force" }, next: "endA" },
    { text: { zh: "“往西。现在。”你挡在它爬升的路线和每一张弩之间，撑住整片天空，直到那对翅膀越过天际线。然后你再落下来，独自收拾这个世界。",
              en: "\"Go west. Now.\" Put yourself between its climb and every crossbow on the " +
                  "ridge, and hold the sky until the wings clear the horizon. You will come down " +
                  "and deal with the world after." },
      set: { climaxEnd: "yield" }, next: "endB" },
    { text: { zh: "“磨坊悬崖。”抓住它的爪子，拖着它一起往下——去你曾经坠落的地方，去一切真正发生过的那片地面。这一回，睁着眼。",
              en: "\"The mill cliff.\" Take its claw and take it down — the long fall you took " +
                  "once by accident, on the ground where it actually happened, and this time " +
                  "with your eyes open." },
      set: { climaxEnd: "fall" }, next: "endC" },
    { text: { zh: "“落下去。就落在他们面前。”让长者、卫队长和哭泣的村子，在火光里看见用四条腿站着的全部真相。再让那个手上沾墨的歌手，去唱这一版。",
              en: "\"Land. In front of all of them. In the firelight, in front of the elder and " +
                  "the captain and the whole weeping village — let them see the whole truth " +
                  "standing on four legs, and let the singer with the ink on {bHis} hands sing " +
                  "THAT.\"" },
      when: { inPartyA: true, inPartyB: true, inPartyC: true, path: "probe" },
      set: { climaxEnd: "rewrite" }, next: "endH" }
  ]
});

// —— ch3g 开场认领（回声工单 S3）——
// 上一页 ch3f 露露三选（revealAct 三值）；原 4 变体逐字保留，运行时扩为 16 条
const ch3gZhClaim = {
  silent: "你一个字也没有说。最先察觉的，是离你最近的那个卫兵，他手里的弩自己垂了下去。\n\n",
  voice:  "那声音起初还是人的嗓子，到了半截就不是了。下山路上的人，全都回过了头。\n\n",
  mirror: "盾面里，那张借来的脸最后一次望着你。\n\n你没有跟它道别，它也用不着你道别。\n\n"
};
(function () {
  const ev = EVENTS[EVENTS.length - 1]; // ch3g
  const src = ev.text, out = [];
  src.forEach(v => {
    const w = v.when || {};
    ["silent", "voice", "mirror"].forEach(a => out.push({
      when: Object.assign({ revealAct: a }, w),
      text: { zh: ch3gZhClaim[a] + v.text.zh, en: v.text.en }
    }));
    const def = { text: v.text };
    if (v.when) def.when = Object.assign({}, v.when);
    out.push(def);
  });
  ev.text = out;
})();

// ============================================================
//  endA · 以力止力
// ============================================================
const endAZhCore =
  "你一个俯冲就冲垮了弩阵。\n\n钉在你鳞上的弩箭，往后不过是几件纪念品，真正要紧的，是往后会流传下去的那个版本。今夜，你用最沉的分量把它写了下来：一个走下神坛的英雄，一头从没被杀死的怪物，还有一台碎在破笼子旁的山中机器。\n\n撕碎的文书烧得很好看。\n\n那只破铁笼会留在原地慢慢生锈，成为往后六代放羊娃都猜不透的谜。\n\n如今你什么都知道了，那场火、那次坠落、那张脸，还有那六十年，而你把这些全都带去了西方。村子再也没有机会问个明白，这就是你替他们了结这笔账时，收下的代价。\n\n第二天一早，西边的群山上空出现了两道影子，它们重新飞上古老的猎道，穿过旧日的风，飞向了那些还没有歌的地方。";
const endAEnCore =
  "You take the crossbow line in one pass.\n\n" +
  "What hits you are keepsakes. What matters has not been invented yet — the story-versions, " +
  "the ones that will be told — and you write those tonight, at full weight: a hero who came " +
  "down off the pedestal, a beast that was never slain, a mountain machine left in pieces " +
  "around an empty cage.\n\n" +
  "The broken writ burns nicely. The broken cage will rust where it stands, a puzzle for six " +
  "generations of shepherd children.\n\n" +
  "You know everything now — the fire, the fall, the faces, the sixty years. You take the " +
  "knowing west with you, and the village never gets to ask, and that is the price of doing " +
  "its arithmetic for it.\n\n" +
  "In the morning there are two shadows over the western ranges, flying the old prey-paths in " +
  "the old weather, traveling nowhere that has a song yet.";

EVENTS.push({
  id: "endA",
  title: { zh: "以力止力", en: "Force Against Force" },
  text: [
    { when: { fightWhy: "bond" },
      text: { zh: endAZhCore + "\n\n在某道山口之外，一笔欠了六十年的债，终于由两边一起还清了。从此以后，那两道影子谁都不再独自飞行。",
              en: "You take the crossbow line in one pass.\n\nWhat hits you are keepsakes. What matters has not been invented yet — the story-versions, the ones that will be told — and you write those tonight, at full weight: a hero who came down off the pedestal, a beast that was never slain, a mountain machine left in pieces around a broken cage.\n\nThe broken writ burns nicely. The broken cage will rust where it stands, a puzzle for six generations of shepherd children.\n\nYou know everything now — the fire, the fall, the face, the sixty years. You take the knowing west with you, and the village never gets to ask, and that is the price of doing its arithmetic for it.\n\nIn the morning there are two shadows over the western ranges, flying the old prey-paths in the old weather, traveling nowhere that has a song yet.\n\nSomewhere beyond the passes, a debt owed for sixty years was finally paid, by both sides together. From then on, neither shadow flew alone." } },
    { when: { fightWhy: "grudge" },
      text: { zh: endAZhCore +
                  "\n\n黄昏时分，越过第一道山口以后，两道影子分开了，东风归东，西风归西，心平气和地重新做回了敌人。\n\n这样的分别，比大多数友情都要干净。",
              en: "You take the crossbow line in one pass.\n\nWhat hits you are keepsakes. What matters has not been invented yet — the story-versions, the ones that will be told — and you write those tonight, at full weight: a hero who came down off the pedestal, a beast that was never slain, a mountain machine left in pieces around a broken cage.\n\nThe broken writ burns nicely. The broken cage will rust where it stands, a puzzle for six generations of shepherd children.\n\nYou know everything now — the fire, the fall, the face, the sixty years. You take the knowing west with you, and the village never gets to ask, and that is the price of doing its arithmetic for it.\n\nIn the morning there are two shadows over the western ranges, flying the old prey-paths in the old weather, traveling nowhere that has a song yet.\n\nOver the first pass, at dusk, the shadows split — east wind and west wind — enemies again, by mutual and honest consent. It is cleaner than most friendships." } },
    { text: { zh: endAZhCore, en: "You take the crossbow line in one pass.\n\nWhat hits you are keepsakes. What matters has not been invented yet — the story-versions, the ones that will be told — and you write those tonight, at full weight: a hero who came down off the pedestal, a beast that was never slain, a mountain machine left in pieces around a broken cage.\n\nThe broken writ burns nicely. The broken cage will rust where it stands, a puzzle for six generations of shepherd children.\n\nYou know everything now — the fire, the fall, the face, the sixty years. You take the knowing west with you, and the village never gets to ask, and that is the price of doing its arithmetic for it.\n\nIn the morning there are two shadows over the western ranges, flying the old prey-paths in the old weather, traveling nowhere that has a song yet." } }
  ],
  choices: [
    { text: { zh: "（翻页）", en: "(Turn the page)" }, next: "endA2" }
  ]
});

// ============================================================
//  endB · 让出传说
// ============================================================
const endBZhCore =
  "“往西，”你对它说，“现在。”\n\n于是你挡在它爬升的路线和弩阵之间，撑住了整片天空，就像当年你撑住山谷最后一线希望那样。\n\n你双翼大张，替那个正在离去的奇迹接下了整轮箭雨，直到那对翅膀越过山脊，西方吞没了你最后一个见证者。\n\n然后，你独自落了下来，落回黑石上，落回一个这片山谷再也不可能认错的形状里。\n\n你在哭泣的村民面前收拢双翼，收得那么轻，反倒比火焰更让他们害怕。\n\n你把那把传说之剑放在长者的脚边，剑尖朝前，就像一句话末尾的句号，又把故事的碎片留在了每个人都够得着的地方。\n\n那个被关过的，此刻正独自飞向西方，自由自在，无人陪伴。\n\n你想，这大概是它这辈子唯一真正开口要过的东西。\n\n第二天一早，你从田野上空不紧不慢地离开了。往后一百年里，村民们会一直争论，雕像那张脸凿掉以后，该换成谁的。\n\n那首歌还会唱下去，它会把地点唱错，会把一切都唱错，可这从来拦不住它。\n\n只是从今往后，它再也找不到一张可以唱错的脸了。";
const endBEnCore =
  "\"West,\" you tell it. \"Now.\"\n\n" +
  "And you put yourself between its climb and the crossbow line, and you hold the sky the way " +
  "you once held a valley's last chance — wings wide, taking the volley meant for a departing " +
  "miracle — until the wings clear the ridge, and the west swallows your only witness.\n\n" +
  "Then you come down. Alone, onto the black stones, in the shape nobody in this valley can " +
  "ever mistake again. You fold your wings in front of the whole weeping village, and you are " +
  "gentle about it, which frightens them more than fire ever did.\n\n" +
  "You lay the broken legend-sword at the elder's feet — point first, like the last word of a " +
  "sentence — and you leave the pieces of the story where all of them can reach. The caged " +
  "one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing " +
  "it ever actually asked of anyone.\n\n" +
  "In the morning you are gone over the fields, unhurried. The village spends the next hundred " +
  "years arguing about what to carve in place of the face they chiseled off the statue. The " +
  "song survives. It gets the location wrong. It gets everything wrong. That has never once " +
  "stopped it — and it has never again had a face to be wrong about.";

// endB 见证尾段（入队组合）
const endBZhA = "守祠人只用一句话就辞去了职务，却留下了那枚徽章，一直戴到老，也终于戴正了。";
const endBEnA = "The keeper of the shrine resigns {aHis} office in a single sentence, and keeps " +
                "the badge, and wears it for the rest of {aHis} life — straight, at last.";
const endBZhB = "佩兰在广场上把那首歌从头到尾稳稳地唱了一遍，就像在订正一份记录，把地点唱对了。在这座山谷里，这还是头一回。";
const endBEnB = "Perrin sings it once in the square, flat-voiced, like someone setting a record " +
                "straight, and gets the location right. It is the first song in this valley " +
                "that ever did.";
const endBZhAlly = "到了第二年开春，守祠人的档案向所有人开放了。那一家并没有因此饿死，事实证明，真故事一样换得来面包。";
const endBEnAlly = "The keeper's archive is open to the public by the following spring. The " +
                   "family has not starved. True stories, it turns out, also sell bread.";

EVENTS.push({
  id: "endB",
  title: { zh: "让出传说", en: "Yielding the Legend" },
  text: [
    { when: { inPartyA: true, inPartyB: true, keeperAlly: true },
      text: { zh: endBZhCore + "\n\n" + endBZhA + endBZhB + "\n\n" + endBZhAlly,
              en: "\"West,\" you tell it. \"Now.\"\n\nAnd you put yourself between its climb and the crossbow line, and you hold the sky the way you once held a valley's last chance — wings wide, taking the volley meant for a departing miracle — until the wings clear the ridge, and the west swallows your only witness.\n\nThen you come down. Alone, onto the black stones, in the shape nobody in this valley can ever mistake again. You fold your wings in front of the whole weeping village, and you are gentle about it, which frightens them more than fire ever did.\n\nYou lay the broken legend-sword at the elder's feet — point first, like the last word of a sentence — and you leave the pieces of the story where all of them can reach. The caged one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing it ever actually asked of anyone.\n\nIn the morning you are gone over the fields, unhurried. The village spends the next hundred years arguing about what to carve in place of the face they chiseled off the statue. The song survives. It gets the location wrong. It gets everything wrong. That has never once stopped it — and it has never again had a face to be wrong about.\n\nThe keeper of the shrine resigned {aHis} office in a single sentence, and kept the badge, and wore it for the rest of {aHis} life — straight, at last. Perrin sang it once in the square, flat-voiced, like someone setting a record straight, and got the location right. It was the first song in this valley that ever did.\n\nThe keeper's archive was open to the public by the following spring. The family had not starved. True stories, it turned out, also sold bread." } },
    { when: { inPartyA: true, inPartyB: true },
      text: { zh: endBZhCore + "\n\n" + endBZhA + endBZhB,
              en: "\"West,\" you tell it. \"Now.\"\n\nAnd you put yourself between its climb and the crossbow line, and you hold the sky the way you once held a valley's last chance — wings wide, taking the volley meant for a departing miracle — until the wings clear the ridge, and the west swallows your only witness.\n\nThen you come down. Alone, onto the black stones, in the shape nobody in this valley can ever mistake again. You fold your wings in front of the whole weeping village, and you are gentle about it, which frightens them more than fire ever did.\n\nYou lay the broken legend-sword at the elder's feet — point first, like the last word of a sentence — and you leave the pieces of the story where all of them can reach. The caged one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing it ever actually asked of anyone.\n\nIn the morning you are gone over the fields, unhurried. The village spends the next hundred years arguing about what to carve in place of the face they chiseled off the statue. The song survives. It gets the location wrong. It gets everything wrong. That has never once stopped it — and it has never again had a face to be wrong about.\n\nThe keeper of the shrine resigned {aHis} office in a single sentence, and kept the badge, and wore it for the rest of {aHis} life — straight, at last. Perrin sang it once in the square, flat-voiced, like someone setting a record straight, and got the location right. It was the first song in this valley that ever did." } },
    { when: { inPartyA: true },
      text: { zh: endBZhCore + "\n\n" + endBZhA, en: "\"West,\" you tell it. \"Now.\"\n\nAnd you put yourself between its climb and the crossbow line, and you hold the sky the way you once held a valley's last chance — wings wide, taking the volley meant for a departing miracle — until the wings clear the ridge, and the west swallows your only witness.\n\nThen you come down. Alone, onto the black stones, in the shape nobody in this valley can ever mistake again. You fold your wings in front of the whole weeping village, and you are gentle about it, which frightens them more than fire ever did.\n\nYou lay the broken legend-sword at the elder's feet — point first, like the last word of a sentence — and you leave the pieces of the story where all of them can reach. The caged one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing it ever actually asked of anyone.\n\nIn the morning you are gone over the fields, unhurried. The village spends the next hundred years arguing about what to carve in place of the face they chiseled off the statue. The song survives. It gets the location wrong. It gets everything wrong. That has never once stopped it — and it has never again had a face to be wrong about.\n\nThe keeper of the shrine resigned {aHis} office in a single sentence, and kept the badge, and wore it for the rest of {aHis} life — straight, at last." } },
    { when: { inPartyB: true, keeperAlly: true },
      text: { zh: endBZhCore + "\n\n" + endBZhB + "\n\n" + endBZhAlly,
              en: "\"West,\" you tell it. \"Now.\"\n\nAnd you put yourself between its climb and the crossbow line, and you hold the sky the way you once held a valley's last chance — wings wide, taking the volley meant for a departing miracle — until the wings clear the ridge, and the west swallows your only witness.\n\nThen you come down. Alone, onto the black stones, in the shape nobody in this valley can ever mistake again. You fold your wings in front of the whole weeping village, and you are gentle about it, which frightens them more than fire ever did.\n\nYou lay the broken legend-sword at the elder's feet — point first, like the last word of a sentence — and you leave the pieces of the story where all of them can reach. The caged one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing it ever actually asked of anyone.\n\nIn the morning you are gone over the fields, unhurried. The village spends the next hundred years arguing about what to carve in place of the face they chiseled off the statue. The song survives. It gets the location wrong. It gets everything wrong. That has never once stopped it — and it has never again had a face to be wrong about.\n\nPerrin sang it once in the square, flat-voiced, like someone setting a record straight, and got the location right. It was the first song in this valley that ever did.\n\nThe keeper's archive was open to the public by the following spring. The family had not starved. True stories, it turned out, also sold bread." } },
    { when: { inPartyB: true },
      text: { zh: endBZhCore + "\n\n" + endBZhB, en: "\"West,\" you tell it. \"Now.\"\n\nAnd you put yourself between its climb and the crossbow line, and you hold the sky the way you once held a valley's last chance — wings wide, taking the volley meant for a departing miracle — until the wings clear the ridge, and the west swallows your only witness.\n\nThen you come down. Alone, onto the black stones, in the shape nobody in this valley can ever mistake again. You fold your wings in front of the whole weeping village, and you are gentle about it, which frightens them more than fire ever did.\n\nYou lay the broken legend-sword at the elder's feet — point first, like the last word of a sentence — and you leave the pieces of the story where all of them can reach. The caged one goes west alone, and free, and unaccompanied — which was, you reflect, the only thing it ever actually asked of anyone.\n\nIn the morning you are gone over the fields, unhurried. The village spends the next hundred years arguing about what to carve in place of the face they chiseled off the statue. The song survives. It gets the location wrong. It gets everything wrong. That has never once stopped it — and it has never again had a face to be wrong about.\n\nPerrin sang it once in the square, flat-voiced, like someone setting a record straight, and got the location right. It was the first song in this valley that ever did." } },
    { text: { zh: endBZhCore, en: endBEnCore } }
  ],
  choices: [
    { text: { zh: "（翻页）", en: "(Turn the page)" }, next: "endB2" }
  ]
});

// ============================================================
//  endC · 坠落
// ============================================================
const endCZhCore =
  "“磨坊悬崖。”你说。另一条龙的眼睛已经替它回答了：对，那片地，就是那片地。\n\n于是你带着它越过了整个故事的头顶，越过黑石台，越过所谓的圣地，一路冲下山的另一侧，直到那面从没有哪首歌叫过名字的崖壁。真相的第一个版本就写在那里，有六十年前的爪痕，还有坑底一棵从裂缝里长出来的树。\n\n到了崖顶，你们抓紧彼此，收起了翅膀。\n\n六十年前，你从这片天空里意外坠落，带着火，胸膛里堵着整个山谷的未来，而你花了六十年，把那叫作一个谜。可此刻，在坠落之中，双翼收拢，利爪紧扣，大地像一笔旧债般迎面扑来，你终于想明白了：你回来，并不是为了弄清当年究竟发生了什么，而是为了亲自做出这个选择。\n\n很多年以后，磨坊主的孩子们会把这一夜讲给他们的孙辈听：两颗星落进了悬崖下的深潭，再也没有浮上来。\n\n那首歌还会把地点唱错，它总是什么都唱错，可这从来拦不住它。\n\n只是那年春天，坑底那棵树开了两回花，而磨坊家的狗每年都会礼貌地朝那面崖壁叫上一声，就像例行问候。";
const endCEnCore =
  "\"The mill cliff,\" you say, and the other dragon's eye says: yes. That ground. That " +
  "ground exactly.\n\n" +
  "You take it down over the top of the story — past the black table, past the holy stones, " +
  "down the mountain's wrong side, all the way to the wall of rock no song has ever named, " +
  "where the first version was written sixty years deep in claw-marks and a crater with a " +
  "tree growing out of it.\n\n" +
  "You let go at the top of it. Together.\n\n" +
  "Sixty years ago you fell out of this sky by accident, on fire, with a valley's whole " +
  "future dammed up in your lungs. You spent sixty years calling that a mystery. Falling " +
  "now — wings folded, claws locked, the ground coming up like a debt coming due — you can " +
  "finally file it where it belongs: you did not come back to find out what happened. You " +
  "came back to choose it.\n\n" +
  "The millers' children will tell their grandchildren about the night two stars went into " +
  "the river below the cliff pool and did not come out. The song will get the location wrong. " +
  "The song gets everything wrong. That has never once stopped it. But the tree at the bottom " +
  "of the crater blooms twice that spring, and the miller's dog barks at the cliff face " +
  "exactly once a year, politely, like a courtesy call.";

EVENTS.push({
  id: "endC",
  title: { zh: "睁眼坠落", en: "The Fall, Chosen" },
  text: [
    { when: { fightWhy: "bond" },
      text: { zh: endCZhCore + "\n\n你们紧紧抓着彼此坠下去，这是两个老朋友唯一从没试过的方向。",
              en: endCEnCore +
                  "\n\nYou go down holding on, which is the only direction two old friends " +
                  "have never tried." } },
    { when: { fightWhy: "grudge" },
      text: { zh: endCZhCore + "\n\n你们一路保持着搏杀的扣法坠落，直到最后一秒都还是敌人。坠落不会宽恕任何东西，但它会把每一笔账都算清。",
              en: endCEnCore +
                  "\n\nYou go down locked in combat-holds, enemies to the last. The fall " +
                  "forgives nothing, but it settles everything." } },
    { text: { zh: endCZhCore, en: endCEnCore } }
  ],
  choices: [
    { text: { zh: "（翻页）", en: "(Turn the page)" }, next: "endC2" }
  ]
});

// ============================================================
//  endH · 当众改写（隐藏结局：三人全同行＋揭穿线＋终拍第四项）
// ============================================================
const endHZhCore =
  "你落了下去。\n\n就落在所有人的面前，落在黑石上，落进火光里，落在长者没念完的文书和卫队长端平的弩阵之间。\n\n一条龙把自己安放在一个村子的正中央，就像一个词终于被放进了它的句子。\n\n弩没有射出去，因为守祠人走进了射线。\n\n那枚一辈子都嫌太大的家族徽章，此刻仿佛撑住了整个传说的重量，就像柱子撑住屋顶。“把你们看见的写下来。”\n\n守祠人对卫兵说，用的正是当年起草文书的那个人的口吻。这并不是请求。\n\n佩兰已经爬上了基座，手上还沾着墨，{bHe}的笔比{bHis}的调子还要快。\n\n而歌里的那头怪物，那个山谷之火、收成的毁灭者，在黑石上收拢双翼，低下了头，就像一个正在宣誓的证人。\n\n你把一切都告诉了他们：烟里走出的陌生人，托尔岗上空的两条龙，为了杀死那场火而把它吞下的你，六十年的沉睡，笼子里抓错的兽，还有磨坊边的悬崖。长者伏在文书上哭了。卫队长在随身的小本子上记得比谁都多，却始终没有说他究竟信了什么。\n\n守祠人最后擦了一次雕像，然后当着所有人的面，郑重地停了手。有些照料，是可以就此结束的。\n\n佩兰把整首歌从头到尾平平稳稳地唱了一遍，就像在订正一本总账，{bHe}把地点唱对了，这在山谷里还是第一次。";
const endHEnCore =
  "You land.\n\n" +
  "In front of everyone. On the black stones, in the firelight, in the middle of the elder's " +
  "unfinished writ and the captain's leveled crossbows — a dragon setting itself down in the " +
  "middle of a village, like a word being set into a sentence.\n\n" +
  "The crossbow does not fire, because the keeper of the shrine walks into the line of it. " +
  "{aHis} family's badge — too big for {aHis} chest for the whole of {aHis} life — holds up the entire " +
  "weight of a legend like someone holding up a roof. \"Write down what you see,\" {aHe} tell{aVs} the " +
  "guard, in exactly the voice of the ones who wrote the writ, and it is not a request.\n\n" +
  "The singer is already on the pedestal with the ink still on {bHis} hands, writing faster than " +
  "a melody.\n\n" +
  "And the beast of the song — the fire of the valley, the ruin of the harvest — folds its " +
  "wings on the black stone and lays its head down like a witness taking an oath.\n\n" +
  "You tell them all of it: the stranger in the smoke, the two dragons above the Tor, the " +
  "fire swallowed to kill it, the sixty years of sleep, the arrest of the wrong beast, the " +
  "cliff by the mill. The elder weeps into the writ. The captain writes more than anyone, in " +
  "a little soldier's book, and does not once say what he is.\n\n" +
  "The keeper polishes the statue one last time, and then — with ceremony, in front of " +
  "everyone — does not. Some kinds of care are allowed to stop. Perrin sings it straight " +
  "through, once, in the flat voice of someone correcting a ledger. {bHe} get{bVs} the location " +
  "right. It is the first song in the valley that ever has.";

EVENTS.push({
  id: "endH",
  title: { zh: "当众改写", en: "The Rewriting" },
  // 2026-10-17 修复：fightWhy 只在 flee 线 c4 设置，而 endH 要求 path=probe，
  // bond/grudge 两变体永远不可达（v8walk 实测 0 命中）——bond 句逐字并入默认正文后删除两变体。
  // 同时修复默认版龙去向缺失与 cLove 余响「叠好的外套」的矛盾。
  text: [
    { text: { zh: endHZhCore +
                  "\n\n另一条龙在高处那个真正的巢里过了冬，那不是笼子，而是巢；而你们终于发现，一座山上住两条龙，也没有那么挤。山谷里有些人，到死都不肯相信这个版本。可从这一夜流传下来的那首歌，多了旧歌从来没有过的三段。六十年后，在别的某个村子里，孩子们会玩一种新的游戏，在那个游戏里，谁都不必去扮怪物。",
              en: "You land.\n\nIn front of everyone. On the black stones, in the firelight, in the middle of the elder's unfinished writ and the captain's leveled crossbows — a dragon setting itself down in the middle of a village, like a word being set into a sentence.\n\nThe crossbow does not fire, because the keeper of the shrine walks into the line of it. {aHis} family's badge — too big for {aHis} chest for the whole of {aHis} life — holds up the entire weight of a legend like someone holding up a roof. \"Write down what you see,\" {aHe} tell{aVs} the guard, in exactly the voice of the ones who wrote the writ, and it is not a request.\n\nThe singer is already on the pedestal with the ink still on {bHis} hands; {bHe} write{bVs} faster than a melody.\n\nAnd the beast of the song — the fire of the valley, the ruin of the harvest — folds its wings on the black stone and lays its head down like a witness taking an oath.\n\nYou tell them all of it: the stranger in the smoke, the two dragons above the Tor, the fire swallowed to kill it, the sixty years of sleep, the arrest of the wrong beast, the cliff by the mill. The elder weeps into the writ. The captain writes more than anyone, in a little soldier's book, and does not once say what he believes.\n\nThe keeper polishes the statue one last time, and then — with ceremony, in front of everyone — does not. Some kinds of care are allowed to stop. Perrin sings it straight through, once, in the flat voice of someone correcting a ledger. {bHe} get{bVs} the location right. It is the first song in the valley that ever has.\n\nThe other dragon stays the winter in the high den — the real one, not the cage — and it turns out two is not such a strange number after all. Some of them will refuse until they die. But the song that survives this night has three verses the old one never carried — and sixty years from tonight, in some other village, children will play the game where nobody has to be the beast." } }
  ],
  choices: [
    { text: { zh: "（翻页）", en: "(Turn the page)" }, next: "endH2" }
  ]
});

// ============================================================
//  结局余响页（endA2/endB2/endC2/endH2）
//  单命中变体：按优先级渲染玩家最重的那一条余味。
//  变量消费：veteranSaved / shoeTaken / dogStart / keep / widowMemory
// ============================================================

// 余响共享段（跨结局通用）
const afterZhVet =
  "老兵又活了许多年，这辈子当了两回见证者。第二回，他整整三年没对外人提过一个字；等到终于肯开口时，他总是从那枚徽章讲起。";
const afterEnVet =
  "The old soldier lives to be a witness twice over. He does not tell this one for " +
  "three years, and when he does, he starts with the badge.";
const afterZhVetLost =
  "那枚徽章和它的主人一起留在了山上。有些人，生来就该和自己的证据葬在一处。";
const afterEnVetLost =
  "The badge and its keeper stay on the mountain together. Some men are buried with " +
  "their proof.";
const afterZhDog =
  "村口那条黄狗说什么也不肯被丢下，硬是跟着你们往西去了。不出一个星期，它就什么都不怕了，连打雷也不例外。";
const afterEnDog =
  "The yellow dog from the gate refuses to be left behind, and by the end of the " +
  "first week, living under two dragons has made something new and unkillable out of " +
  "its nerves.";
const afterZhCoin =
  "此后许多个寒冷的夜里，你的爪子仍会摸到鳞下那枚小小的、半熔的硬币。有些问题，你留着并不是为了解答，只是为了一直带在身边。";
const afterEnCoin =
  "On cold nights, your claws still find the little half-melted coin under the " +
  "scale. Some questions you carry — not to answer. To keep.";
const afterZhRing =
  "那枚小银戒被留在了雕像的石指上。谁也戴不上它，可村里人很快就认定，它本来就属于那里；久而久之，再没有人想过要把它取下来。";
const afterEnRing =
  "The little silver ring is left on the statue's stone finger, where it fits " +
  "nobody. The village decides it has always been there.";
const afterZhBase =
  "山还立着。歌也还在。";
const afterEnBase =
  "The mountain still stands. The song still stands.";

EVENTS.push({
  id: "endA2",
  title: { zh: "后来", en: "After" },
  // stack 叠加段：多命中全显示（遮蔽修复——此前 first-match 只显示老兵一条）
  text: [
    { stack: [
        { when: { veteranSaved: true }, text: { zh: afterZhVet, en: "The old soldier lived to be a witness twice over. He did not tell this one for three years, and when he did, he always started with the badge." } },
        { when: { veteranSaved: false }, text: { zh: afterZhVetLost, en: "The badge and its owner stayed on the mountain together. Some men are buried with their proof." } },
        { when: { shoeTaken: true },
          text: { zh: "那只过节穿的小鞋卡在你翼关节的弯处，跟着你去了西方，飞过了许多座山。直到某个起风的傍晚，你绕回山谷，把它轻轻放在了它主人家的窗台上。",
                  en: "The festival shoe went west with you, tucked in the crook of a wing-joint, over many mountains — until one windy evening you looped back into the valley and set it down on its owner's windowsill." } },
        { when: { dogStart: true }, text: { zh: afterZhDog, en: "The yellow dog from the gate refused to be left behind and followed you west. Within a week it was afraid of nothing — not even thunder." } },
        { when: { keep: "arrow" },
          text: { zh: "那支烧焦的箭，终于朝着它一直该去的方向去了：箭头朝西，从此再没有回头。",
                  en: "The burned arrow finally rode where it was always going: point west, like everything else you kept." } },
        { when: { keep: "ring" }, text: { zh: afterZhRing, en: "The little silver ring was left on the statue's stone finger, where it fits nobody. The village soon decided it had always been there, and in time no one thought to take it off." } },
        { when: { keep: "coin" }, text: { zh: afterZhCoin, en: afterEnCoin } },
      ],
      fallback: { text: { zh: afterZhBase, en: afterEnBase } } }
  ],
  choices: [
    { text: { zh: "（翻到最后一页）", en: "(Turn to the last page)" }, next: "ENDING_CHECK" }
  ]
});

EVENTS.push({
  id: "endB2",
  title: { zh: "后来", en: "After" },
  // stack 叠加段：多命中全显示（遮蔽修复）
  text: [
    { stack: [
        { when: { veteranSaved: true }, text: { zh: afterZhVet, en: "The old soldier lived to be a witness twice over. He did not tell this one for three years, and when he did, he always started with the badge." } },
        // 老兵未获救（老兵余响工单 · Claude 成句；en 为直译占位，E1 管线重做）
        { when: { veteranSaved: false }, text: { zh: "老兵没能从山上下来，下山的是他的徽章。村里人把它挂在了祠堂门边，从此每逢有人讲起那一夜，总要先朝那里看上一眼。", en: "The old soldier never came down the mountain; his badge did. The village hung it beside the shrine door, and ever since, every telling of that night began with a glance at it." } },
        { when: { widowMemory: true },
          text: { zh: "第一个大声说出“是龙替我们撑住了天”的，是面包店的老妇人。后来，全村人都信了她，倒不是因为她拿得出什么证据，而是因为她年纪大；在这个村子里，老人本身就是史书。",
                  en: "The bread-stall woman was the first to say, out loud, that the dragon had held the sky open. The village believed her eventually — not because she could produce any proof, but because she was old; in this village, the old are the only history books it keeps." } },
        { when: { shoeTaken: true },
          text: { zh: "你把那只缝着金线的小鞋留在了磨坊的第一级台阶上。它的主人不到中午就找到了它，此后用了一辈子的时间，一遍又一遍地编着它是怎么自己走回来的。",
                  en: "You left the small gold-stitched shoe on the first step of the mill. Its owner found it before noon, and spent a lifetime inventing, over and over, the story of how it had walked back on its own." } },
        { when: { dogStart: true },
          text: { zh: "村口那条黄狗说什么也不肯被丢下，追着你的影子，一直跑到了河边才停下。后来村里人常说，全村上下，只有它送过龙一程。", en: "The yellow dog from the gate refused to be left behind; it chased your shadow all the way to the river before it stopped. The village would say, for years after, that of everyone in it, only the dog had ever walked a dragon part of the way." } },
        { when: { keep: "arrow" },
          text: { zh: "那支烧焦的箭，终于朝着它一直该去的方向去了：箭头朝西，从此再没有回头。",
                  en: "The burned arrow finally rode where it was always going: point west, like everything else you kept." } },
        { when: { keep: "ring" }, text: { zh: afterZhRing, en: "The little silver ring was left on the statue's stone finger, where it fits nobody. The village soon decided it had always been there, and in time no one thought to take it off." } },
        { when: { keep: "coin" }, text: { zh: afterZhCoin, en: afterEnCoin } },
      ],
      fallback: { text: { zh: afterZhBase, en: afterEnBase } } }
  ],
  choices: [
    { text: { zh: "（翻到最后一页）", en: "(Turn to the last page)" }, next: "ENDING_CHECK" }
  ]
});

EVENTS.push({
  id: "endC2",
  title: { zh: "后来", en: "After" },
  // stack 叠加段：多命中全显示（遮蔽修复）；ring 句为坠崖语境改写（不能是被你放下的）
  text: [
    { stack: [
        { when: { veteranSaved: true }, text: { zh: afterZhVet, en: "The old soldier lived to be a witness twice over. He did not tell this one for three years, and when he did, he always started with the badge." } },
        // 老兵未获救（老兵余响工单 · Claude 成句；en 为直译占位，E1 管线重做）
        { when: { veteranSaved: false }, text: { zh: "火熄了以后，人们才在山上找到老兵。他手里还攥着那枚徽章，已经熏得发黑。后来，徽章交到了一个从没上过山的孩子手里，那段往事就由他接着讲下去。", en: "Only after the fire died did they find the old soldier on the mountain, the badge blackened in his fist. It passed to a child who had never climbed the mountain, and the telling went on through him." } },
        { when: { shoeTaken: true },
          text: { zh: "那只小鞋跟着你们一起落进了潭里，到了第二年开春，又独自漂回了岸边。潭水对小东西向来宽厚，它要收下的，从来只有大的。",
                  en: "The small shoe went into the pool with you, and by the following spring it had drifted back to the bank on its own. The pool is gentle with small things; it is the large ones it wants." } },
        { when: { dogStart: true },
          text: { zh: "村口那条黄狗在磨坊悬崖下守了整整一个冬天，任谁来唤都不肯走，直到开春冰化，它才独自回了家。", en: "The yellow dog from the gate kept watch below the mill cliff the whole winter and would not leave for anyone who called, until the ice broke in spring and it went home alone." } },
        { when: { keep: "arrow" },
          text: { zh: "那支烧焦的箭先你们一步落进了崖底的水潭，兜兜转转六十年，它终于指向了正确的方向：向下。",
                  en: "The burned arrow went into the water at the foot of the cliff ahead of you, and after sixty years of wandering it pointed the right way at last: down." } },
        { when: { keep: "ring" },
          text: { zh: "后来，有人在雕像的石指上发现了那枚小银戒。谁也说不清它是什么时候、又是被谁戴上去的。",
                  en: "Later, someone found the little silver ring on the statue's stone finger. No one could say when it had been put there, or by whom." } },
        { when: { keep: "coin" },
          text: { zh: "落水前的最后一刻，你脑中闪过那枚小小的、半熔的硬币，还有金属熔化时的气味。六十年过去，那个问题依旧没有答案；而有些问题，注定只能湿淋淋地带进水底。",
                  en: "The last thing through your mind before the water was a small half-melted coin and the smell of it melting. Sixty years, and the question keeps. Some questions you take home wet." } },
      ],
      fallback: { text: { zh: afterZhBase, en: afterEnBase } } }
  ],
  choices: [
    { text: { zh: "（翻到最后一页）", en: "(Turn to the last page)" }, next: "ENDING_CHECK" }
  ]
});

EVENTS.push({
  id: "endH2",
  title: { zh: "后来", en: "After" },
  // stack 叠加段：多命中全显示（遮蔽修复）
  text: [
    { stack: [
        { when: { veteranSaved: true }, text: { zh: afterZhVet, en: "The old soldier lived to be a witness twice over. He did not tell this one for three years, and when he did, he always started with the badge." } },
        // 老兵未获救（老兵余响工单 · Claude 成句；en 为直译占位，E1 管线重做）
        { when: { veteranSaved: false }, text: { zh: "老兵等了六十年，只差这一夜。那天晚上全村人听到的真相，他一个字也没能听见。后来有人把徽章摆在他的坟前，就当是替他听过了。", en: "The old soldier waited sixty years and missed it by one night. He did not hear a word of the truth the village heard that night. Later, someone set the badge on his grave, as if it could listen in his place." } },
        { when: { shoeTaken: true },
          text: { zh: "当着全村人的面，你把那只缝着金线的小鞋还给了它的主人。日落之前，她穿着它跑遍了整个广场，逢人就说这是龙的鞋。这话只有一半是真的，可另一半，也从来没有人去纠正。",
                  en: "In front of the whole village, you gave the small gold-stitched shoe back to its owner. She ran the square in it before sundown, telling everyone it was a dragon's shoe — which was half true, and no one ever corrected the other half." } },
        { when: { dogName: ["coal", "bread"] },
          text: { zh: "改写之后的那个下午，你在广场上唤了一声，黄狗便应着你给它起的名字，从广场那头一路朝你跑来。看着它跑过去，广场上的每个人都松了一口气：会应自己名字的东西，就不是怪物。",
                  en: "In the afternoon after the rewriting, the yellow dog trotted the whole width of the square to you — you had called, and it answered to the name you gave it. And after it passed, everyone in the square breathed easier: a thing that answers to a name is not a monster." } },
        { when: { dogStart: true },
          text: { zh: "从那以后，村口那条黄狗常在祠堂门口打盹，哪怕龙从它头顶飞过，它也连眼皮都懒得抬一下。", en: "After that, the yellow dog from the gate often dozed at the shrine door, and would not even lift an eyelid when a dragon passed overhead." } },
        { when: { keep: "arrow" },
          text: { zh: "那支烧焦的箭如今挂在祠堂的横梁上，就挂在那把从没开过刃的剑旁边。一个诚实的村子，总也得留下一两个谎言当摆设。",
                  en: "The burned arrow hangs now from the shrine's beam, next to the sword " +
                      "that never had an edge. An honest village keeps a lie or two for " +
                      "furniture." } },
        { when: { keep: "ring" }, text: { zh: afterZhRing, en: "The little silver ring was left on the statue's stone finger, where it fits nobody. The village soon decided it had always been there, and in time no one thought to take it off." } },
        { when: { keep: "coin" }, text: { zh: afterZhCoin, en: afterEnCoin } },
      ],
      fallback: { text: { zh: afterZhBase, en: afterEnBase } } }
  ],
  choices: [
    { text: { zh: "（翻到最后一页）", en: "(Turn to the last page)" }, next: "ENDING_CHECK" }
  ]
});

// ============================================================
//  G1/G2 · 告白页四态认领（情感线填充工单 · Claude 成句落盘）
//  ch3p1b（隔笼夜访页）：aBond=hand（伸手暧昧）／ aBond=step（退开婉拒）／
//    aLove=true（吻线）／ 兜底（守岗/问祠堂/绕营地/无A线）各一句，插在变体开头
//  ch3p1d（化形页）：bBond=string（按弦暧昧）／ bBond=stick（添柴保持距离）／
//    bLove=true（吻线）／ 兜底（等抄写/问归属/回铺/无B线）各一句
//  认领句仅落 zh（en 留待翻译阶段）；原文一字不改；first-match 语义：带值条目在前、兜底在后
// ============================================================
(function () {
  const claimZh = {
    g1hand:   "那只手握了很久，久到老茧底下的温度也渗了过来。直到换岗的人走近，守祠人才松开，什么也没说。\n\n",
    g1step:   "守祠人没有追上那半步，只点了点头，像收下一张还没到期的借据。夜风从你们之间穿了过去。\n\n",
    g1love:   "那一班岗，你们的肩膀再没分开过。\n\n守祠人走后很久，那点暖意还留在你半边身子上。\n\n",
    g1base:   "那一夜你虽然躺下了，眼睛却一直睁着，望着火光后面的那只铁笼。\n\n",
    g2string: "琴弦在你掌心底下颤了很久才停。\n\n佩兰没有把琴抽回去，你也没有收手。\n\n",
    g2stick:  "新添的柴噼啪作响，把你们隔在火光两边，各自亮着。\n\n佩兰低下头，重新调起了弦。\n\n",
    g2love:   "后来佩兰枕着琴睡着了。\n\n你替{bHim}把滑落的毯子拉好，自己守着火。\n\n",
    g2base:   "你看着余烬一点点暗下去，目光不知不觉越过火堆，落到了铁笼那边。\n\n"
  };
  function expand(evId, states, baseZh) {
    const ev = EVENTS.find(e => e.id === evId);
    if (!ev) throw new Error("G1/G2 认领：找不到事件 " + evId);
    const out = [];
    ev.text.forEach(v => {
      states.forEach(st => {
        const w = Object.assign({}, v.when);
        w[st.whenKey] = st.val;
        out.push({ when: w, text: { zh: st.zh + v.text.zh, en: v.text.en } });
      });
      const d = { text: { zh: baseZh + v.text.zh, en: v.text.en } };
      if (v.when) d.when = Object.assign({}, v.when);
      out.push(d);
    });
    ev.text = out;
  }
  expand("ch3p1b", [
    { whenKey: "aBond", val: "hand",  zh: claimZh.g1hand },
    { whenKey: "aBond", val: "step",  zh: claimZh.g1step },
    { whenKey: "aLove", val: true,    zh: claimZh.g1love }
  ], claimZh.g1base);
  expand("ch3p1d", [
    { whenKey: "bBond", val: "string", zh: claimZh.g2string },
    { whenKey: "bBond", val: "stick",  zh: claimZh.g2stick },
    { whenKey: "bLove", val: true,     zh: claimZh.g2love }
  ], claimZh.g2base);
})();

// ============================================================
//  G4 · 结局页 Love 余味（情感线填充工单 · Claude 成句落盘）
//  endA：同行未在一起的 A/B 各一句（aLove/bLove=false）＋ aLove/bLove 各一句
//  endB：整段替换式变奏——Love 版守祠人/歌手尾段替换原尾段（英文已回填，2026-10-20）
//  endC：cLove 爪子句＋留在村里的 aLove/bLove 恋人各一句（可同屏）
//  endH：三线各一句，追加在现有尾段之后
//  原文一字不动；全部为 stack 叠加段，不影响结局判定与标志逻辑。
// ============================================================
(function () {
  // —— endA 追加条目（对每个 fightWhy 变体都适用）——
  const afterA = [
    { when: { inPartyA: true, aLove: false },
      text: { zh: "守祠人第二天照常开了祠堂的门，只是那块抹布，再没碰过雕像。",
              en: "The keeper opened the shrine doors the next day as usual — but the rag never touched the statue again." } },
    { when: { inPartyB: true, bLove: false },
      text: { zh: "佩兰把那首歌改到一半就搁下了，说剩下的那段，等飞走的回来再唱。",
              en: "Perrin got halfway through rewriting the song and set it down, saying the rest could wait until the one who flew off came back." } },
    { when: { aLove: true },
      text: { zh: "守祠人从此再也没有擦过那座雕像，只是每到黄昏，那枚徽章总要朝着西边的天，多停留一会儿。",
              en: "The keeper never polished that statue again. Only at dusk, the badge would linger a moment longer, turned toward the western sky." } },
    { when: { bLove: true },
      text: { zh: "佩兰后来给那首歌添了一段，却从不在广场上唱。有人问起这段是写给谁的，佩兰只朝西边扬一扬下巴。",
              en: "Perrin added a verse to the song later, but never sang it in the square. When people asked who it was written for, Perrin only tipped a chin toward the west." } }
  ];
  // —— endC 追加条目 ——
  const afterC = [
    { when: { cLove: true },
      text: { zh: "坠到一半时，它在风里换了一下爪子的位置：那不再是搏杀的扣法，而是人牵手的那一种。",
              en: "Halfway down, it changed the grip of its claws in the wind — no longer the way a fighter locks on, but the way people hold hands." } },
    { when: { aLove: true },
      text: { zh: "守祠人在磨坊悬崖边一直站到天黑，临走之前，把那枚徽章留在了崖顶的石头上。",
              en: "The keeper stood at the mill cliff until dark, and left the badge on the stone at the top before going." } },
    { when: { bLove: true },
      text: { zh: "那首歌后来多了一段，没有词，只有六小节。唱到最后一个音时，佩兰总是不收弦。",
              en: "The song gained a verse after that — no words, just six bars. On the last note, Perrin never damped the string." } }
  ];
  // —— endH 追加条目 ——
  const afterH = [
    { when: { aLove: true },
      text: { zh: "那双擦了一辈子雕像的手停下以后，就再也没有空着过，它总在找你的手。",
              en: "The hands that had polished the statue for a lifetime were never idle again. They were always looking for yours." } },
    { when: { bLove: true },
      text: { zh: "新添的三段里，有六小节佩兰从不当众唱，总要等到火堆旁只剩下你们俩的时候。",
              en: "Of the three new verses, six bars from one Perrin never sang in public — only when the two of you were left alone by the fire." } },
    { when: { cLove: true },
      text: { zh: "每年下头一场雪时，你都会在门口发现一件叠得整整齐齐的外套，也不知又是从谁的行李里顺来的。",
              en: "Every year at the first snow, you would find a coat folded neatly at the door — lifted from somebody's baggage again, no telling whose." } }
  ];
  // —— endB Love 版替换尾段（整段替换式变奏）——
  const endBZhALove =
    "守祠人只用一句话就辞去了职务，却留下了那枚徽章，一直戴到老，也终于戴正了。徽章的背面，多了一个新刻的名字。";
  const endBEnALove =
    "The keeper resigned from the shrine in one sentence, kept the badge, wore it into old age — and finally wore it straight. On the back of it, a name newly cut.";
  const endBZhBLove =
    "佩兰在广场上把那首歌从头到尾稳稳地唱了一遍，就像在订正一份记录，把地点唱对了。在这座山谷里，这还是头一回。唱到桥中央那一段时，佩兰停了一拍，抬头望了一眼你离开的那片天。";
  const endBEnBLove =
    "Perrin sang it once in the square, beginning to end, steady — like someone setting a record straight — and got the location right. It was the first time in this valley. At the bridge verse, Perrin stopped for a beat and looked up at the patch of sky you had left by.";

  function wrapAfter(evId, extras) {
    const ev = EVENTS.find(e => e.id === evId);
    if (!ev) throw new Error("G4 包装：找不到事件 " + evId);
    ev.text = ev.text.map(v => {
      const items = [{ text: v.text }].concat(extras.map(o => ({ when: Object.assign({}, o.when), text: o.text })));
      const w = v.when ? { when: Object.assign({}, v.when), stack: items } : { stack: items };
      return w;
    });
  }
  wrapAfter("endA", afterA);
  wrapAfter("endC", afterC);
  wrapAfter("endH", afterH);

  // —— endB：消掉 6 条组合枚举，改为单 stack 条目（aLove/bLove 真值选段；ally 保持原显示条件）——
  const evB = EVENTS.find(e => e.id === "endB");
  if (!evB) throw new Error("G4 包装：找不到事件 endB");
  evB.text = [{ stack: [
    { text: { zh: endBZhCore, en: endBEnCore } },
    { when: { inPartyA: true, aLove: true },  text: { zh: endBZhALove, en: endBEnALove } },
    { when: { inPartyA: true, aLove: false }, text: { zh: endBZhA, en: "The keeper of the shrine resigned {aHis} office in a single sentence, and kept the badge, and wore it for the rest of {aHis} life — straight, at last." } },
    { when: { inPartyB: true, bLove: true },  text: { zh: endBZhBLove, en: endBEnBLove } },
    { when: { inPartyB: true, bLove: false }, text: { zh: endBZhB, en: "Perrin sang it once in the square, flat-voiced, like someone setting a record straight, and got the location right. It was the first song in this valley that ever did." } },
    // keeperAlly 原矩阵语义：ally 段只在原「B 在场」的两条变体（A+B+ally / B+ally）里出现过，
    // 即 iff keeperAlly && inPartyB；原「仅 A 在场」变体没有 ally 段，保持原样不补
    { when: { keeperAlly: true, inPartyB: true }, text: { zh: endBZhAlly, en: "The keeper's archive was open to the public by the following spring. The family had not starved. True stories, it turned out, also sold bread." } }
  ] }];
})();
