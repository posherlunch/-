﻿// ============================================================
//  序章 · 苏醒（p0–p4）
//  写法基准：实测《Fox Spirit》免费三章 ——
//    单屏 120–170 字；3–5 段；长句逗号链＋短促落点；
//    选项带身体感与台词。
//  双语成对：en 是英文初稿（占位），zh 是验收中文稿。
//  ⚠ 英文等润色稿回传后整体替换 en 字段，结构不动。
//  六个单选变量在序章定下：claw / keep / face / gender / voice / habit
//  人物面板显示文字在 00-config.js 的 TRAITS 里，改选项记得同步。
// ============================================================

// ---------- 共享正文段（拼接用） ----------

// p0b 的旧藏正文（前接磨爪后果段）
const p0bZhTail =
  "你的宝藏还在。说是宝藏，其实从来算不上什么，不过是一条龙视若珍宝的一堆破烂：一支断箭、一枚半熔的硬币，还有一枚小得塞不满你一个鼻孔的银戒。\n\n它们在别人眼里一文不值，对你却不然。\n\n你记得自己曾经想要过它们，这就够了。\n\n化作人形以后，你带不走整堆宝藏，所以只能挑一件，塞进肩头那片松动的鳞片底下。";
const p0bEnTail =
  "Your hoard survived you. It was never much of a hoard—a dragon's worth of " +
  "nothing: a broken arrow, a half-melted coin, a silver ring small enough to " +
  "sit inside your nostril. Worthless to anyone but you. But you remember " +
  "wanting them once, and that is enough.\n\n" +
  "You cannot carry a hoard in a human shape. One thing, then, tucked under " +
  "the loose scale at your shoulder.";

// p1 的出洞正文（前接旧藏后果段）
const p1ZhTail =
  "你站起身来，洞穴在你四周缩小了；又或者是你长大了，把它撑得满满当当，就像一棵树撑破了本就嫌小的花盆。\n\n你低下头，侧过肩膀，从巢口挤了出去，岩石刮过鳞片，寒冷的夜风像一堵墙一样迎面撞来。\n\n山谷变了。\n\n你早知道会这样。\n\n你睡过去的六十年，山下的人是一天一天熬过来的。从前那里只有几间茅屋和一条车辙坑洼的土路，如今灯火之中却铺开了一座村庄，有围墙，有屋顶，还有一座你不认识的教堂尖塔。\n\n十几根烟囱正冒着炊烟，远处有一条狗叫了起来，紧接着又是一条。\n\n风里送来了柴烟和新烤面包的香气，其间还夹着落地苹果那股淡淡的、甜丝丝的腐味。\n\n然而，你的目光并没有停在村子上。\n\n你盯着的是村子中央的广场。\n\n那里立着一座比人还高的雕像，披风甩在一边肩头，长剑高高举起，四周围着一圈火把。\n\n尽管隔得这么远，火光还是把那张脸照得清清楚楚。\n\n你认得那张脸。";
const p1EnTail =
  "You rise. The cave shrinks around you — or perhaps you have grown into it, " +
  "the way a tree grows into a pot that was always too small. You lower your " +
  "head and shoulder through the mouth of the den, rocks grating against your " +
  "scales, and the cold night air hits you like a wall.\n\n" +
  "The valley has changed.\n\n" +
  "You knew it would. Sixty years is a long time for anything that does not " +
  "sleep. Below you, where there was once only a handful of thatched roofs and " +
  "a single rutted road, a village spreads out in the lamplight — walls and " +
  "roofs and a church steeple you do not recognize. Smoke rises from a dozen " +
  "chimneys. Somewhere a dog barks, then another. The wind carries woodsmoke " +
  "and baking bread and the faint, sweet rot of fallen apples.\n\n" +
  "But your eyes are not on the village. They are on the square at its center, " +
  "where a new statue stands on a pedestal, taller than a man, its cape thrown " +
  "back over one shoulder and a sword raised in one hand. Torches ring it. " +
  "Even from this distance, the firelight catches the face.\n\n" +
  "You know that face.";

// ============================================================
//  p0 · 苏醒
// ============================================================
INTRO.push({
  id: "p0",
  title: { zh: "苏醒", en: "Waking" },
  text: {
    zh: "你醒来时，整座山正压在你的背上。\n\n六十年来，它一直缓慢而耐心地倚着你，就像大地倚着一切忘了动弹的东西。\n\n你吸进了第一口气，那口气仿佛隔了一整个永恒，肋骨随之像干柴一样噼啪作响，那声音顺着脊椎一路传到了尾巴尖，尘土也从你的鼻孔里簌簌落下。\n\n石壁又冷又硬，可在你的鳞片底下，却有一股更暖的暗流正在慢慢苏醒，它等待的时间，和你一样久。\n\n你屈了屈一只前爪，爪尖刮过洞底，可那声音不对，太尖也太细，仿佛你睡着的时候爪子还在一直生长，如今已经弯得太过、利得太过了。\n\n你睁开眼睛，黑暗立刻清晰而完整地回应了你：岩石上的每一道裂缝、甲虫爬过后留下的干痕、洞顶垂下的每一条根须，全都历历在目。\n\n你一向擅长在黑暗中视物，只是忘了自己究竟有多擅长。\n\n一个名字卡在你喉咙深处，可你怎么也想不起来。" ,
        
    en: "You wake to the weight of the mountain on your back.\n\nFor sixty years it has leaned into you, slow and patient, the way the earth leans on everything that forgets to move. You draw your first breath, as though an eternity had passed since the last, and your ribs crack like dry kindling, the sound traveling down the length of your spine and out through the tip of your tail. Dust sifts from your nostrils. The stone around you is cold and hard, but beneath your scales something warmer stirs, a slow current that has been waiting just as long as you have.\n\nYou flex the claws of one forepaw. They scrape the cave floor, and the sound is wrong — too high, too thin, as though the claws have kept growing while you slept and now curve too far, too sharp. You open your eyes. The dark answers back at once, vivid and complete: every crack in the rock, every beetle's dried trail, every thread of root pushing through the ceiling. You have always seen well in the dark. You had forgotten how much.\n\nThere is a name somewhere at the back of your throat, but it will not come."
  },
  choices: [
    // 名字输入：引擎渲染为输入框＋「就用这个名字」按钮（text 仅作无障碍标签不显示）。
    // 本页唯一交互，不得混排氛围选项。空输入点按钮＝想不起名字，保持「无名者」；
    // 第一章 e06 老兵问起时还有一次起名机会。
    { text: { zh: "想那个名字。", en: "Reach for the name." },
      input: true, set: { named: true }, next: "p0a" }
  ]
});

// ============================================================
//  p0a · 磨爪（claw 三选一）
// ============================================================
INTRO.push({
  id: "p0a",
  title: { zh: "爪", en: "The Claws" },
  text: [
    { when: { named: true },
      text: { zh: "{name}。\n\n这个名字带着六十年的锈味浮上来，又被你咽了回去。\n\n那刮擦声悬在黑暗里，一下一下地啃着你的神经。\n\n于是你像山对付雨那样对付它：先认下它，再一点一点把它磨掉。\n\n你把前爪按在洞壁上，往下一拖。",
              en: "{name}. The name surfaces with sixty years of rust on it, and you swallow it back down.\n\nThe scraping hangs in the dark, gnawing at your nerves, again and again. So you deal with it the way a mountain deals with rain: you accept it first, then wear it down, a little at a time. You set your forepaw against the cave wall and drag it down." } },
    { text: { zh: "那刮擦声悬在黑暗里，一下一下地啃着你的神经。\n\n于是你像山对付雨那样对付它：先认下它，再一点一点把它磨掉。\n\n你把前爪按在洞壁上，往下一拖。",
              en: "The scraping hangs in the dark, gnawing at your nerves, again and again. So you deal with it the way a mountain deals with rain: you accept it first, then wear it down, a little at a time. You set your forepaw against the cave wall and drag it down." } }
  ],
  choices: [
    { text: { zh: "磨利它们。让山发出山该有的声音。", en: "Grind them sharp. Let the mountain come down sounding like itself." },
      set: { claw: "sharp" }, next: "p0b" },
    { text: { zh: "磨钝它们。磨到像人的指甲。", en: "Grind them down. Human nails." },
      set: { claw: "dull" }, next: "p0b" },
    { text: { zh: "随它们去。", en: "Leave them." },
      set: { claw: "kept" }, next: "p0b" }
  ]
});

// ============================================================
//  p0b · 旧藏（keep 三选一；正文前接磨爪后果段）
// ============================================================
INTRO.push({
  id: "p0b",
  title: { zh: "随身之物", en: "What You Kept" },
  text: [
    { when: { claw: "sharp" },
      text: { zh: "石头发出一声尖利的哀鸣，爪尖被磨了出来，漆黑锃亮，弯如镰月。很好。不管那片灯火通明的山谷里有什么在等着你，它迎面撞上的，都将是一条龙。\n\n" + p0bZhTail,
              en: "The wall shrieks. The tips come away black and gleaming, curved like sickle moons. Good. Whatever waits in that lamplit valley, it will meet a dragon head-on.\n\nYour hoard survived you. It was never much of a hoard—a dragon's worth of nothing: a broken arrow, a half-melted coin, a silver ring small enough to sit inside your nostril. Worthless to anyone but you. But you remember wanting them once, and that is enough.\n\nYou cannot carry a hoard in a human shape. One thing, then, tucked under the loose scale at your shoulder." } },
    { when: { claw: "dull" },
      text: { zh: "把自己磨钝，就像把刀收进鞘里过冬，这违背了你身体里的每一分本能。可人类是不会徒手切开石头的，而你眼看就要走进他们中间去了。\n\n" + p0bZhTail,
              en: "It goes against every instinct you own, blunting yourself like a knife put away for the winter. But humans do not cut stone with their hands, and you are about to walk among them.\n\nYour hoard survived you. It was never much of a hoard—a dragon's worth of nothing: a broken arrow, a half-melted coin, a silver ring small enough to sit inside your nostril. Worthless to anyone but you. But you remember wanting them once, and that is enough.\n\nYou cannot carry a hoard in a human shape. One thing, then, tucked under the loose scale at your shoulder." } },
    { when: { claw: "kept" },
      text: { zh: "又长又弯，不成体统。\n\n那就让它们留着吧，不管你从前是什么，你从来都不是规规矩矩的那一类。\n\n" + p0bZhTail,
              en: "Long, curved, wrong. Let them stay. Whatever you were, you " +
                  "were not tidy.\n\n" + p0bEnTail } },
    { text: { zh: p0bZhTail, en: p0bEnTail } }
  ],
  choices: [
    { text: { zh: "那支断箭。", en: "The broken arrow." },
      set: { keep: "arrow" }, next: "p1" },
    { text: { zh: "那枚银戒。", en: "The silver ring." },
      set: { keep: "ring" }, next: "p1" },
    { text: { zh: "那枚半熔的硬币。", en: "The half-melted coin." },
      set: { keep: "coin" }, next: "p1" }
  ]
});

// ============================================================
//  p1 · 出洞（正文前接旧藏后果段）
// ============================================================
INTRO.push({
  id: "p1",
  title: { zh: "走出洞去", en: "Out of the Cave" },
  text: [
    { when: { keep: "arrow" },
      text: { zh: "它曾经烧伤过你一次，至于是什么时候把它拔出来的，你已经记不清了。\n\n断箭躺在你肩头的鳞片下，抵着你，像一句没说完的话。\n\n" + p1ZhTail,
              en: "It burned, once. You do not remember when you pulled it out. The broken arrow rides under your shoulder scale, pressing, like a sentence no one finished.\n\nYou rise. The cave shrinks around you — or perhaps you have grown and filled it, the way a tree bursts a pot that was always too small. You lower your head and shoulder through the mouth of the den, rocks grating against your scales, and the cold night air hits you like a wall.\n\nThe valley has changed.\n\nYou knew it would. Sixty years is a long time for anything that does not sleep, and the people below lived through all of them one day at a time. Below you, where there was once only a handful of thatched roofs and a single rutted road, a village spreads out in the lamplight — walls and roofs and a church steeple you do not recognize. Smoke rises from a dozen chimneys. Somewhere a dog barks, then another. The wind carries woodsmoke and baking bread and the faint, sweet rot of fallen apples.\n\nBut your eyes are not on the village. They are on the square at its center, where a statue stands, taller than a man, its cape thrown back over one shoulder and a long sword raised high. Torches ring it. Even from this distance, the firelight picks the face out clearly.\n\nYou know that face." } },
    { when: { keep: "ring" },
      text: { zh: "你记得它是从一只烫伤的小手里滑落的，也记得当时有人在哭，只是已经分不清是谁了。\n\n银戒躺在你的鳞片下，凉得像夜风。\n\n" + p1ZhTail,
              en: "You remember it sliding off a small scalded hand, and someone crying, and not being able to say whose. The ring rides under your scale, cold as the night wind.\n\nYou rise. The cave shrinks around you — or perhaps you have grown and filled it, the way a tree bursts a pot that was always too small. You lower your head and shoulder through the mouth of the den, rocks grating against your scales, and the cold night air hits you like a wall.\n\nThe valley has changed.\n\nYou knew it would. Sixty years is a long time for anything that does not sleep, and the people below lived through all of them one day at a time. Below you, where there was once only a handful of thatched roofs and a single rutted road, a village spreads out in the lamplight — walls and roofs and a church steeple you do not recognize. Smoke rises from a dozen chimneys. Somewhere a dog barks, then another. The wind carries woodsmoke and baking bread and the faint, sweet rot of fallen apples.\n\nBut your eyes are not on the village. They are on the square at its center, where a statue stands, taller than a man, its cape thrown back over one shoulder and a long sword raised high. Torches ring it. Even from this distance, the firelight picks the face out clearly.\n\nYou know that face." } },
    { when: { keep: "coin" },
      text: { zh: "你还记得金属熔化的气味。至少这一件事，确确实实是你干的。\n\n硬币躺在你的鳞片下，仍留着一丝旧火的余温。\n\n" + p1ZhTail,
              en: "You remember the smell of it melting. That, at least, was your own work. The coin rides under your scale, still faintly warm with the memory of old fire.\n\nYou rise. The cave shrinks around you — or perhaps you have grown and filled it, the way a tree bursts a pot that was always too small. You lower your head and shoulder through the mouth of the den, rocks grating against your scales, and the cold night air hits you like a wall.\n\nThe valley has changed.\n\nYou knew it would. Sixty years is a long time for anything that does not sleep, and the people below lived through all of them one day at a time. Below you, where there was once only a handful of thatched roofs and a single rutted road, a village spreads out in the lamplight — walls and roofs and a church steeple you do not recognize. Smoke rises from a dozen chimneys. Somewhere a dog barks, then another. The wind carries woodsmoke and baking bread and the faint, sweet rot of fallen apples.\n\nBut your eyes are not on the village. They are on the square at its center, where a statue stands, taller than a man, its cape thrown back over one shoulder and a long sword raised high. Torches ring it. Even from this distance, the firelight picks the face out clearly.\n\nYou know that face." } },
    { text: { zh: p1ZhTail, en: "You rise. The cave shrinks around you — or perhaps you have grown and filled it, the way a tree bursts a pot that was always too small. You lower your head and shoulder through the mouth of the den, rocks grating against your scales, and the cold night air hits you like a wall.\n\nThe valley has changed.\n\nYou knew it would. Sixty years is a long time for anything that does not sleep, and the people below lived through all of them one day at a time. Below you, where there was once only a handful of thatched roofs and a single rutted road, a village spreads out in the lamplight — walls and roofs and a church steeple you do not recognize. Smoke rises from a dozen chimneys. Somewhere a dog barks, then another. The wind carries woodsmoke and baking bread and the faint, sweet rot of fallen apples.\n\nBut your eyes are not on the village. They are on the square at its center, where a statue stands, taller than a man, its cape thrown back over one shoulder and a long sword raised high. Torches ring it. Even from this distance, the firelight picks the face out clearly.\n\nYou know that face." } }
  ],
  choices: [
    { text: { zh: "你俯瞰灯火中的村庄。", en: "You look down at the lamplit village." },
      set: { p1Sense: "lights" }, next: "p2" },
    { text: { zh: "你最先注意到的，是那张脸。", en: "The face is what you look at first." },
      set: { p1Sense: "face" }, next: "p2" },
    { text: { zh: "你尝了尝风。烟，面包，湿石头——这片山谷换了一种口音。", en: "You taste the wind. Smoke, bread, wet stone — the valley has changed its accent." },
      set: { p1Sense: "wind" }, next: "p2" }
  ]
});

// ============================================================
//  p2 · 你读不出的脸
// ============================================================
INTRO.push({
  id: "p2",
  title: { zh: "认不出的脸", en: "The Face You Cannot Read" },
  // 凑数工单认领：p1 三选（灯／脸／风）的落点认领，前插；原文整体保留为兜底条目。英文留待翻译阶段
  // stack 条目不写段尾 \n\n：引擎 join("\n\n") 自带分段，写了会产生双空行
  text: [ { stack: [
    { when: { p1Sense: "lights" }, text: { zh: "你在那儿站了很久，十几扇亮着的窗一扇一扇看过去，渐渐认出了哪家的灯熄得最早，哪家的灯总要亮到后半夜。", en: "You stand there a long while, taking the lit windows one by one — a dozen of them — until you begin to recognize which household puts its lamp out first and which one burns until the small hours." } },
    { when: { p1Sense: "face" }, text: { zh: "可你第一眼看见的并不是村子，而是那张脸。石头刻不出眼睛里的东西，好在，石匠本来也没打算刻。", en: "But the first thing you see is not the village. It is that face. Stone cannot carve what lives in the eyes; thankfully, the mason never meant to." } },
    { when: { p1Sense: "wind" }, text: { zh: "你把风里的味道一层一层分开来尝：烟是新的，面包刚出炉，而压在最底下的，是一整片看不见的麦子地。", en: "You tease the smells on the wind apart and taste them one layer at a time: smoke, fresh; bread just out of the oven; and under it all, pressing at the bottom, a whole unseen field of wheat." } },
    { text: {
    zh: "灯火、石像、风里的味道，你一样一样收进眼底，最后，目光又落回那张脸上。\n\n可当你试图回想其中的缘由时，那眉骨的线条、嘴唇和下颌的轮廓，却都像河水一样，从你的爪间悄然溜走了。\n\n你看得更仔细了些，可雕像什么也不肯给你。\n\n广场四周的火把在风里摇曳，那张石脸越过你望向远处，耐心得就像这座山本身。\n\n它像是一张陌生人的脸，却又不完全是：它的轮廓里有某种属于你的东西，就像静水里的倒影属于你一样；可具体的细节早已被时间磨平，如同一块被雨水冲刷了六十年的碑文。睡着是一回事，记得又是另一回事。\n\n你下意识地抠着岩石的边缘。\n\n你上一次披上人形，是多久以前的事了？\n\n你记得那场火，记得一双小小的、温热的手，记得奔跑，也记得烟的气味，却唯独不记得，当时自己戴的是哪一张脸。\n\n至少，这一点还补救得了。",
    en: "Lamplight, stone, the smell on the wind — you gather each one in, and at last your gaze comes back to that face.\n\nAnd yet, when you reach for the why of it—for the brow, the mouth, the line of the jaw—the memory slides through your claws like river water.\n\nYou look harder, and the statue gives you nothing. Torches gutter in the wind around the square. The stone face stares past you, patient as the mountain itself, and it is a stranger's face, and it is not. Something in the set of it is yours, the way your reflection in still water is yours, but the details have worn smooth inside you, like a carving left out in sixty years of rain. Sleeping is one thing. Remembering is another.\n\nYour claws score the ledge without meaning to. The last time you wore a human shape—when was that? You remember fire. You remember small warm hands, and running, and the taste of smoke. You do not remember the face you were wearing when you did it.\n\nThat, at least, you can fix."
  } } ] } ],
  choices: [
    { text: { zh: "你闭上眼，摸进自己的黑暗里。", en: "You close your eyes and feel your way down into your own dark." },
      next: "p3" }
  ]
});

// ============================================================
//  p3 · 披上人皮（face 三选一）
// ============================================================
INTRO.push({
  id: "p3",
  title: { zh: "你曾穿过的形状", en: "What You Wore" },
  text: {
    zh: "记忆回来了，就像水流回干涸的河床，起先很慢，随后骤然漫溢，重新灌满了一具你六十年没用过的人类身体：皮肤代替了鳞片，两条腿撑起了全部的体重，还有人类脊椎那套奇怪、可爱又可怕的算术。\n\n最后，是那张脸。\n\n你披着那层皮的时候，究竟长什么样子？",
    en: "Memory comes back the way water returns to a dry bed: slowly, then all at once, filling the shape of a human body you have not needed for sixty years. Skin instead of scale. Two legs taking all your weight. That strange, lovely, terrible arithmetic of a human spine.\n\nThe face arrives last. What do you look like, wearing that skin?"
  },
  choices: [
    { text: { zh: "一张眉上带疤的脸——年纪更大，更难看透。", en: "A face with a scar through one brow — older, harder to read." },
      set: { face: "scar" }, next: "p3b" },
    { text: { zh: "一张苍白清瘦的脸——像是整日埋在书堆里的那种。", en: "A thin, pale face — the kind that spends its days buried in books." },
      set: { face: "scholar" }, next: "p3b" },
    { text: { zh: "一张宽阔、饱经风霜的脸——猎人的脸。", en: "A broad, weather-beaten face — a hunter's face." },
      set: { face: "hunter" }, next: "p3b" }
  ]
});

// ============================================================
//  p3b · 那具身体（face 后果段 + gender 三选一）
// ============================================================
INTRO.push({
  id: "p3b",
  title: { zh: "你曾住过的身体", en: "The Body You Wore" },
  text: [
    { when: { face: "scar" },
      text: { zh: "眉骨上有一道旧疤，把眉毛截成了两段，就像一条被落石拦腰截断的路。\n\n这是一张会让村民垂下眼睛的脸，有人是出于敬畏，有人是出于害怕，而你发现，这两者你都不介意。\n\n那么，你当时穿的是怎样一具身体？",
              en: "An old scar splits the brow in two, like a road cut off by a rockfall. Faces like this make villagers lower their eyes, some in respect, some in fear. You find you don't mind either.\n\nAnd the body you wore?" } },
    { when: { face: "scholar" },
      text: { zh: "人们总是很快就会信任这张脸，你始终没想明白这是为什么。\n\n它像是一张属于书斋的脸，或者说，是一张最适合在书斋里撒谎的脸。\n\n那么，你当时穿的是怎样一具身体？",
              en: "People trust it quickly, and you never knew why. It is a face " +
                  "made for libraries, or for lying in one.\n\n" +
                  "And the body you wore?" } },
    { when: { face: "hunter" },
      text: { zh: "这是那种还没人问你打哪儿来，就先被端上一碗炖菜的脸。\n\n你已经知道该怎么用这具身体站立了：重心前倾，肩膀放松。\n\n那么，你当时穿的是怎样一具身体？",
              en: "The kind that gets offered stew before it gets asked " +
                  "questions. You already know how to stand in it: weight " +
                  "forward, shoulders loose.\n\n" +
                  "And the body you wore?" } },
    { text: { zh: "那么，你当时穿的是怎样一具身体？", en: "And the body you wore?" } }
  ],
  choices: [
    { text: { zh: "男人的。", en: "A man's." },
      set: { gender: "male" }, next: "p3c" },
    { text: { zh: "女人的。", en: "A woman's." },
      set: { gender: "female" }, next: "p3c" },
    { text: { zh: "你从来没费心去确认过。", en: "You never once bothered to check." },
      set: { gender: "unspoken" }, next: "p3c" }
  ]
});

// ============================================================
//  p3c · 你的声音（voice 二选一）
// ============================================================
INTRO.push({
  id: "p3c",
  title: { zh: "你的声音", en: "Your Voice" },
  text: {
    zh: "记忆又往下沉了一些，沉到了肩膀、双手和喉咙。\n\n还有声音。\n\n你当时，是怎么说话的？",
    en: "The memory sinks a little further. Shoulders. Hands. Throat.\n\nAnd the voice.\n\nHow did you speak, back then?"
  },
  choices: [
    { text: { zh: "你把它压得很低，柔和，像人。", en: "You kept it low, human-soft." },
      set: { voice: "low" }, next: "p3d" },
    { text: { zh: "你从不掩饰它。", en: "You never disguised it." },
      set: { voice: "true" }, next: "p3d" },
    { text: { zh: "你借了一副嗓子，在河边一遍遍地练，直到连河水都信了。", en: "You borrowed a voice once, practiced it at the river over and over, until the river itself believed it." },
      set: { voice: "low" }, next: "p3d" }
  ]
});

// ============================================================
//  p3d · 一个习惯（voice 后果段 + habit 三选一）
// ============================================================
INTRO.push({
  id: "p3d",
  title: { zh: "一个习惯", en: "One Habit" },
  text: [
    { when: { voice: "low" },
      text: { zh: "你把嗓子压得又低又平，像踩实了的雪。\n\n它从来没有出过岔子，却也一直在向你收取代价。\n\n而即便披着人皮，你也始终改不掉一个习惯：",
              en: "You kept it low and flat, like packed snow. It never once cracked. It always charged you for it.\n\nAnd one habit you could not shake, even in skin:" } },
    { when: { voice: "true" },
      text: { zh: "那声音始终是你自己的，太低沉，元音也拖得太长，就像远方滚滚而来的天气。\n\n你说“你好”的时候，人类听见的总是雷声。\n\n而即便披着人皮，你也始终改不掉一个习惯：",
              en: "The voice was always yours: too deep, too long in the " +
                  "vowels, a sound like distant weather. Humans heard thunder " +
                  "when you said hello.\n\n" +
                  "And one habit you could not shake, even in skin:" } },
    { text: { zh: "而即便披着人皮，你也始终改不掉一个习惯：",
              en: "And one habit you could not shake, even in skin:" } }
  ],
  choices: [
    { text: { zh: "开口之前，你总要先把一切气味闻个遍。", en: "You smelled everything first and spoke second." },
      set: { habit: "sniff" }, next: "p3e" },
    { text: { zh: "你的手指从不安分，总得搓着点什么、拨弄着点什么。", en: "Your fingers were never still — they worried at things." },
      set: { habit: "finger" }, next: "p3e" },
    { text: { zh: "你和任何活物之间，总要隔开三步。", en: "You kept three steps of distance between yourself and everyone alive." },
      set: { habit: "distance" }, next: "p3e" }
  ]
});

// ============================================================
//  p3e · 试穿
// ============================================================
INTRO.push({
  id: "p3e",
  title: { zh: "试穿", en: "Trying It On" },
  text: {
    zh: "那张脸在你面前一寸一寸地拼合起来，五官一处一处落回了原位。\n\n最奇怪的是，它依然严丝合缝，就像一件压在箱底多年的旧外套，拿出来一试，竟然还很合身。\n\n你在黑暗里把它穿上了片刻，只是试一试。\n\n很好。现在你终于记起自己长什么样了。",
    en: "The face assembles itself in front of you, inch by inch, feature after feature settling back into place. The strangest thing is how well it still fits — like an old coat kept for years at the bottom of a trunk, taken out and tried on, and somehow it still fits. You wear it a moment in the dark, just to try.\n\nThere. Now you remember what you look like."
  },
  choices: [
    { text: { zh: "你睁开眼。", en: "You open your eyes." },
      next: "p4" }
  ]
});

// ============================================================
//  p4 · 属于你的（★核心反转）
// ============================================================
INTRO.push({
  id: "p4",
  title: { zh: "你的脸", en: "Yours" },
  text: {
    zh: "你睁开眼睛。山谷还在，广场还在，火把也还燃着，雕像依旧立在原处，石头披风甩在身后，长剑举向夜空。\n\n只是现在，你读得懂那张脸了，它的每一处你都认得。\n\n那道眉骨是你亲自选的；那张嘴、那副下颌和那道颧骨的线条，你刚刚才在黑暗里一一试穿过。\n\n陌生人的每一道轮廓，如今都属于你，清晰得就像一个签名。\n\n那座雕像长着你的脸。不只是像你。那就是你。\n\n六十年过去了，山下那个村子竟把你刻进了石头，却给它安上了另一个名字。\n\n就在这时，山下酒馆的门忽然被推开了，灯光和半截歌声一起泼洒在鹅卵石上。\n\n风里飘来了一个“龙”字，还有笑声和铃铛的叮当声，以及一个村子顶着你的脸、把同一个故事讲了六十年的声音。\n\n你得把那个故事听清楚。",
    en: "You open your eyes, and the valley is still there, and the square, and the torches. The statue waits where it stood, stone cape thrown back, sword raised against the dark.\n\nOnly now you can read the face. All of it. You know the brow—you chose it. You know the mouth, the jaw, the line of the cheek, because you have just tried each of them on in the dark. Every stranger's line is yours now, sharp as a signature.\n\nThe statue has your face. Not like your face. Your face.\n\nSixty years, and the village below carved you into stone and gave it another name.\n\nJust then the inn door swings open below, spilling lamplight and a scrap of song onto the cobbles. You catch the word \"dragon\" on the wind — and laughter, and bells, and a village that has spent sixty years telling itself a story with your face in it.\n\nYou have to hear that story clearly."
  },
  choices: [
    { text: { zh: "你开始朝那片灯火走下山去。", en: "You start down toward the lamplight." },
      set: { p4Move: "walk" }, next: "e01" },
    { text: { zh: "你决定先仔细听听那首歌。", en: "You mean to hear that song clearly first." },
      set: { p4Move: "song" }, next: "e01" },
    { text: { zh: "你朝那张脸缓缓眨了眨眼。这是龙的方式。", en: "You blink at the face, once, slow. The dragon's way." },
      set: { p4Move: "wink" }, next: "e01" }
  ]
});
