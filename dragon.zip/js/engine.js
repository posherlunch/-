// ============================================================
//  engine.js —— 游戏引擎
//  只读取 story/ 文件夹里的数据并渲染页面。
//  写剧情不需要改这个文件。
//
//  引擎只做七件事：
//    1. 事件与选项
//    2. 标志位
//    3. 标志位驱动的正文变体
//    4. 人物面板
//    5. 中英双语切换
//    6. 自动存档与「继续上次冒险」
//    7. 成就判定与弹窗（成就数据在 story/00-config.js）
//  没有数值、没有掷骰、没有战斗。
//
//  文本约定：所有给玩家看的文字都写成 { en: "…", zh: "…" } 两份，
//  由引擎按当前语言取值；缺了哪一边，自检会在控制台点名。
// ============================================================

const $ = (s) => document.querySelector(s);

let state;
let pageCount = 0;
let currentEvent = null;    // 当前事件（切语言时原地重渲染）
let currentEnding = null;   // 当前结局（同上）
let currentPanel = null;    // 当前打开的面板（同上）
let galleryDetail = null;   // 图鉴详情视图当前显示的结局 id（null＝卡片网格）

// ---------- 安全读写 localStorage ----------
// ⚠ 上线到 itch.io 时，游戏跑在第三方 iframe（html-classic.itch.zone）里；
//   浏览器一旦禁用第三方存储，直接碰 localStorage 会抛 SecurityError，
//   整个脚本当场中断 → 玩家看到全白页面。这里统一包一层，读不到就用内存兜底。
const store = (() => {
  try {
    const k = "__tlyao_probe__";
    localStorage.setItem(k, "1");
    localStorage.removeItem(k);
    return localStorage;
  } catch (e) {
    const mem = {};
    return {
      getItem: (k) => (k in mem ? mem[k] : null),
      setItem: (k, v) => { mem[k] = String(v); },
      removeItem: (k) => { delete mem[k]; }
    };
  }
})();

function loadEndings() {
  try {
    const raw = store.getItem("tlyao_endings");
    const arr = JSON.parse(raw || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}

// ---------- 自动存档 ----------
// 每翻一页静默存一份：标志位 + 当前事件 + 页数。
// 标题屏的「继续上次冒险」读的就是它；走到结局后清掉。
const SAVE_KEY = "tlyao_save";

function saveGame() {
  if (!state || !currentEvent) return;
  try {
    store.setItem(SAVE_KEY, JSON.stringify({ v: 1, page: pageCount, ev: currentEvent.id, state: state }));
  } catch (e) { /* 存不下只影响「继续」，游戏照常 */ }
}

function loadSave() {
  try {
    const s = JSON.parse(store.getItem(SAVE_KEY) || "null");
    if (!s || s.v !== 1 || !s.state || !findEvent(s.ev)) return null;
    return s;
  } catch (e) { return null; }
}

function clearSave() { store.removeItem(SAVE_KEY); }

// 有存档时才露出「继续上次冒险」按钮（翻开第一页/结局图鉴恒显，仍居中）
function refreshContinue() {
  const btn = $("#btn-continue");
  if (btn) btn.hidden = !loadSave();
}

// ---------- 成就 ----------
// 数据（id / 名称 / 描述 / 达成条件）在 story/00-config.js 的 ACHIEVEMENTS。
// 这里只负责判定、记录、弹提示。
const ACH_KEY = "tlyao_achievements";

function loadAch() {
  try {
    const arr = JSON.parse(store.getItem(ACH_KEY) || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}

function saveAch(list) {
  try { store.setItem(ACH_KEY, JSON.stringify(list)); } catch (e) { /* 同上 */ }
}

// endingId：只有走到结局时才传，用来匹配 achievement.ending
function checkAchievements(endingId) {
  if (!state) return;
  const got = loadAch();
  let dirty = false;
  ACHIEVEMENTS.forEach(a => {
    if (got.includes(a.id)) return;
    const byFlag = a.when ? matchWhen(a.when) : false;
    const byEnding = a.ending && endingId && (a.ending === endingId || a.ending === "*");
    if (!byFlag && !byEnding) return;
    got.push(a.id);
    dirty = true;
    showToast(a);
  });
  if (dirty) saveAch(got);
}

// 成就提示：从页底浮出，几秒后自己淡走
function showToast(ach) {
  const wrap = $("#toast-wrap");
  if (!wrap) return;
  const t = document.createElement("div");
  t.className = "toast";
  const k = document.createElement("div");
  k.className = "toast-kicker";
  k.textContent = L(STR.achUnlocked);
  const n = document.createElement("div");
  n.className = "toast-title";
  n.textContent = (ach.icon ? ach.icon + " " : "") + L(ach.title);
  const d = document.createElement("div");
  d.className = "toast-desc";
  d.textContent = L(ach.desc);
  t.append(k, n, d);
  wrap.appendChild(t);
  setTimeout(() => {
    t.classList.add("out");
    setTimeout(() => t.remove(), 340);
  }, 3600);
}

// ---------- 偏好设置：字号 / 行距 / 动效（存本地，下次打开照旧） ----------
const FONT_KEY = "tlyao_fontsize";
const LH_KEY = "tlyao_lineheight";
const MOTION_KEY = "tlyao_motion";
let fontSize = store.getItem(FONT_KEY) || "m";      // s / m / l
let lineH = store.getItem(LH_KEY) || "m";           // s / m / l
let motion = store.getItem(MOTION_KEY) || "full";   // full / reduced

function applyPrefs() {
  document.documentElement.setAttribute("data-fs", fontSize);
  document.documentElement.setAttribute("data-lh", lineH);
  document.documentElement.classList.toggle("reduce-motion", motion === "reduced");
}
function setFontSize(v) { fontSize = v; store.setItem(FONT_KEY, v); applyPrefs(); }
function setLineH(v) { lineH = v; store.setItem(LH_KEY, v); applyPrefs(); }
function setMotion(v) { motion = v; store.setItem(MOTION_KEY, v); applyPrefs(); }

// ---------- BGM（冲刺工单 C） ----------
// C.2 用户第一次点击页面才开始播（浏览器自动播放策略也要求手势），2 秒淡入；
// C.3 开关（默认开）与音量（默认 50%）存本地；C.5 先用 <audio loop>；
// C.6 文件缺失或播放失败一律静默跳过，不报错不卡游戏。
const BGM_KEY = "tlyao_bgm";                   // "on" / "off"，缺省＝开
const VOL_KEY = "tlyao_vol";                   // "0"–"100"，缺省＝50
let bgmOn = store.getItem(BGM_KEY) !== "off";
let bgmVol = Number(store.getItem(VOL_KEY) ?? "50") || 0;
if (bgmVol < 0 || bgmVol > 100) bgmVol = 50;
let bgm = null;             // 懒创建：首次需要时才 new Audio
let bgmStarted = false;     // 是否已到过首次点击
let bgmFade = 0;            // 淡入计时器

function ensureBgm() {
  if (bgm) return bgm;
  try {
    bgm = new Audio("assets/audio/bgm.m4a");
    bgm.loop = true;
    bgm.preload = "auto";                       // 封面期就整段下载（加载优化工单 2026-10-21）
    bgm.load();
  } catch (e) { bgm = null; }
  return bgm;
}

// 缓冲已够（readyState≥3）→ 立即播＋淡入；不够 → 等 canplay 再播，
// 不报错不爆音：音量先压 0，canplay 后才起声（加载优化工单 2026-10-21）
function playBgm(fade, a, target) {
  const start = () => {
    a.play().then(() => {
      if (!fade) { a.volume = target; return; }
      const t0 = performance.now();
      a.volume = 0;
      bgmFade = setInterval(() => {             // 2 秒线性淡入到目标音量
        const k = Math.min(1, (performance.now() - t0) / 2000);
        a.volume = target * k;
        if (k >= 1) clearInterval(bgmFade);
      }, 50);
    }).catch(() => {});                         // 手势不足/缺文件/解码失败：静默
  };
  if (a.readyState >= 3) { start(); return; }
  a.addEventListener("canplay", function once() {
    a.removeEventListener("canplay", once);
    start();
  });
}

function applyBgm(fade) {
  const a = ensureBgm();
  if (!a) return;
  const target = bgmOn ? bgmVol / 100 : 0;
  clearInterval(bgmFade);
  if (!bgmOn) { a.pause(); return; }
  playBgm(fade, a, target);
}

function setBgm(v) { bgmOn = v; store.setItem(BGM_KEY, v ? "on" : "off"); applyBgm(false); }
function setBgmVol(v) {
  bgmVol = v; store.setItem(VOL_KEY, String(v));
  if (bgmOn) applyBgm(false);                   // 滑块拖动即时生效（打断淡入直接到位）
}

document.addEventListener("pointerdown", () => {
  if (bgmStarted) return;
  bgmStarted = true;
  applyBgm(true);
}, { once: true });

// C.4 切标签页/最小化自动暂停，切回来接着播
document.addEventListener("visibilitychange", () => {
  if (!bgm) return;
  if (document.hidden) { clearInterval(bgmFade); bgm.pause(); }
  else if (bgmOn && bgmStarted) applyBgm(false);
});

// 测试探针（v8load 用）：暴露 BGM 缓冲/播放状态，只读，不影响任何行为
if (typeof window !== "undefined") {
  window.__bgmState = () => (bgm ? { rs: bgm.readyState, t: bgm.currentTime, paused: bgm.paused } : null);
}

// ---------- 已读跟踪：翻过的页记下 id，旧页重开不再播入场动画（f1 已读快进） ----------
const READ_KEY = "tlyao_read";
function loadRead() {
  try {
    const a = JSON.parse(store.getItem(READ_KEY) || "[]");
    return Array.isArray(a) ? a : [];
  } catch (e) { return []; }
}
function markRead(evId) {
  if (!evId) return;
  const list = loadRead();
  if (!list.includes(evId)) {
    list.push(evId);
    try { store.setItem(READ_KEY, JSON.stringify(list)); } catch (e) { /* 存不下只影响动画 */ }
  }
}

// ---------- 语言 ----------
const LANG_KEY = "tlyao_lang";
// 首次打开跟随浏览器：中文环境用中文，其余都先给英文
let lang = store.getItem(LANG_KEY) ||
  ((navigator.language || "en").toLowerCase().startsWith("zh") ? "zh" : "en");

// 取当前语言的文字：支持 { en, zh } 与单语字符串
function L(t) {
  if (t == null) return "";
  if (typeof t === "string") return t;
  return t[lang] || t.zh || t.en || "";
}

// 界面固定文案（剧情文案不在这里，在 story/ 里）
const STR = {
  docTitle:      { zh: "屠龙谣 · 纯文字互动小说", en: "The Ballad Got It Wrong · Interactive Fiction" },
  nameless:      { zh: "无名者",           en: "Nameless" },
  useName:       { zh: "就用这个名字",      en: "That's the name" },
  scarEndLabel:  { zh: "疤痕：",           en: "Scars: " },
  scarNewEnd:    { zh: "（及一道新疤）",    en: " (and one fresh)" },
  rememberedLabel: { zh: "记得你的人：",    en: "Remembered by: " },
  noOne:         { zh: "目前没有人记得你。", en: "No one remembers you yet." },
  scarNone:      { zh: "你的身上看不出什么。", en: "Nothing about you stands out." },
  newScarPanel:  { zh: "另外，你脸上多了一道新的疤。", en: "There is also a fresh cut across your face." },
  charEmpty:     { zh: "你还没有想起自己是谁。", en: "You haven't remembered yourself yet." },
  logEmpty:      { zh: "还没有任何记录。",   en: "Nothing recorded yet." },
  locked:        { zh: "？？？",           en: "???" },
  galBack:       { zh: "返回",             en: "Back" },
  abandon:       { zh: "放弃本次冒险",      en: "Abandon this run" },
  achUnlocked:   { zh: "达成成就",          en: "Achievement unlocked" },
  setFont:       { zh: "字号",             en: "Text size" },
  setLh:         { zh: "行距",             en: "Spacing" },
  setMotion:     { zh: "界面动效",          en: "Motion" },
  setBgm:        { zh: "音乐",             en: "Music" },
  setVolume:     { zh: "音量",             en: "Volume" },
  bgm:           { on: { zh: "开", en: "On" }, off: { zh: "关", en: "Off" } },
  motionNote:    { zh: "开启后关闭开合书、翻页与文字淡入动画。",
                   en: "Turns off book open/close, page-turn and text fade-in animations." },
  fontSize:      { s: { zh: "小", en: "S" }, m: { zh: "中", en: "M" }, l: { zh: "大", en: "L" } },
  lh:            { s: { zh: "紧凑", en: "Tight" }, m: { zh: "适中", en: "Cozy" }, l: { zh: "宽松", en: "Airy" } },
  motion:        { full: { zh: "完整", en: "Full" }, reduced: { zh: "减弱", en: "Reduced" } },
  startOver:     { zh: "有一场冒险还没走完。翻开第一页会覆盖它的存档，确定？", en: "A run is unfinished. Opening the first page overwrites its save. Proceed?" },
  panel: {
    character: { zh: "人物", en: "Character" },
    log:       { zh: "日志", en: "Journal" },
    gallery:   { zh: "图鉴", en: "Gallery" },
    settings:  { zh: "设置", en: "Settings" }
  },
  row: {
    name:       { zh: "姓名",     en: "Name" },
    gender:     { zh: "性别",     en: "Gender" },
    origin:     { zh: "出身",     en: "Origin" },
    look:       { zh: "容貌",     en: "Appearance" },
    scar:       { zh: "疤痕",     en: "Scars" },
    remembered: { zh: "记得你的人", en: "Remembered by" }
  }
};

function displayName() {
  return state && state.name ? state.name : L(STR.nameless);
}

function pageLabel(n) {
  return lang === "zh" ? "第 " + n + " 页" : "Page " + n;
}

// ---------- 屏幕切换 ----------
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(el => el.classList.remove("active"));
  $(id).classList.add("active");
}

// ---------- 标志位：条件匹配 ----------
// when 里可以写 { scar: "face" }、{ origin: ["kin","guild"] }、{ knowFog: true }
function matchWhen(when) {
  if (!when) return true;
  // state 为 null（从扉页打开图鉴）时条件一律不命中，正文落到兜底变体
  if (!state) return false;
  return Object.entries(when).every(([k, v]) =>
    Array.isArray(v) ? v.includes(state[k]) : state[k] === v
  );
}

// ---------- 正文：字符串 / {en,zh} / 条件变体数组 / stack 叠加段 ----------
// stack 形状（余响页/结局页「多命中全显示」用，与 first-match 互补）：
//   { when?, stack: [ {when?, text}... ], fallback: {text} }
//   外层 when 命中后：stack 内所有 when 命中的条目按序以空行拼接（一条都不中取 fallback）。
//   stack 条目的 text 可继续是字符串/{en,zh}/数组（递归）。
function pickText(t) {
  if (t == null) return "";
  if (!Array.isArray(t)) return L(t);
  const hit = t.find(v => matchWhen(v.when));
  if (!hit) return "";
  if (hit.stack) {
    const parts = hit.stack.filter(v => matchWhen(v.when)).map(v => pickText(v.text));
    const joined = parts.filter(Boolean).join("\n\n");
    return joined || (hit.fallback ? pickText(hit.fallback.text) : "");
  }
  return pickText(hit.text);
}

// ---------- RO 代词 token 系统（照 Fox Spirit 完整变位组） ----------
// 三个浪漫候选（A 守祠人 / B 歌手 / C 那条龙）的性别在相遇页由玩家选定：
//   male / female / nonbinary（存 roA_sex / roB_sex / roC_sex）。
// 正文里用 {aHe}{aHis}{bWas}{cVs}… 占位，渲染时按性别查表替换；
// 家族称谓 {aGrand}{aGreat}{bGrand} 随 RO 性别翻转（祖父/外祖母/祖上…）。
// 中文 nonbinary 态不用"他/她"，用头衔指代（守祠人/歌手/那条龙）；
// 英文 nonbinary 态用 they/them/their + 复数动词（are/were/去 s）。
// ⚠ 相遇页之前性别未设定：token 原样保留，V8 自检靠残留报错定位误用。
const RO_INFO = {
  a: { sexVar: "roA_sex", zhTitle: "守祠人" },
  b: { sexVar: "roB_sex", zhTitle: "歌手" },
  c: { sexVar: "roC_sex", zhTitle: "那条龙" }
};

// 完整变位组：主格 / 宾格 / 所有格 / 反身 / is / was / 动词 s 后缀
// zh 为 null 的是英文专用 token——出现在中文里会原样残留，自检可定位
const PRONOUN_SETS = {
  male: {
    He:   { zh: "他",     en: "he" },
    Him:  { zh: "他",     en: "him" },
    His:  { zh: "他的",   en: "his" },
    Self: { zh: "他自己", en: "himself" },
    Is:   { zh: null,     en: "is" },
    Was:  { zh: null,     en: "was" },
    Vs:   { zh: null,     en: "s" }
  },
  female: {
    He:   { zh: "她",     en: "she" },
    Him:  { zh: "她",     en: "her" },
    His:  { zh: "她的",   en: "her" },
    Self: { zh: "她自己", en: "herself" },
    Is:   { zh: null,     en: "is" },
    Was:  { zh: null,     en: "was" },
    Vs:   { zh: null,     en: "s" }
  },
  nonbinary: {
    He:   { zh: "TITLE",  en: "they" },
    Him:  { zh: "TITLE",  en: "them" },
    His:  { zh: "TITLE的", en: "their" },
    Self: { zh: "TITLE自己", en: "themself" },
    Is:   { zh: null,     en: "are" },
    Was:  { zh: null,     en: "were" },
    Vs:   { zh: null,     en: "" }
  }
};

// 家族称谓：A 守祠人家族线（建纪念堂的祖辈 / 信里的曾祖辈）、B 歌手页边小字线
const KIN_TOKENS = {
  aGrand: {
    male:      { zh: "祖父",     en: "grandfather" },
    female:    { zh: "外祖母",   en: "grandmother" },
    nonbinary: { zh: "祖上",     en: "grandparent" }
  },
  aGreat: {
    male:      { zh: "曾祖父",   en: "great-grandfather" },
    female:    { zh: "曾外祖母", en: "great-grandmother" },
    nonbinary: { zh: "曾祖",     en: "great-grandparent" }
  },
  bGrand: {
    male:      { zh: "爷爷",     en: "grandfather" },
    female:    { zh: "外婆",     en: "grandmother" },
    nonbinary: { zh: "祖辈",     en: "grandparent" }
  }
};

// 全量 token 清单：checkStory 静态校验用（{name} + 代词 + 称谓）
const KNOWN_TOKENS = new Set(["name"]);
Object.keys(RO_INFO).forEach(r =>
  Object.keys(PRONOUN_SETS.male).forEach(k => KNOWN_TOKENS.add(r + k)));
Object.keys(KIN_TOKENS).forEach(k => KNOWN_TOKENS.add(k));

// 中文 nonbinary 态的头衔指代：{aHe}→守祠人，{aHis}→守祠人的，{aSelf}→守祠人自己
function titleForm(title, key) {
  if (key === "Self") return title + "自己";
  return title + (key === "His" ? "的" : "");
}

// 正文里的 {name} 换成玩家名字；{aHe} 一类 RO token 按当前性别查表替换。
// 句首判断（仅英文模式用）：token 前为 字符串开头 / .!?… 加空格 / 换行（含 \n\n）/
// 左引号（含「句末标点＋空格＋左引号」）时算句首。破折号、逗号、闭引号（said-tag）不算。
// 直引号 " 既可开可闭：前一字符紧贴标点或字母＝闭引号；隔空格回望是句首＝开引号。
function atSentenceStart(text, offset) {
  let i = offset;
  while (i > 0 && text[i - 1] === " ") i--;
  if (i === 0) return true;                        // 字符串开头
  const c = text[i - 1];
  if (c === "\n") return true;                     // 换行后（含段落 \n\n）
  if (".!?…".includes(c)) return true;             // 句末标点＋空格
  if (c === '"' || c === "“") {
    if (i < 2) return true;                        // 文本以引号开头
    const d = text[i - 2];
    if (d === "\n") return true;                   // 换行＋左引号
    if (d === " ") {                               // 空格＋左引号：回望空格前
      let j = i - 1;
      while (j > 0 && text[j - 1] === " ") j--;
      return j === 0 || ".!?…".includes(text[j - 1]);
    }
    return false;                                  // 标点/字母紧贴引号＝闭引号
  }
  return false;                                    // 破折号 —、逗号等：不大写
}

// 用函数做替换：名字里就算带 $& 之类的字符，也不会被 replace 当成特殊指令。
function fillTokens(text) {
  return String(text).replace(/\{([a-zA-Z]+)\}/g, (whole, key, offset) => {
    if (key === "name") return displayName();
    const ro = RO_INFO[key[0]];
    if (!ro) return whole;                       // 不是 RO token：原样保留
    const sex = state ? state[ro.sexVar] : "";
    if (!sex) return whole;                      // 性别未设定：保留残留，自检定位
    const form = key.slice(1);
    const pron = PRONOUN_SETS[sex] && PRONOUN_SETS[sex][form];
    if (pron) {
      if (lang === "zh") {
        if (pron.zh === null) return whole;      // 英文专用 token 落进中文：残留报错
        if (pron.zh.startsWith("TITLE")) return titleForm(ro.zhTitle, form);
        return pron.zh;
      }
      const en = pron.en;                        // 英文：句首首字母大写（工单二.1）
      return atSentenceStart(text, offset) ? en.charAt(0).toUpperCase() + en.slice(1) : en;
    }
    const kin = KIN_TOKENS[key] && KIN_TOKENS[key][sex];
    if (kin) {
      if (lang === "zh") return kin.zh;
      return atSentenceStart(text, offset) ? kin.en.charAt(0).toUpperCase() + kin.en.slice(1) : kin.en;
    }
    return whole;
  });
}

// ---------- 事件查找 ----------
function findEvent(id) {
  return INTRO.find(e => e.id === id) || EVENTS.find(e => e.id === id);
}

// ---------- 日志 ----------
function addLog(entry) {
  if (entry) state.log.push(entry);
}

// 页标题进日志时带的括号也分语言
function bracketTitle(title) {
  if (typeof title === "string") return "【" + title + "】";
  return { en: "[" + (title.en || "") + "]", zh: "【" + (title.zh || "") + "】" };
}

// ---------- 剧情自检（写作辅助，玩家无感知） ----------
function checkStory() {
  const problems = [];
  const all = [...INTRO, ...EVENTS];

  // 1) id 重复 / 断链
  const ids = new Set();
  all.forEach(e => {
    if (ids.has(e.id)) problems.push("事件 id 重复：" + e.id);
    ids.add(e.id);
  });
  all.forEach(e => (e.choices || []).forEach(c => {
    const t = c.next;
    if (t && t !== "ENDING_CHECK" && !ids.has(t)) {
      problems.push(`「${L(e.title)}」的选项指向了不存在的事件：${t}`);
    }
  }));

  // 2) 标志位拼写：when / hide / set / push 里的键必须先在 INITIAL_STATE 里定义过
  const checkFlags = (obj, label) => {
    if (!obj) return;
    Object.entries(obj).forEach(([k, v]) => {
      if (!(k in INITIAL_STATE)) problems.push(label + " 用了未定义的标志位：" + k);
      if (k === "rememberedBy" && !NAMES[v]) problems.push(label + " 的名单里没有这个人：" + v);
    });
  };

  // 3) 正文变体必须留一条无条件兜底，否则条件全不满足时是一页空白
  const checkVariants = (v, label) => {
    if (!Array.isArray(v)) return;
    if (!v.some(x => !x.when)) problems.push(label + " 的条件变体没有兜底（条件全不满足时会是空白页）");
    v.forEach(x => { checkFlags(x.when, label); checkVariants(x.text, label); });
  };

  // 4) 漏译：所有要展示的文字必须 en / zh 成对
  const checkPair = (v, label) => {
    if (v == null) return;
    if (typeof v === "string") { problems.push(label + " 还没写成双语"); return; }
    if (!v.en || !v.zh) problems.push(label + (v.en ? " 缺中文" : " 缺英文"));
  };
  const checkText = (v, label) => {
    if (Array.isArray(v)) v.forEach(x => checkText(x.text, label));
    else checkPair(v, label);
  };

  // 6) token 拼写：文本里的 {xxx} 只能是 {name} 或 RO 代词/称谓 token
  //    （残留的未知 token 会在页面上原样显示，必须静态拦下）
  const collectLeafText = (v, out) => {
    if (v == null) return;
    if (typeof v === "string") { out.push(v); return; }
    if (Array.isArray(v)) { v.forEach(x => collectLeafText(x.text, out)); return; }
    if (v.zh) out.push(v.zh);
    if (v.en) out.push(v.en);
  };
  const scanTokens = (v, label) => {
    const leaves = [];
    collectLeafText(v, leaves);
    leaves.forEach(t =>
      (String(t).match(/\{[a-zA-Z]+\}/g) || []).forEach(tok => {
        if (!KNOWN_TOKENS.has(tok.slice(1, -1))) {
          problems.push(label + " 用了未知 token：" + tok);
        }
      }));
  };
  all.forEach(e => {
    checkText(e.title, `「${e.id}」的标题`);
    checkText(e.text, `「${e.id}」的正文`);
    checkVariants(e.text, `「${e.id}」的正文`);
    scanTokens(e.title, `「${e.id}」的标题`);
    scanTokens(e.text, `「${e.id}」的正文`);
    (e.choices || []).forEach(c => {
      checkText(c.text, `「${e.id}」的选项`);
      checkPair(c.log, `「${e.id}」的选项日志`);
      scanTokens(c.text, `「${e.id}」的选项`);
      scanTokens(c.log, `「${e.id}」的选项日志`);
      checkFlags(c.when, `「${e.id}」的选项`);
      checkFlags(c.hide, `「${e.id}」的选项`);
      checkFlags(c.set, `「${e.id}」的选项`);
      checkFlags(c.push, `「${e.id}」的选项`);
    });
  });
  ENDINGS.forEach(e => {
    checkText(e.title, "结局「" + e.id + "」的标题");
    checkText(e.text, "结局「" + e.id + "」的正文");
    checkVariants(e.text, "结局「" + e.id + "」的正文");
    scanTokens(e.title, "结局「" + e.id + "」的标题");
    scanTokens(e.text, "结局「" + e.id + "」的正文");
  });

  // 5) 成就：id 不重复、文案双语、条件标志位存在、指向的结局存在
  const achIds = new Set();
  ACHIEVEMENTS.forEach(a => {
    if (achIds.has(a.id)) problems.push("成就 id 重复：" + a.id);
    achIds.add(a.id);
    checkPair(a.title, "成就「" + a.id + "」的名称");
    checkPair(a.desc, "成就「" + a.id + "」的描述");
    checkFlags(a.when, "成就「" + a.id + "」");
    if (a.ending && a.ending !== "*" && !ENDINGS.some(e => e.id === a.ending)) {
      problems.push("成就「" + a.id + "」指向了不存在的结局：" + a.ending);
    }
  });
  Object.entries(TRAITS).forEach(([g, kv]) => Object.entries(kv).forEach(([k, v]) => {
    checkPair(v.label, `人物词条 ${g}.${k} 的显示名`);
    checkPair(v.desc, `人物词条 ${g}.${k} 的描述`);
  }));
  Object.entries(NAMES).forEach(([id, v]) => checkPair(v, `人名 ${id}`));

  return problems;
}

// ---------- 事件渲染 ----------
// 入场动画播放中＝true；点击正文任意处立即播完（跳过）
let animating = false;
function finishAnim() {
  if (!animating) return;
  animating = false;
  $("#event-text").classList.add("no-anim");
  $("#choices").classList.add("no-anim");
}

// ---------- 左页插图：按场景组换图（ILLUST_MAP，story/00-config.js），支持角色性别分版 ----------
// 解析链：ILLUST_MAP 精确id命中（含性别后缀）→ 未命中/性别未定沿用上一页的图 → 一局开头无图时空白羊皮纸。
// ILLUST_VER：插图更新时递增，拼进请求串破浏览器缓存（旧图缓存是"左页空白"的元凶）。
const ILLUST_VER = "v7";
function illustUrl(name) { return "assets/illust/" + name + "?" + ILLUST_VER; }
function illustKeyFor(id, st) {
  const map = (typeof ILLUST_MAP !== "undefined") ? ILLUST_MAP : [];
  const hit = map.find(m => m.ids && m.ids.indexOf(id) !== -1);
  if (!hit || !hit.key) return "";
  if (hit.sex) {
    const v = st[hit.sex];
    if (v === "male") return hit.key + "_m";
    if (v === "female") return hit.key + "_f";
    if (v === "nonbinary") return hit.key + (hit.nb || "_obj");
    return "";                                   // 性别未定＝沿用上一页
  }
  return hit.key;
}
// 预取缓存（加载优化工单 2026-10-21）：url→Image 常驻引用，防浏览器回收解码结果
// （同 BOOK_IMGS 的教训）；预取过的图 setIllust 直接命中，不再等网络。
const ILLUST_CACHE = {};
function prefetchIllust(url) {
  if (typeof Image !== "function" || !url) return null;
  if (ILLUST_CACHE[url]) return ILLUST_CACHE[url];
  const im = new Image();
  ILLUST_CACHE[url] = im;                        // 先入缓存防回收
  im.src = url;
  try { if (im.decode) im.decode().catch(() => {}); } catch (e) {}
  return im;
}
// 等 url 的图加载＋解码完成；失败返回 null（清缓存让下次重试）
function loadIllustReady(url) {
  return new Promise((resolve) => {
    const im = prefetchIllust(url);
    if (!im) { resolve(null); return; }          // 工具沙盒
    if (im.complete) {
      if (im.naturalWidth > 0) { resolve(url); } else { delete ILLUST_CACHE[url]; resolve(null); }
      return;
    }
    im.onload = () => resolve(url);
    im.onerror = () => { delete ILLUST_CACHE[url]; resolve(null); };
  });
}
// 把图坐进背景并拆掉交叉淡入叠层
function commitIllustBg(el, url) {
  const old = el.querySelector("img.illust-over");
  if (old && old.parentNode) old.parentNode.removeChild(old);
  el.style.background = 'url("' + url + '") center / cover no-repeat';
  el.classList.remove("illust-loading");
}
// 交叉淡入：旧图始终可见，新图（已 decode）以 <img> 淡入其上，过渡完坐进背景——
// 全程左页不出现空白（加载优化工单：不能先变空白再淡入）
function crossfadeIllust(el, url) {
  try {
    if (el._illustTimer) { clearTimeout(el._illustTimer); el._illustTimer = null; }
    if (el._illustUrl) commitIllustBg(el, el._illustUrl);   // 上一张还没坐底：先坐底
    const im = document.createElement("img");
    im.src = url; im.alt = ""; im.draggable = false;
    im.className = "illust-over";
    el.appendChild(im);
    el._illustUrl = url;
    const settle = () => { el._illustTimer = null; commitIllustBg(el, url); el._illustUrl = null; };
    if (typeof requestAnimationFrame === "function") {
      requestAnimationFrame(() => requestAnimationFrame(() => { im.classList.add("on"); }));
      el._illustTimer = setTimeout(settle, 380);
    } else settle();
  } catch (e) {
    try { commitIllustBg(el, url); } catch (e2) {}
  }
}
function setIllust(id) {
  const el = $("#page-illust");
  if (!el) return;                               // 结构不在（工具沙盒等）静默跳过
  const key = illustKeyFor(id, state);
  if (!key && el.dataset.key) return;            // 本页无图：沿用上一页，不重渲染
  if (key && el.dataset.key === key) return;     // 同图翻页不重新渲染
  el.dataset.key = key || "";
  const cands = [];
  if (key) cands.push(illustUrl(key + ".webp"), illustUrl(key + ".png"));
  if (typeof Image !== "function") return;       // 工具沙盒：只解析 key，不做真实加载
  let reduce = false;
  try { reduce = document.documentElement.classList.contains("reduce-motion"); } catch (e) {}
  const blank = () => {                          // 全缺＝空白羊皮纸，不出现破图
    el._illustUrl = null;
    if (el._illustTimer) { clearTimeout(el._illustTimer); el._illustTimer = null; }
    const old = el.querySelector("img.illust-over");
    if (old && old.parentNode) old.parentNode.removeChild(old);
    el.style.background = "";
    el.classList.remove("illust-loading");
  };
  if (!cands.length) { blank(); return; }
  const probe = (idx) => {
    if (idx >= cands.length) { blank(); return; }
    loadIllustReady(cands[idx]).then((url) => {
      if (!url) { probe(idx + 1); return; }
      if (reduce) { el._illustUrl = null; commitIllustBg(el, url); return; }   // 减弱动效：直接换
      crossfadeIllust(el, url);                  // 新图 decode 完才淡入，旧图一直在
    });
  };
  probe(0);
}

// ---------- 结局跨页左页：沿用末页的插图映射（ILLUST_MAP 精确 id），全缺＝空白羊皮纸 ----------
function setEndingIllust() {
  const el = $("#ending-illust");
  if (!el) return;                               // 结构不在（工具沙盒等）静默跳过
  const key = (currentEvent && illustKeyFor(currentEvent.id, state)) || "";
  if (typeof Image !== "function") return;
  const cands = key ? [illustUrl(key + ".webp"), illustUrl(key + ".png")] : [];
  const probe = (idx) => {
    if (idx >= cands.length) { el.style.background = ""; return; }
    loadIllustReady(cands[idx]).then((url) => {
      if (!url) { probe(idx + 1); return; }
      el.style.background = 'url("' + url + '") center / cover no-repeat';
    });
  };
  probe(0);
}

// ---------- 插图预取（加载优化工单 2026-10-21） ----------
// 每页渲染完：把本页所有可见选项的落点页插图提前下载（按选项自带 set 推算性别分版）
function prefetchChoicesIllust(evt) {
  if (!evt || typeof Image !== "function") return;
  (evt.choices || []).forEach(c => {
    if (c.when && !matchWhen(c.when)) return;
    if (c.hide && matchWhen(c.hide)) return;
    if (!c.next || c.next === "ENDING_CHECK") return;   // 结局页沿用本页图，已在缓存
    const st = Object.assign({}, state, c.set || {});   // 该选项按下后的标志位
    const key = illustKeyFor(c.next, st);
    if (key) prefetchIllust(illustUrl(key + ".webp"));
  });
}
// 开书后：requestIdleCallback（无则 setTimeout 兜底）在后台一次一张，
// 把全部 23 张插图收进缓存，不挤占当前页（加载优化工单 2026-10-21）
let illustBgStarted = false;
function startIllustBgPrefetch() {
  if (illustBgStarted || typeof Image !== "function") return;
  illustBgStarted = true;
  const urls = [illustUrl("cover.webp")];
  const seen = {};
  (typeof ILLUST_MAP !== "undefined" ? ILLUST_MAP : []).forEach(m => {
    if (!m || !m.key) return;
    (m.sex ? ["_m", "_f", (m.nb || "_obj")] : [""]).forEach(v => {
      const u = illustUrl(m.key + v + ".webp");
      if (!seen[u]) { seen[u] = 1; urls.push(u); }
    });
  });
  let i = 0;
  const step = () => { if (i < urls.length) { prefetchIllust(urls[i++]); setTimeout(step, 150); } };
  const kick = () => step();
  if (typeof requestIdleCallback === "function") requestIdleCallback(kick, { timeout: 3000 });
  else setTimeout(kick, 1200);
}

// ---------- 开合书与翻页：像素帧动画（素材：Antahonist book，帧内含 36px 透明边） ----------
// 帧时长可调：想改开合书/翻页速度，只调这一个数（工单要求 60–70ms）。
const BOOK_FRAME_MS = 65;

function frameUrls(dir, name, n) {
  const urls = [];
  for (let i = 0; i < n; i++) {
    urls.push("assets/ui/book/" + dir + "/frames/" + name + "_" + String(i).padStart(2, "0") + ".png");
  }
  return urls;
}
const BOOK_FRAMES = {
  open:  frameUrls("open", "open", 16),                 // 合书 → 摊开
  close: frameUrls("close", "close", 12),               // 摊开 → 合书
  flip:  frameUrls("flip_forward", "flip_forward", 12)  // 右页翻页
};
// 预加载全部帧：Image 引用保留在 BOOK_IMGS 里防浏览器回收解码结果（闪烁修复 2026-10-21），
// 每帧 decode() 记录完成状态；全部就绪后 bookFramesReady 置 true。
const BOOK_IMGS = {};
let bookFramesReady = false;
function preloadBookFrames() {
  if (typeof Image !== "function") return;       // 工具沙盒：跳过
  const jobs = [];
  Object.keys(BOOK_FRAMES).forEach(k => {
    BOOK_IMGS[k] = BOOK_FRAMES[k].map(u => {
      const im = new Image(); im.src = u;
      try { jobs.push(im.decode ? im.decode().catch(() => {}) : Promise.resolve()); } catch (e2) {}
      return im;
    });
  });
  Promise.all(jobs).then(() => { bookFramesReady = true; }).catch(() => { bookFramesReady = true; });
}

// 在书舞台上播一组帧（闪烁修复 2026-10-21 的播放方式）：
//   全部帧 <img> 一次性叠入层内，rAF 按时间切 opacity——浏览器卡顿只跳帧，不出现空帧；
//   挂层即亮首帧，层没有透明期；播完停在最后一帧 → 回调（新页/新屏先渲染，层盖在上面）→
//   nextPaint 之后再撤层，中间不露底；帧未解码完最多等 300ms，仍不行就直切页面不播动画。
// 失败静默直通回调——视觉层永远不影响游戏逻辑。
function playBookFrames(stage, urls, onDone) {
  const direct = () => { try { onDone(); } catch (e) {} };
  try {
    if (!stage || typeof document === "undefined") { direct(); return; }
    if (!bookFramesReady) {                        // 首播等待解码（上限 300ms）
      const started = (typeof performance !== "undefined" ? performance.now() : Date.now());
      const poll = () => {
        if (bookFramesReady) { startBookAnim(stage, urls, onDone); return; }
        const now = (typeof performance !== "undefined" ? performance.now() : Date.now());
        if (now - started >= 300) { direct(); return; }
        setTimeout(poll, 30);
      };
      poll();
      return;
    }
    startBookAnim(stage, urls, onDone);
  } catch (e) { direct(); }
}

function startBookAnim(stage, urls, onDone) {
  const layer = document.createElement("div");
  layer.className = "book-anim";
  const imgs = urls.map(u => {
    const el = document.createElement("img");
    el.src = u; el.alt = ""; el.draggable = false;
    layer.appendChild(el);
    return el;
  });
  stage.appendChild(layer);
  let shown = -1;
  const show = (i) => {
    if (shown >= 0 && imgs[shown]) imgs[shown].style.opacity = "0";
    if (i >= 0 && i < imgs.length && imgs[i]) { imgs[i].style.opacity = "1"; shown = i; }
  };
  show(0);                                         // 挂层即亮首帧
  const finish = () => {
    try { onDone(); } catch (e2) {}                // 新页先渲染，最后一帧仍盖在最上
    let removed = false;
    const rm = () => {                             // 双 rAF 后再撤层，中间不露底
      if (removed) return;
      removed = true;
      try { if (layer.parentNode) layer.parentNode.removeChild(layer); } catch (e3) {}
    };
    if (typeof requestAnimationFrame === "function") nextPaint(rm);
    setTimeout(rm, 120);                           // rAF 停摆兜底：新页已渲染，直接撤不露底
  };
  const nowMs = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
  const t0 = nowMs();
  let finished = false;                            // finish 只走一次（rAF 与兜底定时器双驱动，防重入）
  const tick = () => {
    try {
      if (finished || !layer.parentNode) return;   // 已收尾/中途被拆：停
      const i = Math.floor((nowMs() - t0) / BOOK_FRAME_MS);
      if (i >= imgs.length) { finished = true; clearInterval(timer); show(imgs.length - 1); finish(); return; }
      show(i);
    } catch (e) {
      finished = true; clearInterval(timer);
      try { if (layer.parentNode) layer.parentNode.removeChild(layer); } catch (e2) {}
      try { onDone(); } catch (e3) {}
    }
  };
  // 双驱动：rAF 为主（正常时 60fps 精确切帧）；setTimeout 兜底（渲染被抑制时——窗口遮挡、
  // 后台标签、系统卡顿——rAF 停摆，定时器仍按节流节奏跳帧推进，动画拖长但不会卡死不播，
  // 也不会出现空帧。旧行为（纯 setTimeout 链）在遮挡下拖到 ~12s 播完，兜底与此对齐）。
  const timer = (typeof setInterval === "function") ? setInterval(tick, BOOK_FRAME_MS) : null;
  if (typeof requestAnimationFrame === "function") requestAnimationFrame(tick);
  else tick();
}

// 动效开关联动：只看游戏内「减弱动效」开关（系统 prefers-reduced-motion 不再干预）
function motionFull() {
  try { return !document.documentElement.classList.contains("reduce-motion"); }
  catch (e) { return true; }
}

// 双 rAF：先让浏览器画出「隐藏态」，再移除类触发淡入过渡（沙盒无 rAF 用 setTimeout 兜底）
function nextPaint(fn) {
  if (typeof requestAnimationFrame === "function") {
    requestAnimationFrame(() => requestAnimationFrame(fn));
  } else setTimeout(fn, 50);
}

// 标题舞台瞬回合书位（-454px）：无过渡＋强制重排，避免从跨页位滑过去被看见。
// 「书处于合书状态」统一收口在这里——凡是回到封面的入口（首次加载、合书动画结束、
// 设置里放弃冒险、结局后再次苏醒）都必须调它，漏了书就会停在跨页居中位（偏右）。
function snapTitleToCover() {
  const title = $("#title-stage");
  if (!title) return;
  title.style.transition = "none";
  title.classList.remove("stage-center");
  void title.offsetWidth;                      // 强制重排让归位立即生效
  title.style.transition = "";
}

// ---------- 封面 → 跨页：封面叠层淡出 → open 16 帧（舞台同步从合书位滑回跨页居中）→ 跨页内容淡入 ----------
function openBookThen(beginGame) {
  const stage = $("#title-stage");
  if (!stage || !motionFull()) {                 // 减弱动效：直接切换
    startIllustBgPrefetch();
    showScreen("#screen-game");
    beginGame();
    return;
  }
  stage.classList.add("cover-leaving");          // 封面叠层先淡出
  setTimeout(() => {
    // 滑移与帧动画同步（16×65=1040ms）：合书位 -454px → 跨页居中 0
    stage.style.transition = "transform 1040ms ease-in-out";
    stage.classList.add("stage-center");
    playBookFrames(stage, BOOK_FRAMES.open, () => {
      stage.style.transition = "";
      const g = $("#game-stage");
      if (g) g.classList.add("spread-hidden");   // 跨页内容先藏住（display 切换前）
      showScreen("#screen-game");
      startIllustBgPrefetch();                   // 开书完成：后台逐张收全部插图（加载优化工单）
      beginGame();
      if (g) nextPaint(() => g.classList.remove("spread-hidden"));  // 再淡入
    });
  }, 360);
}

// ---------- 结局跨页 → 封面：跨页淡出 → close 12 帧（舞台同步滑回合书位）→ 封面叠层淡入 ----------
let closingBook = false;                           // 合书动画进行中（防「再次苏醒」连点重播）
function closeBookToCover() {
  if (closingBook) return;                         // 动画没播完前再点无效
  closingBook = true;
  const again = $("#btn-restart");
  if (again) again.disabled = true;                // 动画期间禁用按钮
  const release = () => { closingBook = false; if (again) again.disabled = false; };
  const stage = $("#ending-stage");
  const title = $("#title-stage");
  if (!stage || !motionFull()) {                 // 减弱动效：直接切换
    snapTitleToCover();
    showScreen("#screen-title");
    refreshContinue();
    release();
    return;
  }
  stage.classList.add("spread-hidden");          // 结局跨页先淡出
  setTimeout(() => {
    // 滑移与帧动画同步（12×65=780ms）：跨页居中 0 → 合书位 -454px
    stage.style.transition = "transform 780ms ease-in-out";
    stage.classList.add("stage-closing");
    playBookFrames(stage, BOOK_FRAMES.close, () => {
      stage.style.transition = "";
      stage.classList.remove("stage-closing");
      snapTitleToCover();                        // 切屏前先把标题舞台归位，避免闪跳
      if (title) title.classList.add("cover-leaving");  // display:none 下先藏叠层，避免闪一帧
      showScreen("#screen-title");
      refreshContinue();
      if (title) nextPaint(() => title.classList.remove("cover-leaving"));  // 叠层淡入
      release();
    });
  }, 360);
}

function renderEvent(evt, isRerender) {
  currentEvent = evt;
  setIllust(evt.id);
  if (!isRerender) {
    pageCount++;
    addLog(bracketTitle(evt.title));
  }
  $("#event-page").textContent = pageLabel(pageCount);
  $("#event-title").textContent = L(evt.title);

  // 段落渲染：\n\n 拆段逐个淡入；已读页跳过动画直接全显（f1 已读快进）
  const seen = loadRead().includes(evt.id);
  markRead(evt.id);
  const body = $("#event-text");
  body.innerHTML = "";
  body.className = seen ? "seen" : "";
  const paras = fillTokens(pickText(evt.text)).split("\n\n").filter(s => s !== "");
  paras.forEach((s, i) => {
    const p = document.createElement("p");
    p.className = "para";
    p.textContent = s;
    if (!seen) p.style.animationDelay = (i * 90) + "ms";
    body.appendChild(p);
  });
  animating = !seen;

  const box = $("#choices");
  box.innerHTML = "";
  box.className = seen ? "seen" : "";
  // 选项错峰：等正文播完再逐个跟上；已读页无延迟立即可点
  const base = seen ? 0 : paras.length * 90 + 120;
  let vi = 0;
  (evt.choices || []).forEach(choice => {
    // 选项显示条件
    if (choice.when && !matchWhen(choice.when)) return;
    if (choice.hide && matchWhen(choice.hide)) return;

    // 名字输入框
    if (choice.input) { renderNameInput(box, choice); return; }

    const btn = document.createElement("button");
    btn.className = "choice-btn";
    btn.textContent = fillTokens(L(choice.text));
    btn.style.animationDelay = (base + (vi++) * 70) + "ms";
    btn.onclick = () => onChoice(choice);
    box.appendChild(btn);
  });
  prefetchChoicesIllust(evt);   // 选项落点页插图提前下载（加载优化工单 2026-10-21）

  // 像素翻页改由 onChoice 驱动（右页淡出 → 翻页帧 → 新页淡入），这里只管渲染本页
  // 长页防溢出：正文超高时约束正文区高度，选项始终留在纸面可视区（短页零变化）。
  // 工具沙盒无 requestAnimationFrame：跳过（只验证渲染分支，不做真实测量，同 setIllust 的 Image 守卫）。
  if (typeof requestAnimationFrame === "function") requestAnimationFrame(() => {
    const main = $("#page-main"), body = $("#event-body"), box = $("#choices");
    if (!main || !body || !box) return;
    body.style.maxHeight = "";
    if (main.scrollHeight > main.clientHeight + 2) {
      // 可用高 = main 内容高（扣除自身上下 padding）− 选项区 margin − 选项区高 − 4px 余量
      const cs = getComputedStyle(box), ms = getComputedStyle(main);
      const gap = (parseFloat(cs.marginTop) || 0) + (parseFloat(cs.marginBottom) || 0);
      const pad = (parseFloat(ms.paddingTop) || 0) + (parseFloat(ms.paddingBottom) || 0);
      body.style.maxHeight = Math.max(200, main.clientHeight - pad - gap - box.offsetHeight - 4) + "px";
    }
  });
  if (!isRerender) saveGame();   // 每翻一页静默存档
}

function renderNameInput(box, choice) {
  const wrap = document.createElement("div");
  wrap.className = "name-input";

  const input = document.createElement("input");
  input.type = "text";
  input.maxLength = 12;
  input.placeholder = L(STR.nameless);
  // 二次起名（e06）：回填已有名字——「报出你的名字」而非「重新起名」；
  // 从未起过名的玩家 value 为空，只露 placeholder「无名者」。
  input.value = (state && state.name) || "";
  input.setAttribute("aria-label", L(choice.text));

  const btn = document.createElement("button");
  btn.className = "choice-btn";
  btn.textContent = L(STR.useName);
  btn.onclick = () => {
    const v = input.value.trim();
    if (v) state.name = v;                    // 有输入＝采用（含沿用回填的旧名）
    else if (!state.name) delete choice.set;  // 空输入且从未起过名＝保持「无名者」，set 不生效
    // 空输入但已有旧名＝不说也不抹，沿用序章起的名字
    onChoice(choice);
  };

  input.onkeydown = (e) => { if (e.key === "Enter") btn.click(); };
  wrap.append(input, btn);
  box.appendChild(wrap);
  input.focus();
}

// ---------- 选项处理 ----------
let lastChoiceAt = 0;   // 防连点：双击的第二个 click 会落在新页面的选项上
let flipping = false;   // 翻页帧播放中：吞掉期间的点击
function onChoice(choice) {
  const now = Date.now();
  if (now - lastChoiceAt < 300 || flipping) return;
  lastChoiceAt = now;

  if (choice.set) {
    for (const [k, v] of Object.entries(choice.set)) state[k] = v;
  }
  if (choice.push) {
    for (const [k, v] of Object.entries(choice.push)) {
      if (Array.isArray(state[k]) && !state[k].includes(v)) state[k].push(v);
    }
  }
  if (choice.log) addLog(choice.log);

  checkAchievements();   // 标志位刚变过，看看有没有成就达成

  const go = () => {
    if (choice.next === "ENDING_CHECK") { showEnding(); return; }
    const next = findEvent(choice.next);
    if (next) renderEvent(next); else showEnding();
  };

  // 像素翻页（全覆盖）：右页内容淡出 → flip 12 帧 → 新页内容淡入。
  // 已读页同样播翻页，只是渲染走 seen 分支跳过文字的逐段淡入。
  if (!motionFull()) { go(); return; }
  const main = $("#page-main");
  if (!main) { go(); return; }
  flipping = true;
  main.classList.add("page-turning");
  setTimeout(() => {
    playBookFrames($("#game-stage"), BOOK_FRAMES.flip, () => {
      flipping = false;
      main.classList.remove("page-turning");
      go();
    });
  }, 180);
}

// ---------- 人物面板文字 ----------
function traitLabel(group, key) {
  const t = (TRAITS[group] || {})[key];
  return t ? L(t.label) : "—";
}
function traitDesc(group, key) {
  const t = (TRAITS[group] || {})[key];
  return t ? L(t.desc) : "";
}
function scarLine() {
  const base = traitDesc("scar", state.scar) || L(STR.scarNone);
  return state.scarNew ? base + " " + L(STR.newScarPanel) : base;
}
function rememberedLine() {
  if (!state.rememberedBy.length) return L(STR.noOne);
  const sep = lang === "zh" ? "、" : ", ";
  return state.rememberedBy.map(id => NAMES[id] ? L(NAMES[id]) : id).join(sep);
}

// ---------- 结局 ----------
function showEnding() {
  const ending = ENDINGS.find(e => e.condition(state)) || ENDINGS[ENDINGS.length - 1];
  currentEnding = ending;
  renderEnding(ending);
  setEndingIllust();

  // 结局进图鉴
  const unlocked = loadEndings();
  if (!unlocked.includes(ending.id)) {
    unlocked.push(ending.id);
    try { store.setItem("tlyao_endings", JSON.stringify(unlocked)); } catch (e) { /* 存不下就只影响图鉴解锁 */ }
  }

  checkAchievements(ending.id);   // 结局类成就
  clearSave();                    // 一局走完，「继续」不再指回这里
  refreshContinue();
  const es = $("#ending-stage");
  const fade = es && motionFull();
  if (fade) es.classList.add("spread-hidden");   // display 切换前先藏，避免闪一帧
  showScreen("#screen-ending");
  if (fade) nextPaint(() => es.classList.remove("spread-hidden"));  // 结局跨页淡入
}

function renderEnding(ending) {
  $("#ending-title").textContent = L(ending.title);
  $("#ending-text").textContent = fillTokens(pickText(ending.text));
  // 结局摘要：通用遍历 TRAITS，把本局定下的条目拼成一行回顾
  const parts = [];
  Object.keys(TRAITS).forEach(g => {
    const v = state[g];
    if (v && TRAITS[g] && TRAITS[g][v]) parts.push(L(TRAITS[g][v].label));
  });
  $("#ending-summary").textContent = parts.length ? parts.join(" · ") : "";
}

// ---------- 次级菜单面板 ----------
document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.onclick = () => openPanel(btn.dataset.panel);
});
$("#panel-close").onclick = () => $("#panel-overlay").classList.add("hidden");
$("#panel-overlay").onclick = (e) => {
  if (e.target.id === "panel-overlay") e.target.classList.add("hidden");
};

function charRow(key, value) {
  const div = document.createElement("div");
  div.className = "char-row";
  div.innerHTML = `<span class="char-key">${key}</span><span class="char-val"></span>`;
  div.querySelector(".char-val").textContent = value;
  return div;
}

// ---------- 结局图鉴（工单第三部分 B）----------
// 只列 4 个正式结局，顺序＝force → yield → fall → rewrite；兜底 dev_end 不进图鉴
// （结局判定与解锁记录逻辑不动）。卡面 CG 按结局事件对应：endA/B/C/H → cg_end_a/b/c/h。
const GAL_ENDINGS = [
  { id: "force",   cg: "cg_end_a" },
  { id: "yield",   cg: "cg_end_b" },
  { id: "fall",    cg: "cg_end_c" },
  { id: "rewrite", cg: "cg_end_h" }
];
// 锁图标（内联 SVG，随 currentColor 染色；不引第三方素材）
const LOCK_SVG = '<svg viewBox="0 0 24 24" width="34" height="34" aria-hidden="true">' +
  '<path d="M7 10V7a5 5 0 0 1 10 0v3h1a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h1zm2 0h6V7a3 3 0 0 0-6 0v3z" fill="currentColor"/>' +
  '<circle cx="12" cy="15" r="1.7" fill="#2e2013"/></svg>';

// 详情短文：可能从扉页（state 为空）打开——fillTokens 对未设性别的 token 会原样保留，
// 这里临时用一套中性（nonbinary）代词渲染，读完立刻恢复，不碰真存档。
function galText(text) {
  if (state) return fillTokens(L(text));
  const saved = state;
  state = { roA_sex: "nonbinary", roB_sex: "nonbinary", roC_sex: "nonbinary" };
  try { return fillTokens(L(text)); } finally { state = saved; }
}

// 设置里的一行：左边标签，右边一排小按钮，选中项泛金
function setRow(label, keys, labelOf, current, onPick) {
  const row = document.createElement("div");
  row.className = "set-row";
  const k = document.createElement("span");
  k.className = "set-key";
  k.textContent = label;
  const seg = document.createElement("span");
  seg.className = "seg";
  keys.forEach(key => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "seg-btn" + (key === current ? " on" : "");
    b.textContent = labelOf(key);
    b.onclick = () => onPick(key);
    seg.appendChild(b);
  });
  row.append(k, seg);
  return row;
}

// 音量滑块行（BGM C.3）：拖动即时生效，值存本地
function volRow() {
  const row = document.createElement("div");
  row.className = "set-row";
  const k = document.createElement("span");
  k.className = "set-key";
  k.textContent = L(STR.setVolume);
  const input = document.createElement("input");
  input.type = "range";
  input.min = 0; input.max = 100; input.step = 5;
  input.value = bgmVol;
  input.setAttribute("aria-label", L(STR.setVolume));
  input.oninput = () => setBgmVol(Number(input.value));
  row.append(k, input);
  return row;
}

function openPanel(type) {
  currentPanel = type;
  $("#panel-title").textContent = L(STR.panel[type]);
  const c = $("#panel-content");
  c.innerHTML = "";

  if (type === "character") {
    // 通用渲染：按 TRAITS 的键序，把 state 里有值的条目各显示一行
    // （姓名行只在玩家已经报过名字后才出现）
    const rows = [];
    // 名字行常驻（游戏中打开面板必有）：未起名显示兜底「无名者」
    if (state) rows.push(charRow(L(STR.row.name), displayName()));
    Object.keys(TRAITS).forEach(g => {
      const v = state ? state[g] : "";
      if (v && TRAITS[g][v]) {
        // 左列＝类别名（TRAIT_CATS），右列＝玩家所选的选项名；散文描述不再进面板（2026-10-16 用户裁决）
        rows.push(charRow(TRAIT_CATS[g] ? L(TRAIT_CATS[g]) : traitLabel(g, v), traitLabel(g, v)));
      }
    });
    if (rows.length) rows.forEach(r => c.appendChild(r));
    else c.innerHTML = "<p>" + L(STR.charEmpty) + "</p>";
  }

  if (type === "log") {
    if (!state || !state.log.length) { c.innerHTML = "<p>" + L(STR.logEmpty) + "</p>"; }
    else state.log.forEach(line => {
      const div = document.createElement("div");
      div.className = "log-entry";
      div.textContent = fillTokens(L(line));
      c.appendChild(div);
    });
  }

  if (type === "gallery") {
    const unlocked = loadEndings();
    if (galleryDetail) {
      // 详情视图（工单 B.4）：顶部返回，左边大图（4:5），右边结局名＋完整短文
      const g = GAL_ENDINGS.find(x => x.id === galleryDetail);
      const e = ENDINGS.find(x => x.id === g.id);
      const back = document.createElement("button");
      back.className = "text-btn gal-back";
      back.textContent = L(STR.galBack);
      back.onclick = () => { galleryDetail = null; openPanel("gallery"); };
      const wrap = document.createElement("div");
      wrap.className = "gal-detail";
      const img = document.createElement("div");
      img.className = "gal-detail-img gal-frame";
      img.style.backgroundImage = 'url("assets/illust/' + g.cg + '.webp")';
      const info = document.createElement("div");
      info.className = "gal-detail-info";
      const h = document.createElement("h3");
      h.textContent = "❦ " + L(e.title);
      const p = document.createElement("p");
      p.textContent = galText(e.text);
      info.append(h, p);
      wrap.append(img, info);
      c.append(back, wrap);
    } else {
      // 卡片网格（工单 B.1–B.3）：4 张 4:5 竖卡；未解锁＝黑剪影＋锁＋？？？，点击无反应
      const grid = document.createElement("div");
      grid.className = "gal-grid";
      GAL_ENDINGS.forEach(g => {
        const e = ENDINGS.find(x => x.id === g.id);
        const got = unlocked.includes(g.id);
        const card = document.createElement("div");
        card.className = "gal-card" + (got ? " openable" : " locked");
        const frame = document.createElement("div");
        frame.className = "gal-card-img gal-frame";
        const pic = document.createElement("div");
        pic.className = "gal-card-pic";
        pic.style.backgroundImage = 'url("assets/illust/' + g.cg + '.webp")';
        frame.appendChild(pic);
        if (!got) {
          const lock = document.createElement("div");
          lock.className = "gal-lock";
          lock.innerHTML = LOCK_SVG;
          frame.appendChild(lock);
        }
        const cap = document.createElement("div");
        cap.className = "gal-card-name";
        cap.textContent = got ? "❦ " + L(e.title) : L(STR.locked);
        card.append(frame, cap);
        if (got) card.onclick = () => { galleryDetail = g.id; openPanel("gallery"); };
        grid.appendChild(card);
      });
      c.appendChild(grid);
    }
  }

  if (type === "settings") {
    // 字号：三档，改完立刻生效，也存在本地
    c.appendChild(setRow(L(STR.setFont), ["s", "m", "l"],
      (k) => L(STR.fontSize[k]), fontSize,
      (k) => { setFontSize(k); openPanel("settings"); }));
    // 行距：三档，文字游戏的阅读舒适度（f1）
    c.appendChild(setRow(L(STR.setLh), ["s", "m", "l"],
      (k) => L(STR.lh[k]), lineH,
      (k) => { setLineH(k); openPanel("settings"); }));
    // 动效：减弱会关掉全部过渡与动画（晕动症友好，也更省电）
    c.appendChild(setRow(L(STR.setMotion), ["full", "reduced"],
      (k) => L(STR.motion[k]), motion,
      (k) => { setMotion(k); openPanel("settings"); }));
    // 音乐开关（默认开）与音量滑块（默认 50%），均存本地（冲刺工单 C.3）
    c.appendChild(setRow(L(STR.setBgm), ["on", "off"],
      (k) => L(STR.bgm[k]), bgmOn ? "on" : "off",
      (k) => { setBgm(k === "on"); openPanel("settings"); }));
    c.appendChild(volRow());
    // 动效说明：点明翻页动画也随此开关关闭，系统级动画关闭同样不播（玩家排查用）
    const motionNote = document.createElement("p");
    motionNote.className = "set-note";
    motionNote.textContent = L(STR.motionNote);
    c.appendChild(motionNote);

    // 剧情自检结果：写作时如果有断链或漏译，打开设置就能看到
    const problems = checkStory();
    if (problems.length) {
      const warn = document.createElement("p");
      warn.className = "dim warn";
      warn.textContent = "⚠ 剧情自检发现问题：" + problems.join("；");
      c.appendChild(warn);
    }

    const btn = document.createElement("button");
    btn.className = "text-btn";
    btn.textContent = L(STR.abandon);
    btn.onclick = () => {
      $("#panel-overlay").classList.add("hidden");
      snapTitleToCover();                        // 回封面必须归位合书位：漏了书会停在跨页居中位（偏右）
      const t = $("#title-stage");
      if (t) t.classList.remove("cover-leaving");   // 直接回封面：叠层必须亮着
      showScreen("#screen-title");
      refreshContinue();   // 回封面时按存档决定「继续」露不露
    };
    c.appendChild(btn);
  }

  $("#panel-overlay").classList.remove("hidden");
}

// ---------- 开局 ----------
function resetRun() {
  state = JSON.parse(JSON.stringify(INITIAL_STATE));
  pageCount = 0;
  currentEvent = null;
  currentEnding = null;
  currentPanel = null;
}

function startGame() {
  resetRun();
  showScreen("#screen-game");
  renderEvent(INTRO.length ? INTRO[0] : EVENTS[0]);
}

// 继续上次冒险：还原标志位与页数，原地重渲染存档里的那一页
function continueGame() {
  const s = loadSave();
  if (!s) { refreshContinue(); return; }
  resetRun();
  Object.assign(state, s.state);
  pageCount = s.page || 1;
  showScreen("#screen-game");
  renderEvent(findEvent(s.ev), true);
}

$("#btn-start").onclick = () => {
  // 有进行中的存档时提醒一句：翻开第一页＝覆盖它（确认过了才开书）
  if (loadSave() && typeof window.confirm === "function" && !window.confirm(L(STR.startOver))) return;
  openBookThen(startGame);
};
$("#btn-continue").onclick = () => openBookThen(continueGame);
$("#btn-restart").onclick = closeBookToCover;   // 结局页：合上书回到封面，从封面再开新局
$("#btn-gallery-title").onclick = () => { state = null; openPanel("gallery"); };
document.querySelectorAll(".lang-btn").forEach(b => { b.onclick = toggleLang; });

// 正文区点击＝立即播完入场动画（跳过）
$("#event-body").addEventListener("click", finishAnim);

// ---------- 语言切换 ----------
function toggleLang() {
  lang = lang === "zh" ? "en" : "zh";
  store.setItem(LANG_KEY, lang);
  applyLang();
}

function applyLang() {
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";
  document.title = L(STR.docTitle);

  // 界面上写死的中文都带着 data-en，一并换掉
  document.querySelectorAll("[data-zh]").forEach(el => {
    el.textContent = el.dataset[lang] || el.dataset.zh || "";
  });
  document.querySelectorAll(".lang-btn").forEach(b => {
    b.textContent = lang === "zh" ? "EN" : "中文";
    b.title = lang === "zh" ? "Switch to English" : "切换到中文";
  });
  refreshContinue();   // 「继续上次冒险」显隐随语言切换同步刷新

  // 原地重渲染当前页：进度不丢，输入框里没提交的名字也留着
  const typed = $("#choices .name-input input");
  const pending = typed ? typed.value : null;
  if ($("#screen-game").classList.contains("active") && currentEvent) renderEvent(currentEvent, true);
  if ($("#screen-ending").classList.contains("active") && currentEnding) renderEnding(currentEnding);
  if (!$("#panel-overlay").classList.contains("hidden") && currentPanel) openPanel(currentPanel);
  const again = $("#choices .name-input input");
  if (again && pending != null) { again.value = pending; again.focus(); }
}

// ---------- 全屏切换（冲刺工单 .4）：右上角与语言按钮并排，Fullscreen API ----------
// iframe 环境（itch）若不允许全屏，requestFullscreen 会被拒绝——静默处理，不影响游玩
function toggleFullscreen() {
  if (document.fullscreenElement) { document.exitFullscreen().catch(() => {}); return; }
  document.documentElement.requestFullscreen().catch(() => {});
}
function refreshFsBtns() {
  const on = !!document.fullscreenElement;
  document.querySelectorAll(".fs-btn").forEach(b => {
    b.dataset.zh = on ? "退出全屏" : "全屏";
    b.dataset.en = on ? "Exit" : "Full";
    b.textContent = on ? (lang === "zh" ? "退出全屏" : "Exit") : (lang === "zh" ? "全屏" : "Full");
  });
}
document.querySelectorAll(".fs-btn").forEach(b => { b.onclick = toggleFullscreen; });
if (typeof document.addEventListener === "function") {
  document.addEventListener("fullscreenchange", refreshFsBtns);
}

// ---------- 书本缩放：整数倍优先（放大后宽高都占视口 85% 以上），否则非整数倍＋pixelated ----------
// 基准：书图 420x264（书舞台布局盒为其 x4）。--book-scale 供 .book-stage 的 zoom 使用。
const BOOK_W = 420, BOOK_H = 264;
function computeBookScale() {
  const raw = Math.min(innerWidth / BOOK_W, innerHeight / BOOK_H);
  const sInt = Math.floor(raw);
  const s = (sInt >= 1 &&
    sInt * BOOK_W / innerWidth >= 0.85 && sInt * BOOK_H / innerHeight >= 0.85)
    ? sInt : raw * 0.95;
  document.documentElement.style.setProperty("--book-scale", s);
}
// 仅浏览器环境启用（V8 沙盒无 innerWidth/addEventListener，跳过即可）
if (typeof innerWidth === "number") {
  computeBookScale();
  if (typeof window.addEventListener === "function") {
    window.addEventListener("resize", computeBookScale);
  }
}

// ---------- 启动时剧情自检：问题打到控制台，不影响游玩 ----------
applyPrefs();   // 先套用上次选的字号与动效
const storyProblems = checkStory();
if (storyProblems.length) {
  console.warn("【雾溪谷】剧情自检发现问题：\n" + storyProblems.join("\n"));
}
applyLang();
snapTitleToCover();   // 首载兜底：确保书在合书位（正常时 CSS 默认就是，防其它入口遗漏）
refreshContinue();
preloadBookFrames();   // 开合书/翻页帧预载：第一次播放不闪

// ---------- 封面就绪门（加载优化工单 2026-10-21） ----------
// 开书 16 帧＋封面图＋初页插图（scene_nest）decode 完成前，封面按钮禁用并显示
// 「正在准备书页…」；齐了恢复，8 秒兜底强制放行。按钮位置/封面布局不动。
let coverReady = false;
function openCoverGate() {
  if (coverReady) return;
  coverReady = true;
  document.querySelectorAll("#cover-menu .text-btn").forEach(b => { b.disabled = false; });
  const tip = $("#cover-preparing");
  if (tip) tip.hidden = true;
}
function setupCoverGate() {
  const btns = document.querySelectorAll("#cover-menu .text-btn");
  if (!btns.length) return;                      // 结构不在（工具沙盒等）
  if (typeof Image !== "function") { openCoverGate(); return; }
  btns.forEach(b => { b.disabled = true; });
  const tip = $("#cover-preparing");
  if (tip) tip.hidden = false;
  const ims = (BOOK_IMGS.open || []).slice();
  ["cover.webp", "scene_nest.webp"].forEach(k => { const im = prefetchIllust(illustUrl(k)); if (im) ims.push(im); });
  const t0 = Date.now();
  const poll = () => {
    if (coverReady) return;
    if (ims.every(im => im.complete && im.naturalWidth > 0) || Date.now() - t0 > 8000) { openCoverGate(); return; }
    setTimeout(poll, 100);
  };
  poll();
}
setupCoverGate();
ensureBgm();   // 封面显示即开始下载 BGM（preload="auto"），首次点击不等网络